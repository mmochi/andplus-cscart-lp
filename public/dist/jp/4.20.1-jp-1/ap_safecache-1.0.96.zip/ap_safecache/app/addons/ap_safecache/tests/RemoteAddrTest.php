<?php

declare(strict_types=1);

use PHPUnit\Framework\TestCase;

/**
 * lib/ap_safecache_remote_addr.php の純粋ロジック用スモークテスト。
 * 実行: 本ディレクトリで `phpunit` または `phpunit -c phpunit.xml`
 */
final class RemoteAddrTest extends TestCase
{
    /** @var array<string, mixed> */
    private $serverBackup = [];

    protected function setUp(): void
    {
        $this->serverBackup = $_SERVER;
    }

    protected function tearDown(): void
    {
        $_SERVER = $this->serverBackup;
    }

    public function testIpv4InCloudflareRange(): void
    {
        $this->assertTrue(fn_ap_safecache_ipv4_in_cidr('104.16.0.1', '104.16.0.0/13'));
        $this->assertTrue(fn_ap_safecache_remote_addr_is_cloudflare_edge('104.16.0.1'));
    }

    public function testIpv4OutsideCloudflareRanges(): void
    {
        $this->assertFalse(fn_ap_safecache_remote_addr_is_cloudflare_edge('8.8.8.8'));
    }

    public function testIpv6InCloudflareRange(): void
    {
        $this->assertTrue(fn_ap_safecache_ipv6_in_cidr('2606:4700::1', '2606:4700::/32'));
        $this->assertTrue(fn_ap_safecache_remote_addr_is_cloudflare_edge('2606:4700::1'));
    }

    public function testPickFirstValidIpFromCfConnectingHeader(): void
    {
        $_SERVER['HTTP_CF_CONNECTING_IP'] = '203.0.113.10, 198.51.100.2';
        $this->assertSame('203.0.113.10', fn_ap_safecache_remote_addr_pick_client_ip_from_cf_headers());
    }

    public function testApplyRemoteAddrRestoresClientWhenEdgeAndHeaderSet(): void
    {
        $_SERVER['REMOTE_ADDR'] = '104.16.0.1';
        $_SERVER['HTTP_CF_CONNECTING_IP'] = '198.51.100.99';
        unset(
            $_SERVER['AP_SAFECACHE_REMOTE_ADDR_RESTORED'],
            $_SERVER['AP_SAFECACHE_ORIGINAL_REMOTE_ADDR']
        );

        fn_ap_safecache_apply_remote_addr_from_cloudflare();

        $this->assertSame('198.51.100.99', $_SERVER['REMOTE_ADDR']);
        $this->assertSame('104.16.0.1', $_SERVER['AP_SAFECACHE_ORIGINAL_REMOTE_ADDR']);
        $this->assertSame('1', $_SERVER['AP_SAFECACHE_REMOTE_ADDR_RESTORED']);
    }

    public function testApplyRemoteAddrNoOpWhenNotCloudflareEdge(): void
    {
        $_SERVER['REMOTE_ADDR'] = '8.8.8.8';
        $_SERVER['HTTP_CF_CONNECTING_IP'] = '198.51.100.1';
        unset(
            $_SERVER['AP_SAFECACHE_REMOTE_ADDR_RESTORED'],
            $_SERVER['AP_SAFECACHE_ORIGINAL_REMOTE_ADDR']
        );

        fn_ap_safecache_apply_remote_addr_from_cloudflare();

        $this->assertSame('8.8.8.8', $_SERVER['REMOTE_ADDR']);
        $this->assertArrayNotHasKey('AP_SAFECACHE_ORIGINAL_REMOTE_ADDR', $_SERVER);
    }
}
