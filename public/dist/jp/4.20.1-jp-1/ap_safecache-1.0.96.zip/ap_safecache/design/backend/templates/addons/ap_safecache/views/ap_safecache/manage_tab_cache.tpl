<div class="dashboard-row" id="ap-safecache-purge" style="scroll-margin-top:72px;">
    <div>
        <div class="well" style="border:1px solid #e0c9a6;border-radius:4px;background:#fffbf5;">
            <div style="padding:4px 4px 8px 4px;">
            {if $ap_safecache_license_is_pro|default:true}
            {include file="common/subheader.tpl" title=__("ap_safecache.ui_group_cloudflare_purge")}
            <p class="muted">{__("ap_safecache.cloudflare_purge_hint")}</p>

            <p class="muted" style="margin-top: 1rem;"><strong>{__("ap_safecache.cloudflare_purge_by_urls")}</strong></p>
            <p class="muted">{__("ap_safecache.cloudflare_purge_by_urls_hint", ["[max]" => $ap_safecache_purge_url_max])}</p>

            <form action="{""|fn_url}" method="post" id="ap_safecache_purge_urls_form" name="ap_safecache_purge_urls_form">
                <textarea name="ap_safecache_purge_urls" rows="6" cols="72" class="input-textarea-long" style="width: 100%; max-width: 48rem;" placeholder="https://"></textarea>
                <div style="margin-top: 8px;">
                    {include file="buttons/button.tpl"
                        but_role="submit"
                        but_meta="btn"
                        is_btn_primary=false
                        but_name="dispatch[ap_safecache.purge_cloudflare_urls]"
                        but_text=__("ap_safecache.btn_purge_cloudflare_urls")
                        but_confirm_text=__("ap_safecache.confirm_purge_cloudflare_urls")
                    }
                </div>
            </form>

            <div class="alert alert-warning" style="margin-top: 1.25rem;">
                <p><strong>{__("ap_safecache.cloudflare_purge_everything")}</strong></p>
                <p>{__("ap_safecache.cloudflare_purge_warning")}</p>
            </div>

            <form action="{""|fn_url}" method="post" id="ap_safecache_purge_form" name="ap_safecache_purge_form">
                {include file="buttons/button.tpl"
                    but_role="submit"
                    but_meta="btn btn-danger"
                    is_btn_primary=false
                    but_name="dispatch[ap_safecache.purge_cloudflare_cache]"
                    but_text=__("ap_safecache.btn_purge_cloudflare_cache")
                    but_confirm_text=__("ap_safecache.confirm_purge_cloudflare")
                }
            </form>
            {else}
            <p class="muted">{__("ap_safecache.license_pro_feature_note")}</p>
            {/if}
            </div>
        </div>

        <div id="ap-safecache-cf-backup" class="well" style="margin-top: 1.5rem; border: 1px solid #e0e0e0; border-radius: 4px; scroll-margin-top: 72px;">
            <div style="padding: 12px 16px 16px 16px;">
            {if $ap_safecache_license_is_pro|default:true}
            {include file="common/subheader.tpl" title=__("ap_safecache.cf_backup_section")}
            <p class="muted">{__("ap_safecache.cf_backup_intro", ["[max]" => $ap_safecache_cf_backup_max_generations|escape])}</p>

            <p class="muted" style="margin-top: 0.75rem;"><strong>{__("ap_safecache.cf_backup_subsection_page")}</strong></p>
            <form action="{""|fn_url}" method="post" style="margin-bottom: 12px;">
                {include file="buttons/button.tpl"
                    but_role="submit"
                    but_meta="btn"
                    is_btn_primary=false
                    but_name="dispatch[ap_safecache.cf_backup_create_page]"
                    but_text=__("ap_safecache.cf_btn_backup_page_now")
                }
            </form>
            {if $ap_safecache_cf_backups_page|@count > 0}
                <div class="table-responsive-wrapper">
                    <table class="table table-middle table--relative">
                        <thead>
                            <tr>
                                <th>{__("ap_safecache.cf_backup_col_generation")}</th>
                                <th>{__("ap_safecache.cf_backup_col_created")}</th>
                                <th>{__("ap_safecache.cf_backup_col_user")}</th>
                                <th>{__("ap_safecache.cf_backup_col_actions")}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {foreach from=$ap_safecache_cf_backups_page item=bf}
                                <tr>
                                    <td>{$bf.generation|escape}</td>
                                    <td>{$bf.created_at|date_format:"%Y-%m-%d %H:%M"}</td>
                                    <td>{$bf.user_id|escape}</td>
                                    <td class="right">
                                        <form action="{""|fn_url}" method="post" style="display:inline;">
                                            <input type="hidden" name="backup_id" value="{$bf.backup_id}" />
                                            {include file="buttons/button.tpl"
                                                but_role="submit"
                                                but_meta="btn btn-primary"
                                                is_btn_primary=false
                                                but_name="dispatch[ap_safecache.cf_rollback_page]"
                                                but_text=__("ap_safecache.cf_btn_rollback_page")
                                                but_confirm_text=__("ap_safecache.cf_confirm_rollback_page")
                                            }
                                        </form>
                                        <form action="{""|fn_url}" method="post" style="display:inline; margin-left: 6px;">
                                            <input type="hidden" name="backup_id" value="{$bf.backup_id}" />
                                            {include file="buttons/button.tpl"
                                                but_role="submit"
                                                but_meta="btn btn-danger"
                                                is_btn_primary=false
                                                but_name="dispatch[ap_safecache.cf_backup_delete_page]"
                                                but_text=__("ap_safecache.cf_btn_delete_backup")
                                                but_confirm_text=__("ap_safecache.cf_confirm_delete_backup_page", ["[gen]" => $bf.generation|escape])
                                            }
                                        </form>
                                    </td>
                                </tr>
                            {/foreach}
                        </tbody>
                    </table>
                </div>
            {else}
                <p class="muted">{__("ap_safecache.cf_backup_empty_page")}</p>
            {/if}

            <p class="muted" style="margin-top: 1.25rem;"><strong>{__("ap_safecache.cf_backup_subsection_cache")}</strong></p>
            <form action="{""|fn_url}" method="post" style="margin-bottom: 12px;">
                {include file="buttons/button.tpl"
                    but_role="submit"
                    but_meta="btn"
                    is_btn_primary=false
                    but_name="dispatch[ap_safecache.cf_backup_create_cache]"
                    but_text=__("ap_safecache.cf_btn_backup_cache_now")
                }
            </form>
            {if $ap_safecache_cf_backups_cache|@count > 0}
                <div class="table-responsive-wrapper">
                    <table class="table table-middle table--relative">
                        <thead>
                            <tr>
                                <th>{__("ap_safecache.cf_backup_col_generation")}</th>
                                <th>{__("ap_safecache.cf_backup_col_created")}</th>
                                <th>{__("ap_safecache.cf_backup_col_user")}</th>
                                <th>{__("ap_safecache.cf_backup_col_actions")}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {foreach from=$ap_safecache_cf_backups_cache item=bf}
                                <tr>
                                    <td>{$bf.generation|escape}</td>
                                    <td>{$bf.created_at|date_format:"%Y-%m-%d %H:%M"}</td>
                                    <td>{$bf.user_id|escape}</td>
                                    <td class="right">
                                        <form action="{""|fn_url}" method="post" style="display:inline;">
                                            <input type="hidden" name="backup_id" value="{$bf.backup_id}" />
                                            {include file="buttons/button.tpl"
                                                but_role="submit"
                                                but_meta="btn btn-primary"
                                                is_btn_primary=false
                                                but_name="dispatch[ap_safecache.cf_rollback_cache]"
                                                but_text=__("ap_safecache.cf_btn_rollback_cache")
                                                but_confirm_text=__("ap_safecache.cf_confirm_rollback_cache")
                                            }
                                        </form>
                                        <form action="{""|fn_url}" method="post" style="display:inline; margin-left: 6px;">
                                            <input type="hidden" name="backup_id" value="{$bf.backup_id}" />
                                            {include file="buttons/button.tpl"
                                                but_role="submit"
                                                but_meta="btn btn-danger"
                                                is_btn_primary=false
                                                but_name="dispatch[ap_safecache.cf_backup_delete_cache]"
                                                but_text=__("ap_safecache.cf_btn_delete_backup")
                                                but_confirm_text=__("ap_safecache.cf_confirm_delete_backup_cache", ["[gen]" => $bf.generation|escape])
                                            }
                                        </form>
                                    </td>
                                </tr>
                            {/foreach}
                        </tbody>
                    </table>
                </div>
            {else}
                <p class="muted">{__("ap_safecache.cf_backup_empty_cache")}</p>
            {/if}
            {else}
            <p class="muted">{__("ap_safecache.license_pro_feature_note")}</p>
            {/if}
            </div>
        </div>
    </div>
</div>
