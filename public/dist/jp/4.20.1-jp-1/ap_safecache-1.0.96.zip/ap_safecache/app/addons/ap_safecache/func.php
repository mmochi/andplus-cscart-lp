<?php

// *** 関数名の命名ルール ***
// 混乱を避けるため、フックポイントで動作する関数とその他の命名ルールを明確化する。
// (1) init.phpで定義ししたフックポイントで動作する関数：fn_[アドオンID]_[フックポイント名]
// (2) addons.xmlで定義した設定項目で動作する関数：fn_settings_variants_addons_[アドオンID]_[アイテムID]
// (3) (1)以外の関数：fn_[アドオンID]_[任意の名称]

if (!defined('BOOTSTRAP')) { die('Access denied'); }

use Tygh\Ajax;
use Tygh\BlockManager\Block;
use Tygh\BlockManager\Layout;
use Tygh\BlockManager\Location;
use Tygh\BlockManager\SchemesManager;
use Tygh\Http;
use Tygh\Registry;
use Tygh\Settings;
use Tygh\Tygh;

if (!defined('AP_SAFECACHE_CF_PURGE_MAX_FILES_PER_REQUEST')) {
    define('AP_SAFECACHE_CF_PURGE_MAX_FILES_PER_REQUEST', 30);
    define('AP_SAFECACHE_CF_PURGE_MAX_URLS_TOTAL', 500);
}

if (!defined('AP_SAFECACHE_CF_BACKUP_MAX_GENERATIONS')) {
    /** Cloudflare 設定バックアップのゾーンあたり最大保持世代数 */
    define('AP_SAFECACHE_CF_BACKUP_MAX_GENERATIONS', 20);
}

require_once __DIR__ . '/lib/ap_safecache_remote_addr.php';
require_once __DIR__ . '/lib/ap_safecache_cf_fingerprint.php';
require_once __DIR__ . '/lib/ap_safecache_freemius.php';
require_once __DIR__ . '/lib/ap_safecache_license_action_token.php';
require_once __DIR__ . '/cloudflare_rules.php';
require_once __DIR__ . '/cf_cache_recommendations.php';
require_once __DIR__ . '/ap_safecache_cache_tags.php';
require_once __DIR__ . '/ap_safecache_purge_everything.php';
require_once __DIR__ . '/ap_safecache_purge_queue.php';

/**
 * チェックボックス設定値を「オン」とみなすか（Y / 1 / true 等）。
 *
 * @param mixed $value
 *
 * @return bool
 */
function fn_ap_safecache_setting_value_is_yes($value)
{
    if ($value === true || $value === 1) {
        return true;
    }
    if ($value === false || $value === null) {
        return false;
    }

    $s = strtoupper(trim((string) $value));

    return $s === 'Y' || $s === '1' || $s === 'YES' || $s === 'ON' || $s === 'TRUE';
}

/**
 * log_ajax_block_reload の生の値を取得（getValue の company/storefront 差異を吸収）。
 *
 * @return mixed
 */
function fn_ap_safecache_get_log_ajax_block_reload_setting_value()
{
    $pairs = [
        [null, null],
        [null, 0],
        [0, 0],
    ];

    foreach ($pairs as $pair) {
        $v = Settings::instance()->getValue('log_ajax_block_reload', 'ap_safecache', $pair[0], $pair[1]);
        if ($v !== false) {
            return $v;
        }
    }

    return false;
}

/**
 * Ajax ブロック再読み込みの追跡ログを有効にするか。
 * config.local.php で define('AP_SAFECACHE_LOG_AJAX_BLOCK_RELOAD', true); するか、
 * アドオン設定「log_ajax_block_reload」をオンにする。
 *
 * @return bool
 */
function fn_ap_safecache_is_ajax_block_reload_logging_enabled()
{
    if (defined('AP_SAFECACHE_LOG_AJAX_BLOCK_RELOAD') && AP_SAFECACHE_LOG_AJAX_BLOCK_RELOAD) {
        return true;
    }

    if (!fn_ap_safecache_is_pro()) {
        return false;
    }

    fn_ap_safecache_ensure_addon_settings_objects_registered();

    return fn_ap_safecache_setting_value_is_yes(fn_ap_safecache_get_log_ajax_block_reload_setting_value());
}

/**
 * レイアウトブロックの初回再読み込みを Intersection Observer で遅延するか（既定: オン）。
 *
 * @return bool
 */
function fn_ap_safecache_lazy_reload_layout_blocks_enabled()
{
    fn_ap_safecache_ensure_addon_settings_objects_registered();

    $v = Settings::instance()->getValue('lazy_reload_layout_blocks', 'ap_safecache', null, 0);
    if ($v === false || $v === null || $v === '') {
        return true;
    }

    return fn_ap_safecache_setting_value_is_yes($v);
}

/**
 * 追跡ログ用の現在時刻（日本時間・ISO 8601、例: 2026-04-12T22:55:08+09:00）。
 *
 * @return string
 */
function fn_ap_safecache_log_now_iso8601_jst()
{
    try {
        $dt = new \DateTimeImmutable('now', new \DateTimeZone('Asia/Tokyo'));

        return $dt->format('c');
    } catch (\Exception $e) {
        return gmdate('c');
    }
}

/**
 * 店頭ブロック再取得の再現用ログを var/log/ap_safecache_ajax_block_reload.log に JSON 1 行で追記する。
 *
 * @param string               $phase   page_assign | block_manager_render など
 * @param array<string, mixed> $context 追加コンテキスト
 */
function fn_ap_safecache_log_ajax_block_reload_event($phase, array $context = [])
{
    if (!fn_ap_safecache_is_ajax_block_reload_logging_enabled()) {
        return;
    }

    $root = defined('DIR_ROOT') ? DIR_ROOT : Registry::get('config.dir.root');
    if (!is_string($root) || $root === '') {
        return;
    }

    $dir = rtrim($root, '/\\') . '/var/log';
    if (!is_dir($dir)) {
        fn_mkdir($dir);
    }

    $path = $dir . '/ap_safecache_ajax_block_reload.log';
    $row = array_merge(
        [
            'ts'    => fn_ap_safecache_log_now_iso8601_jst(),
            'phase' => (string) $phase,
            'area'  => defined('AREA') ? AREA : '',
        ],
        $context
    );

    $line = json_encode($row, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";
    if (file_put_contents($path, $line, FILE_APPEND | LOCK_EX) === false) {
        error_log('ap_safecache: failed to write ajax block reload log: ' . $path);
    }
}

/**
 * GET dispatch=ap_safecache.cron_cf_poll（サーバ cron / wget 用）。本文は text/plain。
 * アドオン設定で「CF ポールの cron を許可」がオンかつ cron 用パスワードが設定されているときのみ、cron_password 一致で実行する。
 *
 * @return void
 */
function fn_ap_safecache_cf_poll_cron_http_response()
{
    if (!defined('AREA') || AREA !== 'A') {
        http_response_code(403);
        header('Content-Type: text/plain; charset=UTF-8');
        echo 'ERROR: ' . __('access_denied');

        return;
    }

    header('Content-Type: text/plain; charset=UTF-8');

    $addon = Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];

    if (!fn_ap_safecache_setting_value_is_yes($addon['cf_poll_cron_enable'] ?? 'N')) {
        http_response_code(403);
        echo 'ERROR: ' . __('ap_safecache.cf_poll_cron_err_disabled');

        return;
    }

    if (!fn_ap_safecache_is_pro()) {
        http_response_code(403);
        echo 'ERROR: ' . __('ap_safecache.license_pro_only');

        return;
    }

    $stored = isset($addon['cf_poll_cron_password']) ? trim((string) $addon['cf_poll_cron_password']) : '';
    if ($stored === '') {
        http_response_code(503);
        echo 'ERROR: ' . __('ap_safecache.cf_poll_cron_err_password_not_set');

        return;
    }

    $req = isset($_REQUEST['cron_password']) ? (string) $_REQUEST['cron_password'] : '';
    if (!hash_equals($stored, $req)) {
        http_response_code(403);
        echo 'ERROR: ' . __('access_denied');

        return;
    }

    list($ok, $msg) = fn_ap_safecache_cf_poll_live_now('cron');
    if ($ok) {
        echo 'OK: ' . $msg;
    } else {
        http_response_code(500);
        echo 'ERROR: ' . $msg;
    }
}

/**
 * GET dispatch=ap_safecache.cron_freemius_sync（サーバ cron / wget 用）。本文は text/plain。
 * 既存の cf_poll 用 cron 設定（enable/password）を共用して、Freemius ライセンス状態を強制再同期する。
 *
 * @return void
 */
function fn_ap_safecache_freemius_sync_cron_http_response()
{
    if (!defined('AREA') || AREA !== 'A') {
        http_response_code(403);
        header('Content-Type: text/plain; charset=UTF-8');
        echo 'ERROR: ' . __('access_denied');

        return;
    }

    header('Content-Type: text/plain; charset=UTF-8');

    $addon = Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];

    if (!fn_ap_safecache_setting_value_is_yes($addon['cf_poll_cron_enable'] ?? 'N')) {
        http_response_code(403);
        echo 'ERROR: cron is disabled';

        return;
    }

    $stored = isset($addon['cf_poll_cron_password']) ? trim((string) $addon['cf_poll_cron_password']) : '';
    if ($stored === '') {
        http_response_code(503);
        echo 'ERROR: cron password is not set';

        return;
    }

    $req = isset($_REQUEST['cron_password']) ? (string) $_REQUEST['cron_password'] : '';
    if (!hash_equals($stored, $req)) {
        http_response_code(403);
        echo 'ERROR: ' . __('access_denied');

        return;
    }

    if (!function_exists('fn_ap_safecache_freemius_sync_license')) {
        http_response_code(500);
        echo 'ERROR: freemius sync function is unavailable';

        return;
    }

    list($ok, $msg) = fn_ap_safecache_freemius_sync_license([
        'auto' => true,
        'force' => true,
    ]);

    if ($ok) {
        echo 'OK: ' . $msg;
    } else {
        http_response_code(500);
        echo 'ERROR: ' . $msg;
    }
}

/**
 * Smarty が実際に読む manage.tpl の絶対パス（addon の overrides があれば、有効アドオン列の後勝ちで最後の1件）。
 *
 * @return string
 */
function fn_ap_safecache_manage_resolve_effective_manage_tpl_path()
{
    $design = rtrim((string) Registry::get('config.dir.design_backend'), '/\\') . '/';
    $winner = '';

    foreach (Registry::get('addons') as $addon_name => $settings) {
        if (empty($settings['status']) || $settings['status'] !== 'A') {
            continue;
        }
        $candidate = $design . 'templates/addons/' . $addon_name . '/overrides/addons/ap_safecache/views/ap_safecache/manage.tpl';
        if (is_file($candidate)) {
            $winner = $candidate;
        }
    }

    if ($winner !== '') {
        return $winner;
    }

    return $design . 'templates/addons/ap_safecache/views/ap_safecache/manage.tpl';
}

/**
 * 実効 manage.tpl に Cloudflare ポール用アンカーが無いとき、管理画面に警告を出す（誤配置・古い overrides の切り分け用）。
 */
function fn_ap_safecache_manage_notify_if_tpl_missing_cf_poll()
{
    if (!defined('AREA') || AREA !== 'A') {
        return;
    }

    $path = fn_ap_safecache_manage_resolve_effective_manage_tpl_path();
    if (!is_file($path)) {
        fn_set_notification(
            'E',
            __('ap_safecache.cf_notification_title'),
            __('ap_safecache.err_manage_tpl_missing', ['[path]' => $path])
        );

        return;
    }

    $raw = @file_get_contents($path);
    if ($raw === false || strpos($raw, 'ap-safecache-cf-poll') === false) {
        fn_set_notification(
            'W',
            __('ap_safecache.cf_notification_title'),
            __('ap_safecache.warn_manage_tpl_no_cf_poll', ['[path]' => $path])
        );
    }
}

/**
 * manage のスクロール用 id に対応するタブ（safecache_tab クエリ値）。
 *
 * @param string $focus_id 許可リスト内の HTML id
 *
 * @return string overview|rules|monitor|cache|advanced
 */
function fn_ap_safecache_manage_focus_id_to_tab($focus_id)
{
    static $map = [
        'ap-safecache-connection'            => 'overview',
        'ap-safecache-site'                  => 'advanced',
        'ap-safecache-cf-sync'               => 'rules',
        'ap-safecache-cf-poll'               => 'monitor',
        'ap-safecache-cf-recommended'        => 'rules',
        'ap-safecache-cf-editor'             => 'rules',
        'ap-safecache-cf-cache-rules-anchor' => 'rules',
        'ap-safecache-cf-backup'             => 'cache',
        'ap-safecache-purge'                 => 'cache',
        'ap-safecache-diagnostics'           => 'monitor',
        'ap-safecache-license-funnel'        => 'overview',
    ];

    $id = trim((string) $focus_id);

    return isset($map[$id]) ? $map[$id] : 'overview';
}

/**
 * manage 画面へリダイレクト（タブ safecache_tab、スクロール用 safecache_focus と #fragment）。
 *
 * @param string $focus_id 許可リスト内の HTML id（ap-safecache-*）
 *
 * @return string
 */
function fn_ap_safecache_manage_redirect_url($focus_id = '')
{
    static     $allowed = [
        'ap-safecache-connection',
        'ap-safecache-site',
        'ap-safecache-cf-sync',
        'ap-safecache-cf-poll',
        'ap-safecache-cf-recommended',
        'ap-safecache-cf-editor',
        'ap-safecache-cf-cache-rules-anchor',
        'ap-safecache-cf-backup',
        'ap-safecache-purge',
        'ap-safecache-diagnostics',
        'ap-safecache-license-funnel',
    ];

    $id = trim((string) $focus_id);
    if ($id === '' || !in_array($id, $allowed, true)) {
        return 'ap_safecache.manage';
    }

    $tab = fn_ap_safecache_manage_focus_id_to_tab($id);

    $sf = isset($_REQUEST['safecache_sf']) ? (int) $_REQUEST['safecache_sf'] : 0;
    $sf_q = $sf > 0 ? '&safecache_sf=' . $sf : '';

    return 'ap_safecache.manage?safecache_tab=' . rawurlencode($tab)
        . '&safecache_focus=' . rawurlencode($id) . $sf_q . '#' . $id;
}

//install関数
function fn_ap_safecache_install()
{
    fn_ap_safecache_cf_ensure_backup_table();
    fn_ap_safecache_cf_ensure_poll_tables();
    fn_ap_safecache_cf_purge_queue_ensure_table();
}

function fn_ap_safecache_uninstall()
{
    db_query('DROP TABLE IF EXISTS ?:ap_safecache_cf_page_backups');
    db_query('DROP TABLE IF EXISTS ?:ap_safecache_cf_cache_backups');
    db_query('DROP TABLE IF EXISTS ?:ap_safecache_cf_backups');
    db_query('DROP TABLE IF EXISTS ?:ap_safecache_cf_poll_log');
    db_query('DROP TABLE IF EXISTS ?:ap_safecache_cf_poll_state');
    db_query('DROP TABLE IF EXISTS ?:ap_safecache_cf_purge_jobs');
}

/**
 * アドオン設定または Freemius 連携によるエディション（free / pro）。
 * **ライセンスキーが空のときは常に free**（隠し license_tier に依存しない）。
 * Multi-Vendor 本体では Freemius プラン **promv** のみ Pro。ULTIMATE では pross / promv / pro（下位互換）。
 * キーあり・Freemius 利用時は API 同期結果を優先し、手動 license_tier は無視。
 * キーあり・Freemius 未使用時のみ手動 license_tier（未設定・不正値は pro）。
 *
 * @return string 'free'|'pro'
 */
function fn_ap_safecache_get_license_tier()
{
    $addon = Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];

    $license_key = function_exists('fn_ap_safecache_freemius_get_license_key_trimmed')
        ? fn_ap_safecache_freemius_get_license_key_trimmed()
        : (isset($addon['freemius_license_key']) ? trim((string) $addon['freemius_license_key']) : '');
    if ($license_key === '') {
        return 'free';
    }

    if (function_exists('fn_ap_safecache_freemius_resolve_tier_or_null')) {
        $fs_tier = fn_ap_safecache_freemius_resolve_tier_or_null();
        if ($fs_tier !== null) {
            return $fs_tier;
        }
    }

    $v = isset($addon['license_tier']) ? strtolower(trim((string) $addon['license_tier'])) : 'pro';

    if ($v !== 'free' && $v !== 'pro') {
        return 'pro';
    }

    return $v;
}

/**
 * Pro エディション（書き込み・運用系）か。
 *
 * @return bool
 */
function fn_ap_safecache_is_pro()
{
    return fn_ap_safecache_get_license_tier() === 'pro';
}

/**
 * 拡張機能（Cloudflare への適用など）がライセンス上利用可能か。
 * Freemius 連携後はプラン判定に差し替え可能（本関数を集約点にする）。
 *
 * @return bool
 */
function fn_ap_safecache_is_extension_licensed()
{
    return fn_ap_safecache_is_pro();
}

/**
 * Pro 書き込み直前に Freemius を短周期で再検証する（管理 POST の取りこぼし対策）。
 *
 * @return array{0: bool, 1: string} [ok, message]
 */
function fn_ap_safecache_ensure_freemius_for_pro_write()
{
    if (!function_exists('fn_ap_safecache_freemius_is_enabled') || !function_exists('fn_ap_safecache_freemius_sync_license')) {
        return [true, ''];
    }
    if (!fn_ap_safecache_freemius_is_enabled()) {
        return [true, ''];
    }

    $license_key = function_exists('fn_ap_safecache_freemius_get_license_key_trimmed')
        ? fn_ap_safecache_freemius_get_license_key_trimmed()
        : '';
    if ($license_key === '') {
        return [false, __('ap_safecache.license_pro_only')];
    }

    $cooldown = defined('AP_SAFECACHE_FREEMIUS_PRO_WRITE_SYNC_COOLDOWN_SEC')
        ? (int) AP_SAFECACHE_FREEMIUS_PRO_WRITE_SYNC_COOLDOWN_SEC
        : 300;
    if ($cooldown < 0) {
        $cooldown = 300;
    }

    $addon = function_exists('fn_ap_safecache_freemius_get_addon_row')
        ? fn_ap_safecache_freemius_get_addon_row()
        : Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];
    $state = function_exists('fn_ap_safecache_freemius_decode_state')
        ? fn_ap_safecache_freemius_decode_state(isset($addon['freemius_state_json']) ? (string) $addon['freemius_state_json'] : '')
        : [];
    $last_sync = isset($state['last_pro_write_sync_at']) ? (int) $state['last_pro_write_sync_at'] : 0;

    if ($last_sync > 0 && (time() - $last_sync) < $cooldown) {
        return fn_ap_safecache_is_pro()
            ? [true, '']
            : [false, __('ap_safecache.license_pro_only')];
    }

    // ゲートウェイ有効時はトークン取得側で activate を行うため、ここで force すると同一リクエスト内で
    // Freemius activate が二重になり、枠・URL ゆれまわりのエッジで license_utilized が出やすい。
    // ゲートウェイ無効時のみ従来どおり force でリモート再検証する。
    $gateway_on = function_exists('fn_ap_safecache_license_action_token_gateway_configured')
        && fn_ap_safecache_license_action_token_gateway_configured();
    list($ok, $msg) = fn_ap_safecache_freemius_sync_license([
        'auto'  => true,
        'force' => !$gateway_on,
    ]);

    // sync_license 内で freemius_state_json を更新済み。ここで同期前の $state を保存すると
    // license_expired 等で落とした last_plan_slug が古い Pro に戻るため、必ず保存後の状態を読み直す。
    if (function_exists('fn_ap_safecache_freemius_save_state') && function_exists('fn_ap_safecache_freemius_decode_state')) {
        $addon_after = function_exists('fn_ap_safecache_freemius_get_addon_row')
            ? fn_ap_safecache_freemius_get_addon_row()
            : [];
        $addon_after = is_array($addon_after) ? $addon_after : [];
        $state_after = fn_ap_safecache_freemius_decode_state(isset($addon_after['freemius_state_json']) ? (string) $addon_after['freemius_state_json'] : '');
        $state_after['last_pro_write_sync_at'] = time();
        fn_ap_safecache_freemius_save_state($state_after);
    }

    if (!$ok) {
        return [false, $msg];
    }
    if (!fn_ap_safecache_is_pro()) {
        return [false, __('ap_safecache.license_pro_only')];
    }

    return [true, ''];
}

/**
 * Free のとき管理画面 POST をリダイレクトで弾く。
 *
 * @param string $safecache_focus_id ap_safecache_manage_redirect_url 用フォーカス ID
 *
 * @return array|null [CONTROLLER_STATUS_REDIRECT, url] または null（Pro）
 */
function fn_ap_safecache_license_pro_redirect_or_null($safecache_focus_id)
{
    list($guard_ok, $guard_msg) = fn_ap_safecache_ensure_freemius_for_pro_write();
    if (!$guard_ok) {
        fn_set_notification(
            'E',
            __('ap_safecache.notification_title_license'),
            $guard_msg !== '' ? $guard_msg : __('ap_safecache.license_pro_only')
        );

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url($safecache_focus_id)];
    }

    if (fn_ap_safecache_is_pro()) {
        return null;
    }

    fn_set_notification('E', __('ap_safecache.notification_title_license'), __('ap_safecache.license_pro_only'));

    return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url($safecache_focus_id)];
}

/**
 * アドオン設定保存後、ライセンスキー欄が送信されていれば Freemius activate を実行（キー保存直後は Registry が未更新のため同期内で Settings を参照する）。
 *
 * @param array<string, mixed> $settings
 * @param int|null             $storefront_id
 */
function fn_ap_safecache_update_addon_post($settings, $storefront_id)
{
    if (empty($_REQUEST['addon']) || (string) $_REQUEST['addon'] !== 'ap_safecache') {
        return;
    }
    if (empty($settings['options']) || !is_array($settings['options'])) {
        return;
    }
    $kid = (int) Settings::instance()->getId('freemius_license_key', 'ap_safecache');
    if ($kid <= 0 || !array_key_exists($kid, $settings['options'])) {
        return;
    }
    $key = trim((string) $settings['options'][$kid]);
    if ($key === '') {
        return;
    }
    if (!function_exists('fn_ap_safecache_freemius_sync_license') || !function_exists('fn_ap_safecache_freemius_is_enabled')) {
        return;
    }
    if (!fn_ap_safecache_freemius_is_enabled()) {
        return;
    }

    list($ok, $msg) = fn_ap_safecache_freemius_sync_license();
    fn_set_notification($ok ? 'N' : 'E', __('ap_safecache.notification_title_license'), $msg);
}

/**
 * 管理画面: 決済ゲートウェイの IP 登録と Cloudflare の注意喚起用。
 * 現在のリクエストで PHP が見ている REMOTE_ADDR と CF 系ヘッダを返す（診断の目安）。
 *
 * @return array<string, bool|string>
 */
function fn_ap_safecache_get_payment_ip_context_for_manage()
{
    $remote = isset($_SERVER['REMOTE_ADDR']) ? trim((string) $_SERVER['REMOTE_ADDR']) : '';
    $cf = '';
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $cf = trim((string) $_SERVER['HTTP_CF_CONNECTING_IP']);
    }
    $true_client = '';
    if (!empty($_SERVER['HTTP_TRUE_CLIENT_IP'])) {
        $true_client = trim((string) $_SERVER['HTTP_TRUE_CLIENT_IP']);
    }

    return [
        'remote_addr'            => $remote,
        'cf_connecting_ip'       => $cf,
        'true_client_ip'         => $true_client,
        'has_distinct_client_ip' => ($cf !== '' && $cf !== $remote) || ($true_client !== '' && $true_client !== $remote),
    ];
}

/**
 * 管理画面表示用: バージョン・エディション・ストアフロント数などのスナップショット。
 *
 * @return array<string, int|string>
 */
function fn_ap_safecache_get_environment_snapshot()
{
    $storefront_count = (int) db_get_field('SELECT COUNT(*) FROM ?:storefronts');

    return [
        'product_version'  => defined('PRODUCT_VERSION') ? (string) PRODUCT_VERSION : '',
        'product_edition'    => defined('PRODUCT_EDITION') ? (string) PRODUCT_EDITION : '',
        'product_build'      => defined('PRODUCT_BUILD') ? (string) PRODUCT_BUILD : '',
        'storefront_count'   => $storefront_count,
    ];
}

/**
 * 管理画面用: アドオン設定の要約（API トークンはマスク）。
 *
 * @return array<string, bool|string>
 */
function fn_ap_safecache_get_settings_display()
{
    $addon = Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];

    $base = isset($addon['recommendation_api_base_url']) ? trim((string) $addon['recommendation_api_base_url']) : '';
    $zone = isset($addon['cloudflare_zone_id']) ? trim((string) $addon['cloudflare_zone_id']) : '';
    $token = isset($addon['cloudflare_api_token']) ? (string) $addon['cloudflare_api_token'] : '';

    return [
        'recommendation_api_base_url' => $base,
        'cloudflare_zone_id'          => $zone,
        'cloudflare_api_token_set'    => ($token !== ''),
        'ajax_reload_block_count'         => count(fn_ap_safecache_get_ajax_reload_block_ids()),
        'ajax_reload_dom_id_manage_count' => count(fn_ap_safecache_get_ajax_reload_dom_ids_manage()),
        'ajax_reload_dom_id_merged_count' => count(fn_ap_safecache_get_ajax_reload_dom_ids_merged()),
        'restore_remote_addr_from_cf' => fn_ap_safecache_setting_value_is_yes($addon['restore_remote_addr_from_cf'] ?? 'N'),
        'license_tier'                => fn_ap_safecache_get_license_tier(),
    ];
}

/**
 * get_route: Cloudflare エッジ経由のときのみ、REMOTE_ADDR を CF-Connecting-IP（等）に合わせる。
 *
 * コアの pay_read.php 等は本アドオンで変更しない。巻き戻しは lib/ap_safecache_remote_addr.php 冒頭のコメント参照。
 *
 * @param array $req
 * @param array $result
 * @param string $area
 * @param bool $is_allowed_url
 */
function fn_ap_safecache_get_route(&$req, &$result, $area, $is_allowed_url)
{
    // get_route は init 序盤で走り得る。ensure_addon_settings は Settings が CART_LANGUAGE
    // を要求するためここでは呼ばない（Registry の addons.ap_safecache で十分）。
    $addon = Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];

    if (!fn_ap_safecache_setting_value_is_yes($addon['restore_remote_addr_from_cf'] ?? 'N')) {
        return;
    }

    if (!fn_ap_safecache_is_pro()) {
        return;
    }

    fn_ap_safecache_apply_remote_addr_from_cloudflare();
}

/**
 * 店頭の block_manager.render が XHR かどうか（ログイン後 return_url 等の通常 GET では false）。
 *
 * fn_init_ajax は is_ajax 等だけで Tygh::$app['ajax'] を作るため、validateRequest だけでは「ページ遷移」と区別できない。
 *
 * @return bool
 */
function fn_ap_safecache_is_xml_http_request()
{
    return isset($_SERVER['HTTP_X_REQUESTED_WITH'])
        && strcasecmp((string) $_SERVER['HTTP_X_REQUESTED_WITH'], 'XMLHttpRequest') === 0;
}

/**
 * 店頭 block_manager.render で Tygh::$app['ajax'] が未登録のときだけ補う。
 *
 * before_dispatch で「XHR でない GET」はリダイレクト済み。POST で is_ajax があるがヘッダ欠落のときも補う。
 *
 * fn_init_ajax はまれに ajax が無い状態が残る場合の保険。is_ajax を付与しないと destruct が JSON を出さない。
 *
 * @param string $area       エリア（C / A 等）
 * @param string $controller コントローラ名
 * @param string $mode       モード名
 */
function fn_ap_safecache_ensure_ajax_for_block_manager_render($area, $controller, $mode)
{
    if ($area !== 'C' || $controller !== 'block_manager' || $mode !== 'render') {
        return;
    }

    if (Tygh::$app->has('ajax')) {
        return;
    }

    if (!Ajax::validateRequest($_REQUEST)) {
        return;
    }

    $method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper((string) $_SERVER['REQUEST_METHOD']) : 'GET';
    if (!fn_ap_safecache_is_xml_http_request() && $method === 'GET') {
        return;
    }

    $ajax_request = $_REQUEST;
    if (
        empty($ajax_request['is_ajax'])
        && (empty($ajax_request['callback']) || empty($ajax_request['result_ids']))
    ) {
        $ajax_request['is_ajax'] = Ajax::REQUEST_XML;
    }

    Tygh::$app['ajax'] = new Ajax($ajax_request);

    if (!defined('AJAX_REQUEST')) {
        fn_define('AJAX_REQUEST', true);
    }
}

/**
 * get_route_runtime: フックキャッシュに古い登録が残る場合があるため呼び出し可能な空実装を残す。
 * block_manager.render の処理は before_dispatch に集約。
 *
 * @param array  $req
 * @param string $area
 * @param array  $result
 * @param bool   $is_allowed_url
 * @param string $controller
 * @param string $mode
 * @param string $action
 * @param string $dispatch_extra
 * @param array  $current_url_params
 * @param string $current_url
 */
function fn_ap_safecache_get_route_runtime(&$req, &$area, &$result, &$is_allowed_url, &$controller, &$mode, &$action, &$dispatch_extra, &$current_url_params, &$current_url)
{
}

/**
 * before_dispatch: 店頭 block_manager.render は「XHR でない GET」では JSON を返さず redirect_url へ送る。
 *
 * is_ajax だけで fn_init_ajax が ajax を作るため has('ajax') では判定できない。ログイン／ログアウト後の return_url が
 * block_manager.render を指しても、通常 GET では X-Requested-With が付かないのでここでリダイレクトする。
 *
 * POST（ap_safecache の reloadBlock / ceAjax 等）は同一オリジンでも X-Requested-With が欠ける環境があり得るため、
 * GET とのみ区別して処理を続行する（multipart 送信後のブロック差し替え・商品フォーム再生成用）。
 *
 * @param string $controller
 * @param string $mode
 * @param string $action
 * @param string $dispatch_extra
 * @param string $area
 */
function fn_ap_safecache_before_dispatch($controller, $mode, $action, $dispatch_extra, $area)
{
    if ($area !== 'C' || $controller !== 'block_manager' || $mode !== 'render') {
        return;
    }

    $method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper((string) $_SERVER['REQUEST_METHOD']) : 'GET';

    if (!fn_ap_safecache_is_xml_http_request() && $method === 'GET') {
        $target = !empty($_REQUEST['redirect_url']) ? trim((string) $_REQUEST['redirect_url']) : '';
        if ($target !== '') {
            fn_redirect($target, false, false);
        }
        fn_redirect(fn_url(), false, false);
    }

    fn_ap_safecache_ensure_ajax_for_block_manager_render($area, $controller, $mode);
}

/**
 * 疎通結果を管理画面の標準通知（fn_set_notification）で表示する。
 *
 * @param bool   $success 成功時は N（notice）、失敗時は E（error）
 * @param string $title   翻訳済み見出し
 * @param string $message 翻訳済み本文
 */
function fn_ap_safecache_set_ping_notification($success, $title, $message)
{
    fn_set_notification($success ? 'N' : 'E', $title, $message);
}

/**
 * 推奨ルール API（設定のベース URL）への HTTPS GET で疎通確認。結果は fn_set_notification で表示。
 *
 * @return bool 成功した場合 true
 */
function fn_ap_safecache_ping_recommendation_api()
{
    $notification_title = __('ap_safecache.notification_title_recommendation');

    $addon = Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];
    $url = isset($addon['recommendation_api_base_url']) ? trim((string) $addon['recommendation_api_base_url']) : '';

    if ($url === '') {
        fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_url_required'));

        return false;
    }

    if (!filter_var($url, FILTER_VALIDATE_URL) || stripos($url, 'https://') !== 0) {
        fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_https_url_required'));

        return false;
    }

    $extra = [
        'timeout' => 15,
        'headers' => [
            'Accept: application/json, text/plain, */*',
            'User-Agent: AP-SafeCache/' . (defined('PRODUCT_VERSION') ? (string) PRODUCT_VERSION : '1'),
        ],
    ];

    $body = Http::get($url, [], $extra);
    $status = (int) Http::getStatus();

    if ($body === false) {
        fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_http_request_failed'));

        return false;
    }

    if ($status < 200 || $status >= 300) {
        fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_http_status', ['[status]' => (string) $status]));

        return false;
    }

    fn_ap_safecache_set_ping_notification(true, $notification_title, __('ap_safecache.ok_recommendation_ping', ['[status]' => (string) $status]));

    return true;
}

/**
 * Cloudflare API トークン検証（verify）と、任意でゾーン ID の取得確認。結果は fn_set_notification で表示。
 *
 * @return bool 成功した場合 true
 */
function fn_ap_safecache_ping_cloudflare()
{
    $notification_title = __('ap_safecache.notification_title_cloudflare');

    $addon = Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];
    $token = isset($addon['cloudflare_api_token']) ? trim((string) $addon['cloudflare_api_token']) : '';
    $zone_id = isset($addon['cloudflare_zone_id']) ? trim((string) $addon['cloudflare_zone_id']) : '';

    if ($token === '') {
        fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_cf_token_required'));

        return false;
    }

    $verify_url = 'https://api.cloudflare.com/client/v4/user/tokens/verify';
    $extra = [
        'timeout' => 15,
        'headers' => [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
        ],
    ];

    $body = Http::get($verify_url, [], $extra);

    if ($body === false) {
        fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_http_request_failed'));

        return false;
    }

    $data = json_decode($body, true);
    if (!is_array($data) || empty($data['success'])) {
        $detail = '';
        if (is_array($data) && !empty($data['errors'][0]['message'])) {
            $detail = ' ' . (string) $data['errors'][0]['message'];
        }

        fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_cf_token_invalid') . $detail);

        return false;
    }

    if ($zone_id === '') {
        fn_ap_safecache_set_ping_notification(true, $notification_title, __('ap_safecache.ok_cf_token_zone_skipped'));

        return true;
    }

    $zone_url = 'https://api.cloudflare.com/client/v4/zones/' . rawurlencode($zone_id);
    $body_zone = Http::get($zone_url, [], $extra);

    if ($body_zone === false) {
        fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_http_request_failed'));

        return false;
    }

    $zone_data = json_decode($body_zone, true);
    if (!is_array($zone_data) || empty($zone_data['success'])) {
        $detail = '';
        if (is_array($zone_data) && !empty($zone_data['errors'][0]['message'])) {
            $detail = ' ' . (string) $zone_data['errors'][0]['message'];
        }

        fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_cf_zone_invalid') . $detail);

        return false;
    }

    $zone_name = '';
    if (!empty($zone_data['result']['name'])) {
        $zone_name = (string) $zone_data['result']['name'];
    }

    fn_ap_safecache_set_ping_notification(true, $notification_title, __('ap_safecache.ok_cf_zone', ['[zone]' => $zone_name !== '' ? $zone_name : $zone_id]));

    return true;
}

/**
 * Cloudflare purge_cache を JSON で呼び出す。通知は呼び出し側。
 *
 * @param string               $token   API トークン
 * @param string               $zone_id ゾーン ID
 * @param array<string, mixed> $body    purge_everything または files 等
 *
 * @return array{0: bool, 1: string} [成功, 失敗時の翻訳済みメッセージ]
 */
function fn_ap_safecache_cloudflare_purge_post($token, $zone_id, array $body)
{
    $purge_url = 'https://api.cloudflare.com/client/v4/zones/' . rawurlencode($zone_id) . '/purge_cache';
    $payload = json_encode($body, JSON_UNESCAPED_SLASHES);
    $extra = [
        'timeout' => 30,
        'headers' => [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
        ],
    ];

    $response = Http::post($purge_url, $payload, $extra);
    $status = (int) Http::getStatus();

    if ($response === false) {
        return [false, __('ap_safecache.err_http_request_failed')];
    }

    $data = json_decode($response, true);

    if ($status < 200 || $status >= 300) {
        $detail = '';
        if (is_array($data) && !empty($data['errors'][0]['message'])) {
            $detail = ' ' . (string) $data['errors'][0]['message'];
        }

        return [false, __('ap_safecache.err_http_status', ['[status]' => (string) $status]) . $detail];
    }

    if (!is_array($data) || empty($data['success'])) {
        $detail = '';
        if (is_array($data) && !empty($data['errors'][0]['message'])) {
            $detail = ' ' . (string) $data['errors'][0]['message'];
        }

        return [false, __('ap_safecache.err_cf_purge_failed') . $detail];
    }

    return [true, ''];
}

/**
 * テキストからパージ対象 URL のリストを得る（改行・カンマ区切り、重複除去）。
 *
 * @return list<string>
 */
function fn_ap_safecache_parse_purge_url_list($raw)
{
    $raw = (string) $raw;
    $parts = preg_split('/[\r\n,]+/', $raw, -1, PREG_SPLIT_NO_EMPTY);
    $out = [];

    foreach ($parts as $p) {
        $u = trim((string) $p);
        if ($u === '') {
            continue;
        }
        if (!in_array($u, $out, true)) {
            $out[] = $u;
        }
    }

    return $out;
}

/**
 * Cloudflare ゾーンのエッジキャッシュを全削除（purge_everything）。結果は fn_set_notification で表示。
 *
 * @return bool 成功した場合 true
 */
function fn_ap_safecache_purge_cloudflare_cache()
{
    $r = fn_ap_safecache_purge_everything_scheduled(AP_SAFECACHE_PURGE_EVERYTHING_SRC_MANAGE_BUTTON, [
        'bypass_throttle' => true,
    ]);

    return $r['status'] === 'ok';
}

/**
 * 指定 URL のみエッジキャッシュをパージ（files）。API 制限により 30 件ずつ送信。結果は fn_set_notification で表示。
 *
 * @param string $raw 改行・カンマ区切りの URL 一覧
 *
 * @return bool 成功した場合 true
 */
function fn_ap_safecache_purge_cloudflare_cache_by_urls($raw)
{
    $notification_title = __('ap_safecache.notification_title_purge');

    if (!fn_ap_safecache_is_pro()) {
        fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.license_pro_only'));

        return false;
    }

    list($lat_ok, $lat_msg) = fn_ap_safecache_license_action_token_ensure_for_pro_write();
    if (!$lat_ok) {
        fn_ap_safecache_set_ping_notification(false, $notification_title, $lat_msg);

        return false;
    }

    $addon = Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];
    $token = isset($addon['cloudflare_api_token']) ? trim((string) $addon['cloudflare_api_token']) : '';
    $zone_id = isset($addon['cloudflare_zone_id']) ? trim((string) $addon['cloudflare_zone_id']) : '';

    if ($token === '') {
        fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_cf_token_required'));

        return false;
    }

    if ($zone_id === '') {
        fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_cf_zone_required_for_purge'));

        return false;
    }

    $urls = fn_ap_safecache_parse_purge_url_list($raw);

    if ($urls === []) {
        fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_cf_purge_urls_empty'));

        return false;
    }

    if (count($urls) > AP_SAFECACHE_CF_PURGE_MAX_URLS_TOTAL) {
        fn_ap_safecache_set_ping_notification(
            false,
            $notification_title,
            __('ap_safecache.err_cf_purge_urls_too_many', ['[max]' => (string) AP_SAFECACHE_CF_PURGE_MAX_URLS_TOTAL])
        );

        return false;
    }

    foreach ($urls as $u) {
        if (!filter_var($u, FILTER_VALIDATE_URL)) {
            fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_cf_purge_url_invalid', ['[url]' => $u]));

            return false;
        }

        $scheme = parse_url($u, PHP_URL_SCHEME);
        $scheme = is_string($scheme) ? strtolower($scheme) : '';

        if ($scheme !== 'http' && $scheme !== 'https') {
            fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_cf_purge_url_invalid', ['[url]' => $u]));

            return false;
        }
    }

    if (fn_ap_safecache_purge_queue_is_enabled()) {
        $company_id = fn_ap_safecache_purge_queue_runtime_company_id();
        if (fn_ap_safecache_purge_queue_enqueue_urls($company_id, $urls, 'admin_purge_urls', null)) {
            fn_ap_safecache_set_ping_notification(
                true,
                $notification_title,
                __('ap_safecache.ok_cf_purge_urls_queued', ['[count]' => (string) count($urls)])
            );

            return true;
        }

        fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_cf_purge_urls_queue_failed'));

        return false;
    }

    $chunks = array_chunk($urls, AP_SAFECACHE_CF_PURGE_MAX_FILES_PER_REQUEST);

    foreach ($chunks as $chunk) {
        list($ok, $err) = fn_ap_safecache_cloudflare_purge_post($token, $zone_id, ['files' => array_values($chunk)]);

        if (!$ok) {
            fn_ap_safecache_set_ping_notification(false, $notification_title, $err);

            return false;
        }
    }

    fn_ap_safecache_set_ping_notification(
        true,
        $notification_title,
        __('ap_safecache.ok_cf_purge_urls', ['[count]' => (string) count($urls)])
    );

    return true;
}

/**
 * addon.xml の設定が settings_objects に未登録のとき、fn_update_addon_settings で DB に同期する。
 * アドオン XML 更新後に再インストールしていない環境では updateValue が object_id なしで無視される。
 */
function fn_ap_safecache_ensure_addon_settings_objects_registered()
{
    static $done = false;

    if ($done) {
        return;
    }

    $ajax_reload_id = (int) Settings::instance()->getId('ajax_reload_block_ids', 'ap_safecache');
    $ajax_dom_ids_manage = (int) Settings::instance()->getId('ajax_reload_dom_ids_manage', 'ap_safecache');
    $log_reload_id = (int) Settings::instance()->getId('log_ajax_block_reload', 'ap_safecache');
    $restore_ra_id = (int) Settings::instance()->getId('restore_remote_addr_from_cf', 'ap_safecache');
    $freemius_use_id = (int) Settings::instance()->getId('freemius_use', 'ap_safecache');
    $cf_storefront_cache_tag_id = (int) Settings::instance()->getId('cf_storefront_cache_tag_enable', 'ap_safecache');

    if (
        $ajax_reload_id > 0
        && $ajax_dom_ids_manage > 0
        && $log_reload_id > 0
        && $restore_ra_id > 0
        && $freemius_use_id > 0
        && $cf_storefront_cache_tag_id > 0
    ) {
        $done = true;

        return;
    }

    static $sync_attempted = false;

    if ($sync_attempted) {
        $done = true;

        return;
    }

    $sync_attempted = true;
    $addon_id = 'ap_safecache';

    \Tygh\Addons\SchemesManager::clearInternalCache($addon_id);
    $scheme = \Tygh\Addons\SchemesManager::getScheme($addon_id);

    if (empty($scheme)) {
        $done = true;

        return;
    }

    fn_update_addon_settings(
        $scheme,
        true,
        fn_get_addon_settings_values($addon_id),
        fn_get_addon_settings_vendor_values($addon_id)
    );
    fn_clear_cache();
    Settings::instance()->reloadSections();
    $done = true;
}

/**
 * アドオン設定のカンマ区切りから Ajax 再読み込み対象ブロック ID 一覧を得る。
 *
 * @return list<int>
 */
function fn_ap_safecache_parse_ajax_reload_block_ids_raw($raw)
{
    $raw = trim((string) $raw);
    if ($raw === '') {
        return [];
    }

    $parts = preg_split('/[\s,]+/', $raw, -1, PREG_SPLIT_NO_EMPTY);
    $out = [];

    foreach ($parts as $p) {
        $i = (int) $p;
        if ($i > 0 && !in_array($i, $out, true)) {
            $out[] = $i;
        }
    }
    sort($out);

    return $out;
}

/**
 * @return list<int>
 */
function fn_ap_safecache_get_ajax_reload_block_ids()
{
    fn_ap_safecache_ensure_addon_settings_objects_registered();

    // ROOT 設定は storefront_id=0 で settings_objects。Ult 複数SF 時、null だと別テーブル／未保存と不一致になり得る。
    $raw = '';

    $from_settings = Settings::instance()->getValue('ajax_reload_block_ids', 'ap_safecache', null, 0);
    if ($from_settings !== false && $from_settings !== null && trim((string) $from_settings) !== '') {
        $raw = trim((string) $from_settings);
    } else {
        $from_settings = Settings::instance()->getValue('ajax_reload_block_ids', 'ap_safecache');
        if ($from_settings !== false && $from_settings !== null && trim((string) $from_settings) !== '') {
            $raw = trim((string) $from_settings);
        }
    }
    if ($raw === '') {
        $addon = Registry::get('addons.ap_safecache');
        $addon = is_array($addon) ? $addon : [];
        if (isset($addon['ajax_reload_block_ids']) && trim((string) $addon['ajax_reload_block_ids']) !== '') {
            $raw = trim((string) $addon['ajax_reload_block_ids']);
        }
    }

    return fn_ap_safecache_parse_ajax_reload_block_ids_raw($raw);
}

/**
 * アドオン設定のテキスト項目を取得（storefront_id=0 優先、次にフォールバック、最後に Registry の addon 配列）。
 *
 * @param string $name settings_objects の name
 *
 * @return string
 */
function fn_ap_safecache_get_addon_text_setting_value($name)
{
    $name = (string) $name;
    if ($name === '') {
        return '';
    }

    fn_ap_safecache_ensure_addon_settings_objects_registered();

    /**
     * Ultimate 等で getValue(name, section, null, 0) だけだと店頭コンテキストとずれて空になることがある。
     * 管理画面の Add-ons と同じ解決経路（セクション一括・現在 company / storefront）を最優先する。
     */
    static $ap_safecache_addon_flat_settings = null;
    if ($ap_safecache_addon_flat_settings === null) {
        $flat = Settings::instance()->getValues('ap_safecache', Settings::ADDON_SECTION, false);
        $ap_safecache_addon_flat_settings = is_array($flat) ? $flat : [];
    }
    if (isset($ap_safecache_addon_flat_settings[$name])) {
        $flat_val = $ap_safecache_addon_flat_settings[$name];
        if (!is_array($flat_val) && $flat_val !== false && $flat_val !== null && trim((string) $flat_val) !== '') {
            return trim((string) $flat_val);
        }
    }

    $from_settings = Settings::instance()->getValue($name, 'ap_safecache', null, 0);
    if ($from_settings !== false && $from_settings !== null && trim((string) $from_settings) !== '') {
        return trim((string) $from_settings);
    }
    $from_settings = Settings::instance()->getValue($name, 'ap_safecache');
    if ($from_settings !== false && $from_settings !== null && trim((string) $from_settings) !== '') {
        return trim((string) $from_settings);
    }
    $addon = Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];
    if (isset($addon[$name]) && trim((string) $addon[$name]) !== '') {
        return trim((string) $addon[$name]);
    }

    return '';
}

/**
 * 店頭でフルページ HTML から抜き差しする要素の id（改行・カンマ区切り）を検証して一覧化。
 * 許可文字: 英数字・アンダースコア・ハイフンのみ（HTML id の安全なサブセット）。
 *
 * @return list<string>
 */
function fn_ap_safecache_parse_ajax_reload_dom_ids_raw($raw)
{
    $raw = trim((string) $raw);
    if ($raw === '') {
        return [];
    }

    $parts = preg_split('/[\s,;]+/', $raw, -1, PREG_SPLIT_NO_EMPTY);
    $out = [];

    foreach ($parts as $p) {
        $p = trim((string) $p);
        if ($p === '') {
            continue;
        }
        if (strlen($p) > 200) {
            continue;
        }
        if (!preg_match('/^[A-Za-z0-9_-]+$/', $p)) {
            continue;
        }
        if (!in_array($p, $out, true)) {
            $out[] = $p;
        }
    }

    return $out;
}

/**
 * AP SafeCache 管理画面「サイト」タブの DOM id 一覧（settings_objects の `ajax_reload_dom_ids_manage`）。
 *
 * @return list<string>
 */
function fn_ap_safecache_get_ajax_reload_dom_ids_manage()
{
    return fn_ap_safecache_parse_ajax_reload_dom_ids_raw(
        fn_ap_safecache_get_addon_text_setting_value('ajax_reload_dom_ids_manage')
    );
}

/**
 * 店頭用: SafeCache サイト画面で保存した id 一覧（後方互換で `merged` 名を維持）。
 *
 * @return list<string>
 */
function fn_ap_safecache_get_ajax_reload_dom_ids_merged()
{
    return fn_ap_safecache_get_ajax_reload_dom_ids_manage();
}

/**
 * 店頭・診断用: マージ済み HTML id 一覧（後方互換の get 名）。
 *
 * @return list<string>
 */
function fn_ap_safecache_get_ajax_reload_dom_ids()
{
    return fn_ap_safecache_get_ajax_reload_dom_ids_merged();
}

/**
 * @param list<string> $ids
 */
function fn_ap_safecache_set_ajax_reload_dom_ids_manage(array $ids)
{
    fn_ap_safecache_ensure_addon_settings_objects_registered();

    $clean = [];
    foreach ($ids as $id) {
        $id = (string) $id;
        if ($id === '') {
            continue;
        }
        if (strlen($id) > 200 || !preg_match('/^[A-Za-z0-9_-]+$/', $id)) {
            continue;
        }
        if (!in_array($id, $clean, true)) {
            $clean[] = $id;
        }
    }

    $csv = $clean === [] ? '' : implode(',', $clean);
    Settings::instance()->updateValue('ajax_reload_dom_ids_manage', $csv, 'ap_safecache', true, null, true, 0);
}

/**
 * AP SafeCache 管理のテキストエリアから保存（`ajax_reload_dom_ids_manage` のみ更新）。
 *
 * @param string $raw テキストエリアの生入力
 */
function fn_ap_safecache_save_ajax_reload_dom_ids_from_raw($raw)
{
    $ids = fn_ap_safecache_parse_ajax_reload_dom_ids_raw($raw);
    fn_ap_safecache_set_ajax_reload_dom_ids_manage($ids);
}

/**
 * 再読み込み対象にフッター（bm_containers.position = FOOTER）のブロックが含まれる場合、
 * 同一ロケーションの FOOTER 内の全ブロック ID をマージする（フッターメニュー列の取りこぼし防止）。
 *
 * @param list<int> $block_ids
 * @param list<int> $location_ids
 * @param int       $company_id
 *
 * @return list<int>
 */
function fn_ap_safecache_merge_footer_container_block_ids(array $block_ids, array $location_ids, $company_id)
{
    $block_ids = array_values(array_unique(array_filter(array_map('intval', $block_ids), static function ($id) {
        return $id > 0;
    })));
    $location_ids = array_values(array_unique(array_filter(array_map('intval', $location_ids), static function ($id) {
        return $id > 0;
    })));
    $company_id = (int) $company_id;

    if ($block_ids === [] || $location_ids === []) {
        return $block_ids;
    }

    $in_footer = (int) db_get_field(
        'SELECT COUNT(*) FROM ?:bm_snapping AS s'
        . ' INNER JOIN ?:bm_grids AS g ON g.grid_id = s.grid_id'
        . ' INNER JOIN ?:bm_containers AS c ON c.container_id = g.container_id'
        . ' WHERE s.block_id IN (?n) AND c.location_id IN (?n) AND c.position = ?s'
        . ' AND (c.company_id = 0 OR c.company_id = ?i)',
        $block_ids,
        $location_ids,
        'FOOTER',
        $company_id
    );

    if ($in_footer <= 0) {
        return $block_ids;
    }

    $extra = db_get_fields(
        'SELECT DISTINCT s.block_id FROM ?:bm_snapping AS s'
        . ' INNER JOIN ?:bm_grids AS g ON g.grid_id = s.grid_id'
        . ' INNER JOIN ?:bm_containers AS c ON c.container_id = g.container_id'
        . ' WHERE c.location_id IN (?n) AND c.position = ?s'
        . ' AND (c.company_id = 0 OR c.company_id = ?i)',
        $location_ids,
        'FOOTER',
        $company_id
    );
    $extra = array_map('intval', (array) $extra);
    $merged = array_values(array_unique(array_merge($block_ids, $extra)));
    sort($merged);

    return $merged;
}

/**
 * storefront の init.php と同じ要領で dispatch・dynamic_object を解決する（Location::get と整合させる）。
 *
 * @return array{0: string, 1: array<string, int|string>}
 */
function fn_ap_safecache_get_frontend_dispatch_location_context()
{
    $dispatch = isset($_REQUEST['dispatch']) ? (string) $_REQUEST['dispatch'] : '';
    $dynamic_object = [];
    if (!empty($_REQUEST['dynamic_object'])) {
        $dynamic_object = $_REQUEST['dynamic_object'];
        if (!is_array($dynamic_object)) {
            $dynamic_object = [];
        }
    }

    if ($dispatch === '') {
        $controller = (string) Registry::get('runtime.controller');
        $mode = (string) Registry::get('runtime.mode');
        $action = (string) Registry::get('runtime.action');
        $parts = [];
        if ($controller !== '') {
            $parts[] = $controller;
        }
        if ($mode !== '') {
            $parts[] = $mode;
        }
        if ($action !== '') {
            $parts[] = $action;
        }
        $dispatch = implode('.', $parts);
    }

    $dynamic_object_scheme = SchemesManager::getDynamicObject($dispatch, AREA, $_REQUEST);
    if (
        !empty($dynamic_object_scheme['key'])
        && !empty($_REQUEST[$dynamic_object_scheme['key']])
        && !is_array($_REQUEST[$dynamic_object_scheme['key']])
    ) {
        $dynamic_object['object_type'] = $dynamic_object_scheme['object_type'];
        $dynamic_object['object_id'] = $_REQUEST[$dynamic_object_scheme['key']];
        $dispatch = $dynamic_object_scheme['customer_dispatch'];
    }

    return [$dispatch, $dynamic_object];
}

/**
 * @param string $dispatch products.search 形式
 *
 * @return list<string> Tygh\BlockManager\Location::get と同様に短い方へ落とす候補
 */
function fn_ap_safecache_dispatch_chain_from_dispatch_string($dispatch)
{
    $dispatch = trim((string) $dispatch);
    if ($dispatch === '') {
        return [];
    }

    $parts = explode('.', $dispatch);
    $candidates = [];
    while (count($parts) > 0) {
        $candidates[] = implode('.', $parts);
        array_pop($parts);
    }

    return $candidates;
}

/**
 * 現在ページで Location::get が選ぶロケーション ID（ヘッダ・本文が同一の location に載る前提の基準）。
 *
 * @return int
 */
function fn_ap_safecache_get_primary_location_id_for_ajax_reload()
{
    if (!defined('AREA') || AREA !== 'C') {
        return 0;
    }

    [$dispatch, $dynamic_object] = fn_ap_safecache_get_frontend_dispatch_location_context();
    if ($dispatch === '') {
        return 0;
    }

    $location = Location::instance()->get($dispatch, $dynamic_object, CART_LANGUAGE);

    return !empty($location['location_id']) ? (int) $location['location_id'] : 0;
}

/**
 * Ajax ブロック再取得で参照する現在レイアウト＋テーマ既定レイアウトの layout_id 一覧。
 *
 * @return list<int>
 */
function fn_ap_safecache_get_ajax_reload_layout_ids()
{
    $runtime_layout = Registry::get('runtime.layout');
    $runtime_layout = is_array($runtime_layout) ? $runtime_layout : [];
    $current_layout_id = (int) ($runtime_layout['layout_id'] ?? 0);

    $layout_ids = [];
    if ($current_layout_id > 0) {
        $layout_ids[] = $current_layout_id;
    }

    $default_layout = Layout::instance()->getDefault();
    $default_layout_id = (int) ($default_layout['layout_id'] ?? 0);
    if ($default_layout_id > 0 && !in_array($default_layout_id, $layout_ids, true)) {
        $layout_ids[] = $default_layout_id;
    }

    return $layout_ids;
}

/**
 * 設定されたブロック ID が ?:bm_snapping 上で載っている ?:bm_locations.location_id を列挙する（dispatch は見ない）。
 * ヘッダが index ロケーション・本文が products.search ロケーションのように分かれている場合に必要。
 *
 * @param list<int> $block_ids
 * @param list<int> $layout_ids
 *
 * @return list<int>
 */
function fn_ap_safecache_get_location_ids_where_blocks_placed(array $block_ids, array $layout_ids, $company_id)
{
    $block_ids = array_values(array_unique(array_filter(array_map('intval', $block_ids), static function ($id) {
        return $id > 0;
    })));
    $layout_ids = array_values(array_unique(array_filter(array_map('intval', $layout_ids), static function ($id) {
        return $id > 0;
    })));
    $company_id = (int) $company_id;

    if ($block_ids === [] || $layout_ids === []) {
        return [];
    }

    $rows = db_get_fields(
        'SELECT DISTINCT c.location_id FROM ?:bm_snapping AS s'
        . ' INNER JOIN ?:bm_grids AS g ON g.grid_id = s.grid_id'
        . ' INNER JOIN ?:bm_containers AS c ON c.container_id = g.container_id'
        . ' INNER JOIN ?:bm_locations AS loc ON loc.location_id = c.location_id'
        . ' WHERE s.block_id IN (?n) AND loc.layout_id IN (?n) AND (c.company_id = 0 OR c.company_id = ?i)',
        $block_ids,
        $layout_ids,
        $company_id
    );

    if (empty($rows)) {
        return [];
    }

    return array_values(array_unique(array_map('intval', $rows)));
}

/**
 * ブロック再取得用に ?:bm_containers.location_id へ結合する ID 集合を得る。
 *
 * まず ?:bm_locations.dispatch を現在の dispatch チェーン（products.search → products …）で絞り、
 * 別ページ用の location を混ぜない。0件のときだけ従来どおり layout 内の全 location にフォールバック。
 *
 * @return list<int>
 */
function fn_ap_safecache_get_location_ids_for_ajax_reload_blocks()
{
    $layout_ids = fn_ap_safecache_get_ajax_reload_layout_ids();

    if ($layout_ids === []) {
        return [];
    }

    [$dispatch_resolved] = fn_ap_safecache_get_frontend_dispatch_location_context();
    if ($dispatch_resolved === '') {
        $controller = (string) Registry::get('runtime.controller');
        $mode = (string) Registry::get('runtime.mode');
        $action = (string) Registry::get('runtime.action');
        $parts = [];
        if ($controller !== '') {
            $parts[] = $controller;
        }
        if ($mode !== '') {
            $parts[] = $mode;
        }
        if ($action !== '') {
            $parts[] = $action;
        }
        $dispatch_resolved = implode('.', $parts);
    }

    $chain = fn_ap_safecache_dispatch_chain_from_dispatch_string($dispatch_resolved);
    if ($chain !== []) {
        $location_ids = db_get_fields(
            'SELECT DISTINCT location_id FROM ?:bm_locations WHERE layout_id IN (?n) AND dispatch IN (?a)',
            $layout_ids,
            $chain
        );
        if (!empty($location_ids)) {
            return array_values(array_unique(array_map('intval', $location_ids)));
        }
    }

    $location_ids = db_get_fields('SELECT DISTINCT location_id FROM ?:bm_locations WHERE layout_id IN (?n)', $layout_ids);

    if (empty($location_ids)) {
        return [];
    }

    return array_values(array_unique(array_map('intval', $location_ids)));
}

/**
 * 現在のロケーション上に配置されているブロックについて、snapping_id と block_manager.render 用 object_key を解決する。
 *
 * @param list<int> $block_ids
 * @param list<int> $location_ids ?:bm_locations.location_id（同一 dispatch で複数レイアウトにまたがる場合は複数）
 * @param int       $company_id     ?:bm_containers.company_id（0 とベンダー ID の両方を許容）
 * @param int       $primary_location_id Location::get が返す現在ページの location_id（同一 block_id の複数 snapping があるとき優先）
 *
 * @return list<array{block_id: int, snapping_id: int, object_key: string, element_id: string}>
 */
function fn_ap_safecache_build_ajax_reload_runtime_items(array $block_ids, array $location_ids, $company_id, $primary_location_id = 0)
{
    $location_ids = array_values(array_unique(array_filter(array_map('intval', $location_ids), static function ($id) {
        return $id > 0;
    })));
    $company_id = (int) $company_id;
    $primary_location_id = (int) $primary_location_id;

    if ($block_ids === [] || $location_ids === []) {
        return [];
    }

    $rows = db_get_array(
        'SELECT s.block_id, s.snapping_id, c.location_id FROM ?:bm_snapping AS s'
        . ' INNER JOIN ?:bm_grids AS g ON g.grid_id = s.grid_id'
        . ' INNER JOIN ?:bm_containers AS c ON c.container_id = g.container_id'
        . ' WHERE s.block_id IN (?n) AND c.location_id IN (?n) AND (c.company_id = 0 OR c.company_id = ?i)'
        . ' ORDER BY s.snapping_id ASC',
        $block_ids,
        $location_ids,
        $company_id
    );

    $candidates_by_block = [];
    foreach ($rows as $row) {
        $bid = (int) $row['block_id'];
        $sid = (int) $row['snapping_id'];
        if ($bid <= 0 || $sid <= 0) {
            continue;
        }
        if (!isset($candidates_by_block[$bid])) {
            $candidates_by_block[$bid] = [];
        }
        $candidates_by_block[$bid][] = $row;
    }

    $items = [];
    $seen_snapping = [];

    foreach ($candidates_by_block as $bid => $cands) {
        $chosen = null;
        if ($primary_location_id > 0) {
            foreach ($cands as $c) {
                if ((int) $c['location_id'] === $primary_location_id) {
                    $chosen = $c;
                    break;
                }
            }
        }
        if ($chosen === null) {
            $chosen = $cands[0];
        }

        $sid = (int) $chosen['snapping_id'];
        if ($sid <= 0 || isset($seen_snapping[$sid])) {
            continue;
        }
        $seen_snapping[$sid] = true;
        $plain = $bid . ':' . $sid;
        $items[] = [
            'block_id'    => $bid,
            'snapping_id' => $sid,
            'object_key'  => fn_encrypt_text($plain),
            'element_id'  => 'snapping_id_' . $sid,
        ];
    }

    return $items;
}

/**
 * 店頭フル表示時: 設定されたブロックを Ajax で差し替えるためのデータをビューへ渡す。
 */
function fn_ap_safecache_dispatch_before_display()
{
    if (!defined('AREA') || defined('AJAX_REQUEST')) {
        return;
    }

    if (AREA === 'A') {
        fn_ap_safecache_notify_core_upgrade_compatibility_if_needed();
        return;
    }

    if (AREA !== 'C') {
        return;
    }

    if (Registry::get('runtime.controller_status') !== CONTROLLER_STATUS_OK) {
        return;
    }

    if (function_exists('fn_ap_safecache_storefront_cf_cache_tag_headers_send')) {
        fn_ap_safecache_storefront_cf_cache_tag_headers_send();
    }

    /** @var \Tygh\SmartyEngine\Core $view */
    $view = Tygh::$app['view'];

    $log_ajax = fn_ap_safecache_is_ajax_block_reload_logging_enabled();
    $view->assign('ap_safecache_log_ajax_block_reload', $log_ajax);
    $view->assign('ap_safecache_lazy_reload_layout_blocks', fn_ap_safecache_lazy_reload_layout_blocks_enabled());

    $controller = (string) Registry::get('runtime.controller');
    $mode = (string) Registry::get('runtime.mode');
    $view->assign('ap_safecache_is_product_view', $controller === 'products' && $mode === 'view');

    // テンプレで常に window.AP_SAFECACHE_AJAX_RELOAD_BLOCKS を定義するため、解決0件でも [] を渡す。
    $json_flags = JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
    $payload = '[]';
    $items = [];
    $location_ids = [];

    $block_ids = fn_ap_safecache_get_ajax_reload_block_ids();
    if ($block_ids !== []) {
        $location_data = $view->getTemplateVars('location_data');
        $location_data = is_array($location_data) ? $location_data : [];

        $layout_ids = fn_ap_safecache_get_ajax_reload_layout_ids();
        $company_id = (int) Registry::get('runtime.company_id');

        $location_ids = fn_ap_safecache_get_location_ids_for_ajax_reload_blocks();
        if ($location_ids === []) {
            $location_id = !empty($location_data['location_id']) ? (int) $location_data['location_id'] : 0;
            if ($location_id > 0) {
                $location_ids = [$location_id];
            }
        }

        $from_placed = fn_ap_safecache_get_location_ids_where_blocks_placed($block_ids, $layout_ids, $company_id);
        $location_ids = array_values(array_unique(array_merge(
            array_map('intval', (array) $location_ids),
            $from_placed
        )));

        if ($location_ids !== []) {
            $block_ids = fn_ap_safecache_merge_footer_container_block_ids($block_ids, $location_ids, $company_id);
            $primary_location_id = fn_ap_safecache_get_primary_location_id_for_ajax_reload();
            $items = fn_ap_safecache_build_ajax_reload_runtime_items($block_ids, $location_ids, $company_id, $primary_location_id);
            if ($items !== []) {
                $payload = json_encode($items, $json_flags);
            }
        }
    }

    $view->assign('ap_safecache_ajax_reload_blocks_json', $payload);

    $dom_ids_merged = fn_ap_safecache_get_ajax_reload_dom_ids_merged();
    $dom_ids_payload = '[]';
    if ($dom_ids_merged !== []) {
        $dom_ids_payload = json_encode($dom_ids_merged, $json_flags);
    }
    $view->assign('ap_safecache_ajax_reload_dom_ids_json', $dom_ids_payload);

    if ($log_ajax) {
        $runtime_layout = Registry::get('runtime.layout');
        $runtime_layout = is_array($runtime_layout) ? $runtime_layout : [];
        $dispatch = (string) Registry::get('runtime.controller') . '.' . (string) Registry::get('runtime.mode');
        $items_for_log = [];
        foreach ($items as $it) {
            $items_for_log[] = [
                'block_id'    => $it['block_id'] ?? 0,
                'snapping_id' => $it['snapping_id'] ?? 0,
                'element_id'  => $it['element_id'] ?? '',
            ];
        }
        fn_ap_safecache_log_ajax_block_reload_event(
            'page_assign',
            [
                'dispatch'           => $dispatch,
                'company_id'         => (int) Registry::get('runtime.company_id'),
                'layout_id'          => (int) ($runtime_layout['layout_id'] ?? 0),
                'block_ids'          => $block_ids,
                'location_ids'       => $location_ids,
                'items_resolved'     => count($items),
                'items'              => $items_for_log,
                'payload_bytes'       => strlen($payload),
                'dom_ids_merged'        => $dom_ids_merged,
                'dom_ids_payload_bytes' => strlen($dom_ids_payload),
            ]
        );
    }
}

/**
 * upgrade_center.manage 表示時に、本体アップデート互換判定 API の結果を通知する。
 * 現段階では「通知のみ」で、更新処理のブロックは行わない。
 *
 * @return void
 */
function fn_ap_safecache_notify_core_upgrade_compatibility_if_needed()
{
    if ((string) Registry::get('runtime.controller') !== 'upgrade_center') {
        return;
    }
    if ((string) Registry::get('runtime.mode') !== 'manage') {
        return;
    }

    /** @var \Tygh\SmartyEngine\Core $view */
    $view = Tygh::$app['view'];
    $upgrade_env = $view->getTemplateVars('available_core_upgrade');
    if (!is_object($upgrade_env) || !method_exists($upgrade_env, 'getProductVersion')) {
        return;
    }

    $target_version = (string) $upgrade_env->getProductVersion();
    $target_version = trim($target_version);
    if ($target_version === '') {
        return;
    }

    if (!function_exists('fn_ap_safecache_fetch_update_compatibility')) {
        return;
    }

    list($ok, $result) = fn_ap_safecache_fetch_update_compatibility($target_version);
    $title = 'AP SafeCache: 本体アップデート互換チェック';
    if (!$ok || !is_array($result)) {
        fn_set_notification(
            'W',
            $title,
            '次期バージョン ' . $target_version . ' の互換性は未確定です（判定APIに未接続または応答不正）。更新前に確認してください。',
            'S',
            'ap_safecache.core_upgrade_compat'
        );
        return;
    }

    $status = isset($result['compatibility_status']) ? (string) $result['compatibility_status'] : 'unknown';
    $required_addon_version = isset($result['required_addon_version']) ? trim((string) $result['required_addon_version']) : '';
    $addon_version = fn_ap_safecache_get_addon_version();
    $extra = fn_ap_safecache_core_upgrade_compat_extra_message_from_api($result);

    if ($status === 'update_required') {
        $msg = '次期バージョン ' . $target_version . ' へ更新する前に、ap_safecache の更新が必要です。';
        if ($required_addon_version !== '') {
            $msg .= ' 必要アドオン版: ' . $required_addon_version . ' 以上。';
        }
        if ($extra !== '') {
            $msg .= "\n\n" . $extra;
        }
        fn_set_notification('W', $title, $msg, 'S', 'ap_safecache.core_upgrade_compat');
        return;
    }

    if ($status === 'supported') {
        $msg = '次期バージョン ' . $target_version . ' は、現在の ap_safecache ' . $addon_version . ' で利用可能です。';
        if ($extra !== '') {
            $msg .= "\n\n" . $extra;
        }
        fn_set_notification(
            'N',
            $title,
            $msg,
            'S',
            'ap_safecache.core_upgrade_compat'
        );
        return;
    }

    $msg = '次期バージョン ' . $target_version . ' の互換性は未確定です。更新前に確認してください。';
    if ($extra !== '') {
        $msg .= "\n\n" . $extra;
    }
    fn_set_notification(
        'W',
        $title,
        $msg,
        'S',
        'ap_safecache.core_upgrade_compat'
    );
}

/**
 * @param array<string, mixed> $result
 *
 * @return string
 */
function fn_ap_safecache_core_upgrade_compat_extra_message_from_api(array $result)
{
    $lines = [];

    $download = isset($result['download_url']) ? trim((string) $result['download_url']) : '';
    if ($download !== '' && filter_var($download, FILTER_VALIDATE_URL) && stripos($download, 'https://') === 0) {
        $lines[] = 'アドオンZIP: ' . $download;
    }

    $docs = isset($result['docs_url']) ? trim((string) $result['docs_url']) : '';
    if ($docs !== '' && filter_var($docs, FILTER_VALIDATE_URL) && stripos($docs, 'https://') === 0) {
        $lines[] = '手順: ' . $docs;
    }

    $sha = isset($result['sha256']) ? strtolower(trim((string) $result['sha256'])) : '';
    if ($sha !== '' && preg_match('/^[0-9a-f]{64}$/', $sha) === 1) {
        $lines[] = 'SHA256: ' . $sha;
    }

    return implode("\n", $lines);
}

/**
 * ブロックピッカー用の現在ストアフロント ID（管理画面）。
 */
function fn_ap_safecache_get_active_storefront_id_for_picker()
{
    if (!empty(Tygh::$app['storefront']) && !empty(Tygh::$app['storefront']->storefront_id)) {
        return (int) Tygh::$app['storefront']->storefront_id;
    }

    $id = db_get_field('SELECT storefront_id FROM ?:storefronts ORDER BY storefront_id ASC LIMIT 1');

    return $id ? (int) $id : 0;
}

/**
 * @return list<array{storefront_id: int, label: string}>
 */
function fn_ap_safecache_get_storefronts_for_picker()
{
    $rows = db_get_array('SELECT storefront_id FROM ?:storefronts ORDER BY storefront_id ASC');
    $out = [];

    foreach ($rows as $row) {
        $sid = (int) $row['storefront_id'];
        $out[] = [
            'storefront_id' => $sid,
            'label'         => (string) __('ap_safecache.storefront_picker_label', ['[id]' => (string) $sid]),
        ];
    }

    return $out;
}

/**
 * @param list<int> $ids
 *
 * @return list<int>
 */
function fn_ap_safecache_validate_block_ids_exist(array $ids)
{
    if ($ids === []) {
        return [];
    }

    $found = db_get_fields('SELECT block_id FROM ?:bm_blocks WHERE block_id IN (?n)', $ids);

    if (empty($found)) {
        return [];
    }

    $out = array_map('intval', $found);
    sort($out);

    return $out;
}

/**
 * @param list<int> $ids
 */
function fn_ap_safecache_set_ajax_reload_block_ids(array $ids)
{
    fn_ap_safecache_ensure_addon_settings_objects_registered();

    $ids = fn_ap_safecache_validate_block_ids_exist($ids);
    $csv = $ids === [] ? '' : implode(',', $ids);
    // 第7引数 storefront_id=0: addon.xml edition_type=ROOT の値を settings_objects に確実に書く（Ult 複数SF で null だと更新テーブル未決定で保存されない）。
    Settings::instance()->updateValue('ajax_reload_block_ids', $csv, 'ap_safecache', true, null, true, 0);
}

/**
 * ブロック一覧（ピッカー用）。ストアフロントごとのブロックセットに依存する。
 *
 * @return list<array{block_id: int, name: string, type: string, label: string}>
 */
function fn_ap_safecache_get_blocks_for_picker($storefront_id)
{
    $storefront_id = (int) $storefront_id;
    if ($storefront_id <= 0) {
        $storefront_id = fn_ap_safecache_get_active_storefront_id_for_picker();
    }

    $blocks = Block::instance(0, [], $storefront_id)->getAllUnique(DESCR_SL);
    $list = [];

    foreach ($blocks as $bid => $row) {
        $bid = (int) $bid;
        $name = isset($row['name']) ? (string) $row['name'] : '';
        $type = isset($row['type']) ? (string) $row['type'] : '';
        $list[] = [
            'block_id' => $bid,
            'name'     => $name,
            'type'     => $type,
            'label'    => '#' . $bid . ' — ' . $name . ' (' . $type . ')',
        ];
    }

    usort($list, static function ($a, $b) {
        return strcasecmp($a['name'], $b['name']);
    });

    return $list;
}

/**
 * ピッカー各行に「Ajax 再読み込み対象」チェック用フラグを付与する（DB 保存済み ID 一覧と突合）。
 *
 * @param list<array<string, int|string>> $blocks
 * @param list<int>                       $ajax_ids
 *
 * @return list<array<string, int|string|bool>>
 */
function fn_ap_safecache_merge_ajax_reload_selection_into_blocks(array $blocks, array $ajax_ids)
{
    $lookup = [];
    foreach ($ajax_ids as $id) {
        $id = (int) $id;
        if ($id > 0) {
            $lookup[$id] = true;
        }
    }
    foreach ($blocks as &$row) {
        $bid = isset($row['block_id']) ? (int) $row['block_id'] : 0;
        // Smarty で確実に評価できる短いキー名（checked はテンプレ側で付与）
        $row['ap_checked'] = $bid > 0 && isset($lookup[$bid]);
    }
    unset($row);

    return $blocks;
}

/**
 * POST の block_id 配列から保存する。
 *
 * @param array<mixed> $raw_ids
 */
function fn_ap_safecache_save_ajax_reload_blocks_from_post(array $raw_ids)
{
    $ids = [];
    foreach ($raw_ids as $v) {
        $i = (int) $v;
        if ($i > 0) {
            $ids[] = $i;
        }
    }
    $ids = array_values(array_unique($ids));
    fn_ap_safecache_set_ajax_reload_block_ids($ids);
}

/**
 * 「Ajax 再読み込み対象を保存」直後のメンテナンス。店舗キャッシュをクリアし、
 * Cloudflare API が設定されていればエッジの Purge Everything を実行する。
 *
 * @return 'ok'|'skipped'|'error' skipped はトークン／ゾーン ID 未設定、error は API 失敗（その場合はパージ用通知を出す）
 */
function fn_ap_safecache_after_save_ajax_reload_blocks()
{
    Registry::set('ap_safecache_suppress_pe_on_clear_cache', true);
    fn_clear_cache();
    Registry::set('ap_safecache_suppress_pe_on_clear_cache', false);

    if (!fn_ap_safecache_is_pro()) {
        return 'skipped';
    }

    $addon = Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];
    $token = isset($addon['cloudflare_api_token']) ? trim((string) $addon['cloudflare_api_token']) : '';
    $zone_id = isset($addon['cloudflare_zone_id']) ? trim((string) $addon['cloudflare_zone_id']) : '';

    if ($token === '' || $zone_id === '') {
        return 'skipped';
    }

    $r = fn_ap_safecache_purge_everything_scheduled(AP_SAFECACHE_PURGE_EVERYTHING_SRC_AJAX_BLOCKS_SAVE, [
        'silent_success' => true,
        'silent_errors'  => false,
    ]);

    if ($r['status'] === 'deferred') {
        $flushed = fn_ap_safecache_purge_everything_deferred_flush();
        if (is_array($flushed)) {
            $r = $flushed;
        }
    }

    if ($r['status'] === 'error') {
        return 'error';
    }

    if ($r['status'] === 'throttled') {
        return 'throttled';
    }

    return 'ok';
}

/**
 * レイアウト編集から 1 ブロックを対象に追加（重複は追加しない）。
 */
function fn_ap_safecache_merge_ajax_reload_block_id($block_id)
{
    $block_id = (int) $block_id;
    if ($block_id <= 0) {
        return false;
    }

    $exists = db_get_field('SELECT block_id FROM ?:bm_blocks WHERE block_id = ?i', $block_id);
    if (empty($exists)) {
        return false;
    }

    $ids = fn_ap_safecache_get_ajax_reload_block_ids();
    if (!in_array($block_id, $ids, true)) {
        $ids[] = $block_id;
    }
    fn_ap_safecache_set_ajax_reload_block_ids($ids);

    return true;
}

/**
 * @return string
 */
function fn_ap_safecache_get_addon_version()
{
    $addon = Registry::get('addons.ap_safecache');
    if (is_array($addon) && isset($addon['version'])) {
        return (string) $addon['version'];
    }

    return '';
}

/**
 * 推奨 API 等に送る想定の診断ペイロード（秘密情報は含めない）。
 *
 * @return array<string, mixed>
 */
function fn_ap_safecache_get_diagnostic_payload()
{
    $settings = fn_ap_safecache_get_settings_display();
    $env = fn_ap_safecache_get_environment_snapshot();
    $tier = fn_ap_safecache_get_license_tier();

    $base = [
        'schema_version'     => 2,
        'generated_at'       => gmdate('c'),
        'php_version'        => PHP_VERSION,
        'php_sapi'           => PHP_SAPI,
        'addon_id'           => 'ap_safecache',
        'addon_version'      => fn_ap_safecache_get_addon_version(),
        'license_tier'       => $tier,
        'extension_licensed' => fn_ap_safecache_is_extension_licensed(),
        'environment'        => $env,
        'settings'           => [
            'recommendation_api_base_url_configured' => ($settings['recommendation_api_base_url'] !== ''),
            'cloudflare_zone_id_configured'        => ($settings['cloudflare_zone_id'] !== ''),
            'cloudflare_api_token_configured'      => !empty($settings['cloudflare_api_token_set']),
            'ajax_reload_block_targets_count' => (int) ($settings['ajax_reload_block_count'] ?? 0),
            'ajax_reload_dom_id_manage_count' => (int) ($settings['ajax_reload_dom_id_manage_count'] ?? 0),
            'ajax_reload_dom_id_merged_count' => (int) ($settings['ajax_reload_dom_id_merged_count'] ?? 0),
        ],
    ];

    if ($tier === 'free') {
        $base['environment'] = [
            'product_edition'  => isset($env['product_edition']) ? (string) $env['product_edition'] : '',
            'storefront_count' => isset($env['storefront_count']) ? (int) $env['storefront_count'] : 0,
        ];
        $base['settings'] = [
            'cloudflare_zone_id_configured'   => ($settings['cloudflare_zone_id'] !== ''),
            'cloudflare_api_token_configured' => !empty($settings['cloudflare_api_token_set']),
        ];
        $base['diagnostic_note'] = __('ap_safecache.diagnostic_free_tier_note');
    }

    return $base;
}

/**
 * 管理画面表示用 JSON 文字列（pretty print）。
 *
 * @return string
 */
function fn_ap_safecache_get_diagnostic_payload_json()
{
    $payload = fn_ap_safecache_get_diagnostic_payload();
    $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
    if (defined('JSON_PRETTY_PRINT')) {
        $flags |= JSON_PRETTY_PRINT;
    }

    return (string) json_encode($payload, $flags);
}
