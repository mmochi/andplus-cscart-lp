<?php

/**
 * Cloudflare purge_everything の発火元定義と単一入口（合流つき）。
 *
 * @see MEMO_保留事項.md §11.16
 */

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}

use Tygh\Registry;

/** 管理画面「キャッシュ全削除（ゾーン）」 */
define('AP_SAFECACHE_PURGE_EVERYTHING_SRC_MANAGE_BUTTON', 'manage_purge');

/** Ajax 再読み込み対象ブロック保存直後 */
define('AP_SAFECACHE_PURGE_EVERYTHING_SRC_AJAX_BLOCKS_SAVE', 'ajax_blocks_save');

/** Exim import_post */
define('AP_SAFECACHE_PURGE_EVERYTHING_SRC_IMPORT_POST', 'import_post');

/** fn.products 商品保存後 */
define('AP_SAFECACHE_PURGE_EVERYTHING_SRC_UPDATE_PRODUCT_POST', 'update_product_post');

/** fn.products 商品削除後 */
define('AP_SAFECACHE_PURGE_EVERYTHING_SRC_DELETE_PRODUCT_POST', 'delete_product_post');

/** fn.categories カテゴリ保存後 */
define('AP_SAFECACHE_PURGE_EVERYTHING_SRC_UPDATE_CATEGORY_POST', 'update_category_post');

/** fn.categories カテゴリ削除後 */
define('AP_SAFECACHE_PURGE_EVERYTHING_SRC_DELETE_CATEGORY_POST', 'delete_category_post');

/** fn_clear_cache 完了後（管理画面・タイプ all のみフック側で絞る） */
define('AP_SAFECACHE_PURGE_EVERYTHING_SRC_CLEAR_CACHE_POST', 'clear_cache_post');

if (!defined('AP_SAFECACHE_PURGE_EVERYTHING_MIN_INTERVAL_SEC')) {
    /** 同一ゾーンへの purge_everything HTTP の最短間隔（秒）。0 でスロットル無効。 */
    define('AP_SAFECACHE_PURGE_EVERYTHING_MIN_INTERVAL_SEC', 5);
}

if (!defined('AP_SAFECACHE_PURGE_EVERYTHING_CRON_DEBOUNCE_DEFAULT_SEC')) {
    /** cron 送信用: 「最後の wanted 更新」からこの秒数経過後にのみ HTTP（設定未入力時の既定）。 */
    define('AP_SAFECACHE_PURGE_EVERYTHING_CRON_DEBOUNCE_DEFAULT_SEC', 60);
}

/**
 * @return list<string>
 */
function fn_ap_safecache_purge_everything_source_list()
{
    return [
        AP_SAFECACHE_PURGE_EVERYTHING_SRC_MANAGE_BUTTON,
        AP_SAFECACHE_PURGE_EVERYTHING_SRC_AJAX_BLOCKS_SAVE,
        AP_SAFECACHE_PURGE_EVERYTHING_SRC_IMPORT_POST,
        AP_SAFECACHE_PURGE_EVERYTHING_SRC_UPDATE_PRODUCT_POST,
        AP_SAFECACHE_PURGE_EVERYTHING_SRC_DELETE_PRODUCT_POST,
        AP_SAFECACHE_PURGE_EVERYTHING_SRC_UPDATE_CATEGORY_POST,
        AP_SAFECACHE_PURGE_EVERYTHING_SRC_DELETE_CATEGORY_POST,
        AP_SAFECACHE_PURGE_EVERYTHING_SRC_CLEAR_CACHE_POST,
    ];
}

/**
 * @return int 秒（0 以上）
 */
function fn_ap_safecache_purge_everything_min_interval_sec()
{
    $n = (int) AP_SAFECACHE_PURGE_EVERYTHING_MIN_INTERVAL_SEC;

    return max(0, $n);
}

/**
 * ストレージキー（会社／ストア単位で分離）。
 */
function fn_ap_safecache_purge_everything_storage_key_last_http()
{
    $company_id = 0;
    if (function_exists('fn_get_runtime_company_id')) {
        $company_id = (int) fn_get_runtime_company_id();
    }

    return 'ap_safecache_pe_last_http_' . $company_id;
}

/**
 * cron 用「遅延パージ希望」JSON（at / sources）のストレージキー。
 */
function fn_ap_safecache_purge_everything_storage_key_wanted()
{
    $company_id = 0;
    if (function_exists('fn_get_runtime_company_id')) {
        $company_id = (int) fn_get_runtime_company_id();
    }

    return 'ap_safecache_pe_wanted_' . $company_id;
}

/**
 * @return int 秒（0 以上）
 */
function fn_ap_safecache_purge_everything_cron_debounce_sec()
{
    $addon = Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];
    $raw = isset($addon['purge_everything_cron_debounce_sec']) ? trim((string) $addon['purge_everything_cron_debounce_sec']) : '';
    if ($raw === '') {
        return max(0, (int) AP_SAFECACHE_PURGE_EVERYTHING_CRON_DEBOUNCE_DEFAULT_SEC);
    }

    return max(0, (int) $raw);
}

/**
 * @return array{at: float, sources: array<string, bool>}|null
 */
function fn_ap_safecache_purge_everything_wanted_read()
{
    if (!function_exists('fn_get_storage_data')) {
        return null;
    }
    $raw = fn_get_storage_data(fn_ap_safecache_purge_everything_storage_key_wanted());
    if ($raw === false || $raw === null || $raw === '') {
        return null;
    }
    $data = json_decode((string) $raw, true);
    if (!is_array($data) || !isset($data['at'])) {
        return null;
    }
    $data['at'] = (float) $data['at'];
    if (!isset($data['sources']) || !is_array($data['sources'])) {
        $data['sources'] = [];
    }

    return $data;
}

function fn_ap_safecache_purge_everything_wanted_merge_source($source)
{
    $source = (string) $source;
    $cur = fn_ap_safecache_purge_everything_wanted_read();
    if (!is_array($cur)) {
        $cur = ['at' => 0.0, 'sources' => []];
    }
    $cur['at'] = microtime(true);
    $cur['sources'][$source] = true;

    if (function_exists('fn_set_storage_data')) {
        fn_set_storage_data(
            fn_ap_safecache_purge_everything_storage_key_wanted(),
            (string) json_encode($cur, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        );
    }
}

function fn_ap_safecache_purge_everything_wanted_clear()
{
    if (function_exists('fn_set_storage_data')) {
        fn_set_storage_data(fn_ap_safecache_purge_everything_storage_key_wanted(), '');
    }
}

/**
 * 同一リクエスト内の複数 purge 要求をまとめ、shutdown（または明示 flush）で 1 回だけ HTTP する。
 *
 * @param string               $source
 * @param array<string, mixed> $options silent_success, silent_errors
 */
function fn_ap_safecache_purge_everything_deferred_merge($source, array $options = [])
{
    $silent_success = !empty($options['silent_success']);
    $silent_errors = !empty($options['silent_errors']);

    $def = Registry::get('ap_safecache_pe_deferred');
    if (!is_array($def)) {
        $def = [
            'active'          => false,
            'sources'         => [],
            'silent_success'  => true,
            'silent_errors'   => true,
        ];
    }
    if (!isset($def['sources']) || !is_array($def['sources'])) {
        $def['sources'] = [];
    }

    $def['active'] = true;
    $def['sources'][(string) $source] = true;
    $def['silent_success'] = !empty($def['silent_success']) && $silent_success;
    $def['silent_errors'] = !empty($def['silent_errors']) && $silent_errors;

    Registry::set('ap_safecache_pe_deferred', $def);

    fn_ap_safecache_purge_everything_wanted_merge_source($source);
}

/**
 * shutdown 用。合流済みの purge_everything を最大 1 回実行（スロットル適用）。
 *
 * @return array{status: string, detail: string}|null 実行対象がなければ null
 */
function fn_ap_safecache_purge_everything_deferred_flush()
{
    static $done = false;
    if ($done) {
        return null;
    }

    $def = Registry::get('ap_safecache_pe_deferred');
    if (!is_array($def) || empty($def['active'])) {
        return null;
    }

    $done = true;
    Registry::del('ap_safecache_pe_deferred');

    $notification_title = __('ap_safecache.notification_title_purge');

    if (!fn_ap_safecache_is_pro()) {
        if (empty($def['silent_errors'])) {
            fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.license_pro_only'));
        }

        return ['status' => 'skipped', 'detail' => 'not_pro'];
    }

    list($lat_ok, $lat_msg) = fn_ap_safecache_license_action_token_ensure_for_pro_write();
    if (!$lat_ok) {
        if (empty($def['silent_errors'])) {
            fn_ap_safecache_set_ping_notification(false, $notification_title, $lat_msg);
        }

        return ['status' => 'skipped', 'detail' => $lat_msg];
    }

    $addon = Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];
    $token = isset($addon['cloudflare_api_token']) ? trim((string) $addon['cloudflare_api_token']) : '';
    $zone_id = isset($addon['cloudflare_zone_id']) ? trim((string) $addon['cloudflare_zone_id']) : '';

    if ($token === '') {
        if (empty($def['silent_errors'])) {
            fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_cf_token_required'));
        }

        return ['status' => 'skipped', 'detail' => 'no_token'];
    }

    if ($zone_id === '') {
        if (empty($def['silent_errors'])) {
            fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_cf_zone_required_for_purge'));
        }

        return ['status' => 'skipped', 'detail' => 'no_zone'];
    }

    $interval = fn_ap_safecache_purge_everything_min_interval_sec();
    if ($interval > 0) {
        $key = fn_ap_safecache_purge_everything_storage_key_last_http();
        $last_raw = function_exists('fn_get_storage_data') ? fn_get_storage_data($key) : null;
        $last = is_numeric($last_raw) ? (float) $last_raw : 0.0;
        $now = microtime(true);
        if ($last > 0 && ($now - $last) < $interval) {
            $src = implode(',', array_keys($def['sources']));

            return ['status' => 'throttled', 'detail' => $src];
        }
    }

    list($ok, $err) = fn_ap_safecache_cloudflare_purge_post($token, $zone_id, ['purge_everything' => true]);

    if (!$ok) {
        if (empty($def['silent_errors'])) {
            fn_ap_safecache_set_ping_notification(false, $notification_title, $err);
        }

        return ['status' => 'error', 'detail' => $err];
    }

    if (function_exists('fn_set_storage_data')) {
        fn_set_storage_data(fn_ap_safecache_purge_everything_storage_key_last_http(), (string) microtime(true));
    }

    fn_ap_safecache_purge_everything_wanted_clear();

    if (empty($def['silent_success'])) {
        fn_ap_safecache_set_ping_notification(true, $notification_title, __('ap_safecache.ok_cf_purge'));
    }

    return ['status' => 'ok', 'detail' => implode(',', array_keys($def['sources']))];
}

/**
 * shutdown から呼ぶラッパー（register_shutdown_function 用）。
 */
function fn_ap_safecache_purge_everything_shutdown_flush()
{
    fn_ap_safecache_purge_everything_deferred_flush();
}

/**
 * shutdown に合流 flush を 1 度だけ登録する。
 */
function fn_ap_safecache_purge_everything_register_deferred_shutdown()
{
    static $registered = false;
    if ($registered) {
        return;
    }
    $registered = true;

    register_shutdown_function('fn_ap_safecache_purge_everything_shutdown_flush');
}

/**
 * Cloudflare purge_everything の単一入口。
 *
 * @param string               $source  AP_SAFECACHE_PURGE_EVERYTHING_SRC_* のいずれか
 * @param array<string, mixed> $options bypass_throttle(bool), silent_success(bool), silent_errors(bool)
 *
 * @return array{status: string, detail: string} status: ok|skipped|throttled|error|deferred
 */
function fn_ap_safecache_purge_everything_scheduled($source, array $options = [])
{
    $source = (string) $source;
    if (!in_array($source, fn_ap_safecache_purge_everything_source_list(), true)) {
        return ['status' => 'error', 'detail' => 'invalid purge source'];
    }

    $bypass_throttle = !empty($options['bypass_throttle']);
    $silent_success = !empty($options['silent_success']);
    $silent_errors = !empty($options['silent_errors']);

    $notification_title = __('ap_safecache.notification_title_purge');

    if (!fn_ap_safecache_is_pro()) {
        if (!$silent_errors) {
            fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.license_pro_only'));
        }

        return ['status' => 'skipped', 'detail' => 'not_pro'];
    }

    $addon = Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];
    $token = isset($addon['cloudflare_api_token']) ? trim((string) $addon['cloudflare_api_token']) : '';
    $zone_id = isset($addon['cloudflare_zone_id']) ? trim((string) $addon['cloudflare_zone_id']) : '';

    if ($token === '') {
        if (!$silent_errors) {
            fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_cf_token_required'));
        }

        return ['status' => 'skipped', 'detail' => 'no_token'];
    }

    if ($zone_id === '') {
        if (!$silent_errors) {
            fn_ap_safecache_set_ping_notification(false, $notification_title, __('ap_safecache.err_cf_zone_required_for_purge'));
        }

        return ['status' => 'skipped', 'detail' => 'no_zone'];
    }

    if ($bypass_throttle) {
        Registry::del('ap_safecache_pe_deferred');

        list($lat_ok, $lat_msg) = fn_ap_safecache_license_action_token_ensure_for_pro_write();
        if (!$lat_ok) {
            if (!$silent_errors) {
                fn_ap_safecache_set_ping_notification(false, $notification_title, $lat_msg);
            }

            return ['status' => 'skipped', 'detail' => $lat_msg];
        }

        list($ok, $err) = fn_ap_safecache_cloudflare_purge_post($token, $zone_id, ['purge_everything' => true]);

        if (!$ok) {
            if (!$silent_errors) {
                fn_ap_safecache_set_ping_notification(false, $notification_title, $err);
            }

            return ['status' => 'error', 'detail' => $err];
        }

        if (function_exists('fn_set_storage_data')) {
            fn_set_storage_data(fn_ap_safecache_purge_everything_storage_key_last_http(), (string) microtime(true));
        }

        fn_ap_safecache_purge_everything_wanted_clear();

        if (!$silent_success) {
            fn_ap_safecache_set_ping_notification(true, $notification_title, __('ap_safecache.ok_cf_purge'));
        }

        return ['status' => 'ok', 'detail' => ''];
    }

    fn_ap_safecache_purge_everything_deferred_merge($source, [
        'silent_success' => $silent_success,
        'silent_errors'  => $silent_errors,
    ]);
    fn_ap_safecache_purge_everything_register_deferred_shutdown();

    return ['status' => 'deferred', 'detail' => $source];
}

/**
 * GET dispatch=ap_safecache.cron_pe_flush（サーバ cron / wget 用）。text/plain。
 * `cf_poll_cron_enable` / `cf_poll_cron_password` を **cron_cf_poll と共用**（同一ルール）。
 * ストレージ上の **wanted**（遅延パージ希望）があり、デバウンス・最短間隔を満たすときだけ purge_everything を送る。
 *
 * @return void
 */
function fn_ap_safecache_pe_flush_cron_http_response()
{
    if (!defined('AREA') || AREA !== 'A') {
        http_response_code(403);
        header('Content-Type: text/plain; charset=UTF-8');
        echo 'ERROR: ' . __('access_denied');

        return;
    }

    header('Content-Type: text/plain; charset=UTF-8');

    $addon = Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];

    if (!fn_ap_safecache_setting_value_is_yes($addon['cf_poll_cron_enable'] ?? 'N')) {
        http_response_code(403);
        echo 'ERROR: ' . __('ap_safecache.cf_poll_cron_err_disabled');

        return;
    }

    if (!fn_ap_safecache_is_pro()) {
        http_response_code(403);
        echo 'ERROR: ' . __('ap_safecache.license_pro_only');

        return;
    }

    $stored = isset($addon['cf_poll_cron_password']) ? trim((string) $addon['cf_poll_cron_password']) : '';
    if ($stored === '') {
        http_response_code(503);
        echo 'ERROR: ' . __('ap_safecache.cf_poll_cron_err_password_not_set');

        return;
    }

    $req = isset($_REQUEST['cron_password']) ? (string) $_REQUEST['cron_password'] : '';
    if (!hash_equals($stored, $req)) {
        http_response_code(403);
        echo 'ERROR: ' . __('access_denied');

        return;
    }

    $wanted = fn_ap_safecache_purge_everything_wanted_read();
    if ($wanted === null || $wanted['at'] <= 0) {
        echo 'OK: ' . __('ap_safecache.pe_flush_cron_noop');

        return;
    }

    $now = microtime(true);
    $debounce = fn_ap_safecache_purge_everything_cron_debounce_sec();
    if ($debounce > 0 && ($now - $wanted['at']) < $debounce) {
        echo 'OK: ' . __('ap_safecache.pe_flush_cron_wait_debounce');

        return;
    }

    $interval = fn_ap_safecache_purge_everything_min_interval_sec();
    if ($interval > 0) {
        $key_last = fn_ap_safecache_purge_everything_storage_key_last_http();
        $last_raw = function_exists('fn_get_storage_data') ? fn_get_storage_data($key_last) : null;
        $last = is_numeric($last_raw) ? (float) $last_raw : 0.0;
        if ($last > 0 && ($now - $last) < $interval) {
            echo 'OK: ' . __('ap_safecache.pe_flush_cron_wait_throttle');

            return;
        }
    }

    $notification_title = __('ap_safecache.notification_title_purge');

    list($lat_ok, $lat_msg) = fn_ap_safecache_license_action_token_ensure_for_pro_write();
    if (!$lat_ok) {
        http_response_code(500);
        echo 'ERROR: ' . $lat_msg;

        return;
    }

    $token = isset($addon['cloudflare_api_token']) ? trim((string) $addon['cloudflare_api_token']) : '';
    $zone_id = isset($addon['cloudflare_zone_id']) ? trim((string) $addon['cloudflare_zone_id']) : '';

    if ($token === '' || $zone_id === '') {
        http_response_code(503);
        echo 'ERROR: ' . __('ap_safecache.err_cf_zone_required_for_purge');

        return;
    }

    list($ok, $err) = fn_ap_safecache_cloudflare_purge_post($token, $zone_id, ['purge_everything' => true]);

    if (!$ok) {
        http_response_code(500);
        echo 'ERROR: ' . $err;

        return;
    }

    if (function_exists('fn_set_storage_data')) {
        fn_set_storage_data(fn_ap_safecache_purge_everything_storage_key_last_http(), (string) microtime(true));
    }
    fn_ap_safecache_purge_everything_wanted_clear();

    $src_keys = array_keys($wanted['sources']);
    $src = $src_keys !== [] ? implode(',', $src_keys) : 'wanted';

    echo 'OK: ' . __('ap_safecache.pe_flush_cron_ok', ['[sources]' => $src]);
}

/**
 * 管理画面フック import_post
 *
 * @param array<string, mixed> $pattern
 * @param array<string, mixed> $import_data
 * @param array<string, mixed> $options
 * @param bool                   $result
 * @param array<string, mixed> $processed_data
 */
function fn_ap_safecache_import_post($pattern, $import_data, $options, $result, $processed_data)
{
    if (!defined('AREA') || AREA !== 'A') {
        return;
    }
    if (!$result) {
        return;
    }

    if (function_exists('fn_ap_safecache_purge_queue_is_enabled') && fn_ap_safecache_purge_queue_is_enabled()) {
        $table = isset($pattern['table']) ? (string) $pattern['table'] : '';
        if ($table === 'products' && function_exists('fn_ap_safecache_purge_queue_product_tags_from_import_data')) {
            $tags = fn_ap_safecache_purge_queue_product_tags_from_import_data($import_data);
            $pids = function_exists('fn_ap_safecache_purge_queue_product_ids_from_import_data')
                ? fn_ap_safecache_purge_queue_product_ids_from_import_data($import_data)
                : [];
            if ($pids !== [] && function_exists('fn_ap_safecache_purge_queue_distinct_category_tags_for_product_ids')) {
                $tags = array_merge($tags, fn_ap_safecache_purge_queue_distinct_category_tags_for_product_ids($pids));
            }
            $tags[] = fn_ap_safecache_cf_purge_tag_search_results();
            $tags = array_values(array_unique(array_filter(array_map('strval', $tags))));
            sort($tags);
            if ($tags !== [] && function_exists('fn_ap_safecache_purge_queue_enqueue_tags')) {
                $cid = function_exists('fn_ap_safecache_purge_queue_runtime_company_id')
                    ? fn_ap_safecache_purge_queue_runtime_company_id()
                    : (function_exists('fn_get_runtime_company_id') ? (int) fn_get_runtime_company_id() : 0);
                $imp_dk = fn_ap_safecache_purge_queue_dedupe_key_vendor_import_tags($cid);
                fn_ap_safecache_purge_queue_enqueue_tags($cid, $tags, 'import_post', $imp_dk);

                return;
            }
        }
    }

    fn_ap_safecache_purge_everything_scheduled(AP_SAFECACHE_PURGE_EVERYTHING_SRC_IMPORT_POST, [
        'silent_success' => true,
        'silent_errors'  => true,
    ]);
}

/**
 * 商品削除直前: `delete_product_post` 時点では `?:products_categories` が既に消えているため、カテゴリタグ用に退避。
 *
 * @param int|string $product_id
 * @param bool       $status
 *
 * @return void
 */
function fn_ap_safecache_delete_product_pre($product_id, &$status)
{
    if (!defined('AREA') || AREA !== 'A') {
        return;
    }

    Registry::del('ap_safecache_delete_product_category_tag_list');

    if (!function_exists('fn_ap_safecache_purge_queue_is_enabled') || !fn_ap_safecache_purge_queue_is_enabled()) {
        return;
    }

    if ($status === false) {
        return;
    }

    $pid = (int) $product_id;
    if ($pid <= 0) {
        return;
    }

    if (function_exists('fn_ap_safecache_purge_queue_category_tags_for_product_id')) {
        Registry::set('ap_safecache_delete_product_category_tag_list', fn_ap_safecache_purge_queue_category_tags_for_product_id($pid));
    }
}

/**
 * @param array<string, mixed> $product_data
 * @param int|string           $product_id
 * @param string               $lang_code
 * @param bool                 $create
 */
function fn_ap_safecache_update_product_post($product_data, $product_id, $lang_code, $create)
{
    if (!defined('AREA') || AREA !== 'A') {
        return;
    }

    if (function_exists('fn_ap_safecache_purge_queue_is_enabled') && fn_ap_safecache_purge_queue_is_enabled()) {
        $pid = (int) $product_id;
        if ($pid > 0 && function_exists('fn_ap_safecache_purge_queue_merge_vendor_tags')) {
            $cid = fn_ap_safecache_purge_queue_runtime_company_id();
            $tags = [fn_ap_safecache_cf_purge_tag_product($pid)];
            if (function_exists('fn_ap_safecache_purge_queue_category_tags_for_product_id')) {
                $tags = array_merge($tags, fn_ap_safecache_purge_queue_category_tags_for_product_id($pid));
            }
            $tags[] = fn_ap_safecache_cf_purge_tag_search_results();
            $tags = array_values(array_unique(array_filter(array_map('strval', $tags))));
            sort($tags);
            if (fn_ap_safecache_purge_queue_merge_vendor_tags($cid, $tags, 'update_product_post')) {
                return;
            }
        }
    }

    fn_ap_safecache_purge_everything_scheduled(AP_SAFECACHE_PURGE_EVERYTHING_SRC_UPDATE_PRODUCT_POST, [
        'silent_success' => true,
        'silent_errors'  => true,
    ]);
}

/**
 * @param int|string $product_id
 * @param bool       $product_deleted
 */
function fn_ap_safecache_delete_product_post($product_id, $product_deleted)
{
    if (!defined('AREA') || AREA !== 'A') {
        return;
    }

    $extra_cat = Registry::get('ap_safecache_delete_product_category_tag_list');
    Registry::del('ap_safecache_delete_product_category_tag_list');
    $extra_cat = is_array($extra_cat) ? $extra_cat : [];

    if (function_exists('fn_ap_safecache_purge_queue_is_enabled') && fn_ap_safecache_purge_queue_is_enabled()) {
        $pid = (int) $product_id;
        if ($pid > 0 && function_exists('fn_ap_safecache_purge_queue_merge_vendor_tags')) {
            $cid = fn_ap_safecache_purge_queue_runtime_company_id();
            $tags = array_merge([fn_ap_safecache_cf_purge_tag_product($pid)], $extra_cat, [fn_ap_safecache_cf_purge_tag_search_results()]);
            $tags = array_values(array_unique(array_filter(array_map('strval', $tags))));
            sort($tags);
            if (fn_ap_safecache_purge_queue_merge_vendor_tags($cid, $tags, 'delete_product_post')) {
                return;
            }
        }
    }

    fn_ap_safecache_purge_everything_scheduled(AP_SAFECACHE_PURGE_EVERYTHING_SRC_DELETE_PRODUCT_POST, [
        'silent_success' => true,
        'silent_errors'  => true,
    ]);
}

/**
 * @param array<string, mixed> $category_data
 */
function fn_ap_safecache_update_category_post($category_data, $category_id, $lang_code, $create)
{
    if (!defined('AREA') || AREA !== 'A') {
        return;
    }

    if (function_exists('fn_ap_safecache_purge_queue_is_enabled') && fn_ap_safecache_purge_queue_is_enabled()) {
        $cat_id = (int) $category_id;
        if ($cat_id > 0 && function_exists('fn_ap_safecache_purge_queue_merge_vendor_tags')) {
            $company_id = fn_ap_safecache_purge_queue_runtime_company_id();
            $tags = [fn_ap_safecache_cf_purge_tag_category($cat_id), fn_ap_safecache_cf_purge_tag_search_results()];
            sort($tags);
            if (fn_ap_safecache_purge_queue_merge_vendor_tags($company_id, $tags, 'update_category_post')) {
                return;
            }
        }
    }

    fn_ap_safecache_purge_everything_scheduled(AP_SAFECACHE_PURGE_EVERYTHING_SRC_UPDATE_CATEGORY_POST, [
        'silent_success' => true,
        'silent_errors'  => true,
    ]);
}

/**
 * @param int|string $category_id
 * @param bool       $recurse
 * @param list<int>  $category_ids
 */
function fn_ap_safecache_delete_category_post($category_id, $recurse, $category_ids)
{
    if (!defined('AREA') || AREA !== 'A') {
        return;
    }

    if (function_exists('fn_ap_safecache_purge_queue_is_enabled') && fn_ap_safecache_purge_queue_is_enabled()) {
        $seen = [];
        $root = (int) $category_id;
        if ($root > 0) {
            $seen[$root] = true;
        }
        if (is_array($category_ids)) {
            foreach ($category_ids as $id) {
                $id = (int) $id;
                if ($id > 0) {
                    $seen[$id] = true;
                }
            }
        }
        $tags = [];
        foreach (array_keys($seen) as $id) {
            $tags[] = fn_ap_safecache_cf_purge_tag_category($id);
        }
        $tags[] = fn_ap_safecache_cf_purge_tag_search_results();
        sort($tags);
        if ($tags !== [] && function_exists('fn_ap_safecache_purge_queue_merge_vendor_tags')) {
            $cid = fn_ap_safecache_purge_queue_runtime_company_id();
            if (fn_ap_safecache_purge_queue_merge_vendor_tags($cid, $tags, 'delete_category_post')) {
                return;
            }
        }
    }

    fn_ap_safecache_purge_everything_scheduled(AP_SAFECACHE_PURGE_EVERYTHING_SRC_DELETE_CATEGORY_POST, [
        'silent_success' => true,
        'silent_errors'  => true,
    ]);
}

/**
 * @param string $type  misc|registry|static|assets|all 等
 * @param string $extra
 */
function fn_ap_safecache_clear_cache_post($type, $extra)
{
    if (!defined('AREA') || AREA !== 'A') {
        return;
    }
    if (Registry::get('ap_safecache_suppress_pe_on_clear_cache')) {
        return;
    }
    if ((string) $type !== 'all') {
        return;
    }

    fn_ap_safecache_purge_everything_scheduled(AP_SAFECACHE_PURGE_EVERYTHING_SRC_CLEAR_CACHE_POST, [
        'silent_success' => true,
        'silent_errors'  => true,
    ]);
}
