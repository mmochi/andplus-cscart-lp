<?php

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}

$schema['ap_safecache']['allow']['cron_cf_poll'] = true;
$schema['ap_safecache']['allow']['cron_freemius_sync'] = true;
$schema['ap_safecache']['allow']['cron_pe_flush'] = true;
$schema['ap_safecache']['allow']['cron_purge_queue'] = true;

return $schema;
