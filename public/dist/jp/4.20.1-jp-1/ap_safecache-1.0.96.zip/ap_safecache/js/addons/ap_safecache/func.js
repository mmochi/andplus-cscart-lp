(function (_, $) {
  /**
   * 生 HTML から外部 script の URL を列挙（jQuery パース前に使う。パースで script が落ちる場合があるため）。
   */
  function extractScriptSrcsFromHtml(html) {
    if (!html || typeof html !== 'string') {
      return [];
    }
    var out = [];
    var re = /<script[^>]*\ssrc\s*=\s*["']([^"']+)["'][^>]*>\s*<\/script>/gi;
    var m;
    while ((m = re.exec(html)) !== null) {
      if (m[1]) {
        out.push(m[1]);
      }
    }
    return out;
  }

  /**
   * インライン script を実行（Tygh の Ajax と同様。ブロック内の初期化用）。
   */
  function runInlineScriptsFromHtml(html) {
    if (!html || typeof html !== 'string') {
      return;
    }
    var re = /<script(?![^>]*\bsrc\s*=)([^>]*)>([\s\S]*?)<\/script>/gi;
    var m;
    while ((m = re.exec(html)) !== null) {
      var code = m[2];
      if (code && $.trim(code).length) {
        try {
          $.globalEval(code);
        } catch (e) {}
      }
    }
  }

  function getMultiScripts(arr, cacheBustParam) {
    var bust = cacheBustParam != null ? String(cacheBustParam) : String(Date.now());
    var _arr = $.map(arr, function (scr) {
      if (!scr) {
        return $.Deferred().resolve().promise();
      }
      var sep = scr.indexOf('?') >= 0 ? '&' : '?';
      return $.getScript(scr + sep + 'ap_sc_cb=' + encodeURIComponent(bust));
    });
    _arr.push($.Deferred(function (deferred) {
      $(deferred.resolve);
    }));
    return $.when.apply($, _arr);
  }

  /**
   * block_manager.render が返した HTML を差し替え（共通処理）。
   */
  function applyReloadBlockHtml(item, rawHtml, apScTs) {
    if (!rawHtml || typeof rawHtml !== 'string' || !$.trim(rawHtml).length) {
      return false;
    }
    var $target;
    if (item && item.element_id) {
      if (typeof $.escapeSelector === 'function') {
        $target = $('#' + $.escapeSelector(item.element_id));
      } else {
        $target = $('#' + item.element_id);
      }
    } else {
      return false;
    }
    if (!$target.length) {
      return false;
    }
    var content = $(rawHtml);
    content.toggleClass('cm-block-loaded');
    var scripts = extractScriptSrcsFromHtml(rawHtml);
    if (!scripts.length) {
      content.find('script[src]').each(function () {
        if (this.src) {
          scripts.push(this.src);
        }
      });
    }
    function doReplaceIntoDom() {
      content.find('script[src]').remove();
      $('.cm-block-loaded', $target).remove();
      $target.replaceWith(content);
      $.commonInit(content);
      runInlineScriptsFromHtml(rawHtml);
    }
    if (!scripts.length) {
      doReplaceIntoDom();
    } else {
      getMultiScripts(scripts, apScTs).always(doReplaceIntoDom);
    }
    return true;
  }

  /**
   * フォールバック GET 用の URL（Tygh の _.current_url はクエリ欠落等があるためブラウザ実URLを優先）。
   */
  function getApSafecacheReloadFallbackPageUrl() {
    try {
      if (typeof window !== 'undefined' && window.location && window.location.href) {
        return String(window.location.href);
      }
    } catch (e) {}
    return _.current_url && typeof _.current_url === 'string' ? _.current_url : '';
  }

  /**
   * 極大 HTML 向け: id 属性で始まる div の outerHTML を文字列だけで切り出す（DOMParser / parseHTML が重すぎる・落ちる場合の保険）。
   * メイン検索結果ブロックは商品一覧を含み非常に長い。
   */
  function extractOuterHtmlForDivWithId(html, elementId) {
    if (!html || typeof html !== 'string' || !elementId) {
      return '';
    }
    var idDouble = 'id="' + elementId + '"';
    var idSingle = "id='" + elementId + "'";
    var pos = html.indexOf(idDouble);
    if (pos === -1) {
      pos = html.indexOf(idSingle);
    }
    if (pos === -1) {
      return '';
    }
    var tagStart = html.lastIndexOf('<div', pos);
    if (tagStart === -1 || tagStart > pos) {
      return '';
    }
    var gt = html.indexOf('>', tagStart);
    if (gt === -1 || gt < pos) {
      return '';
    }
    var lower = html.toLowerCase();
    var depth = 1;
    var i = gt + 1;
    while (depth > 0 && i < html.length) {
      var o = lower.indexOf('<div', i);
      var c = lower.indexOf('</div>', i);
      if (c === -1) {
        return '';
      }
      if (o !== -1 && o < c) {
        depth++;
        i = o + 4;
      } else {
        depth--;
        i = c + 6;
      }
    }
    if (depth !== 0) {
      return '';
    }
    return html.substring(tagStart, i);
  }

  function escapeApSafecacheRegExp(str) {
    return String(str).replace(/[\\^$.*+?()[\]{}|]/g, '\\$&');
  }

  /**
   * 極大 HTML で DOMParser / parseHTML が外す・誤る場合の id 抽出（div 以外のラッパーや、先頭付近の誤 indexOf 対策）。
   * 属性としての id= の出現ごとに、直前の開始タグから入れ子で outerHTML を切り出す。
   */
  function extractOuterHtmlForAnyElementByIdStringFallback(html, elementId) {
    if (!html || typeof html !== 'string' || !elementId) {
      return '';
    }
    var lower = html.toLowerCase();
    var re = new RegExp('\\bid\\s*=\\s*(["\'])' + escapeApSafecacheRegExp(elementId) + '\\1', 'gi');
    var m;
    while ((m = re.exec(html)) !== null) {
      var pos = m.index;
      var lt = html.lastIndexOf('<', pos);
      if (lt === -1 || lt > pos) {
        continue;
      }
      var nameMatch = /^<([a-z0-9:-]+)/i.exec(html.substring(lt, Math.min(lt + 64, html.length)));
      if (!nameMatch || !nameMatch[1]) {
        continue;
      }
      var tagLc = nameMatch[1].toLowerCase();
      var openEnd = html.indexOf('>', lt);
      if (openEnd === -1 || openEnd < pos) {
        continue;
      }
      var openSlice = lower.substring(lt, openEnd + 1);
      if (/\/>$/.test(openSlice.trim())) {
        continue;
      }
      var closeNeedle = '</' + tagLc + '>';
      var openNeedle = '<' + tagLc;
      var depth = 1;
      var i = openEnd + 1;
      while (depth > 0 && i < html.length) {
        var nextOpen = -1;
        var scan = i;
        while (true) {
          nextOpen = lower.indexOf(openNeedle, scan);
          if (nextOpen === -1) {
            break;
          }
          var boundary = nextOpen + openNeedle.length;
          var bch = lower.charAt(boundary);
          if (bch && /[\s/>]/.test(bch)) {
            break;
          }
          scan = nextOpen + 1;
        }
        var nextClose = lower.indexOf(closeNeedle, i);
        if (nextClose === -1) {
          break;
        }
        if (nextOpen !== -1 && nextOpen < nextClose) {
          depth++;
          var nestGt = html.indexOf('>', nextOpen);
          if (nestGt === -1) {
            break;
          }
          i = nestGt + 1;
        } else {
          depth--;
          i = nextClose + closeNeedle.length;
        }
      }
      if (depth === 0 && i > lt) {
        return html.substring(lt, i);
      }
    }
    return extractOuterHtmlForDivWithId(html, elementId);
  }

  /**
   * HTML 文字列から snapping ルート要素を探す（DOMParser と jQuery の両方を試す）。
   */
  function findSnappingElementInHtmlString(html, elementId) {
    if (!html || !elementId) {
      return null;
    }
    var el = null;
    try {
      if (window.DOMParser) {
        var doc = new DOMParser().parseFromString(html, 'text/html');
        el = doc.getElementById(elementId);
        if (el && el.outerHTML) {
          return el;
        }
      }
    } catch (e1) {}
    try {
      var $wrap = $('<div>');
      $wrap.append($.parseHTML(html, document, true));
      var sel = typeof $.escapeSelector === 'function' ? '#' + $.escapeSelector(elementId) : '#' + elementId;
      var $n = $wrap.find(sel);
      if ($n.length && $n[0].outerHTML) {
        return $n[0];
      }
    } catch (e2) {}
    return null;
  }

  /**
   * 取得 HTML から任意の id 要素の outerHTML を得る（ブロック snapping 以外の DOM 差し替え用）。
   */
  function extractOuterHtmlForAnyElementById(html, elementId) {
    if (!html || typeof html !== 'string' || !elementId) {
      return '';
    }
    var el = findSnappingElementInHtmlString(html, elementId);
    if (el && el.outerHTML) {
      return el.outerHTML;
    }
    return extractOuterHtmlForAnyElementByIdStringFallback(html, elementId);
  }

  /**
   * Tygh は `X-Requested-With: XMLHttpRequest` があると Ajax 初期化が走り、内部リクエストでない GET でも
   * 応答が空／JSON 化することがある。フルページ HTML を期待する GET では jQuery `$.ajax` を使わない。
   * `window.AP_SAFECACHE_DOM_FETCH_USE_JQUERY_AJAX === true` のときだけ従来の $.ajax にフォールバック（調査用）。
   *
   * @param {string} url
   * @param {Object.<string, string>} headersObj
   * @param {function(string)} onSuccess
   * @param {function()} [onFail]
   */
  function fetchFullPageHtmlNoAjaxHeader(url, headersObj, onSuccess, onFail) {
    headersObj = headersObj || {};
    function tryXhr() {
      try {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', url, true);
        xhr.withCredentials = true;
        var hk;
        for (hk in headersObj) {
          if (Object.prototype.hasOwnProperty.call(headersObj, hk) && typeof headersObj[hk] === 'string') {
            xhr.setRequestHeader(hk, headersObj[hk]);
          }
        }
        xhr.onload = function () {
          if (xhr.status >= 200 && xhr.status < 400) {
            onSuccess(xhr.responseText || '');
          } else if (typeof onFail === 'function') {
            onFail();
          }
        };
        xhr.onerror = function () {
          if (typeof onFail === 'function') {
            onFail();
          }
        };
        xhr.send();
      } catch (eXhr0) {
        if (typeof onFail === 'function') {
          onFail();
        }
      }
    }
    if (window.AP_SAFECACHE_DOM_FETCH_USE_JQUERY_AJAX === true) {
      $.ajax({
        url: url,
        type: 'GET',
        dataType: 'html',
        cache: false,
        headers: headersObj
      })
        .done(function (html) {
          onSuccess(typeof html === 'string' ? html : '');
        })
        .fail(function () {
          if (typeof onFail === 'function') {
            onFail();
          }
        });
      return;
    }
    if (typeof window.fetch !== 'function') {
      tryXhr();
      return;
    }
    var fetchHeaders = {};
    var hk2;
    for (hk2 in headersObj) {
      if (Object.prototype.hasOwnProperty.call(headersObj, hk2) && typeof headersObj[hk2] === 'string') {
        fetchHeaders[hk2] = headersObj[hk2];
      }
    }
    window
      .fetch(url, {
        method: 'GET',
        credentials: 'same-origin',
        cache: 'no-store',
        redirect: 'follow',
        headers: fetchHeaders
      })
      .then(function (res) {
        if (!res || !res.ok) {
          throw new Error('bad status');
        }
        return res.text();
      })
      .then(function (text) {
        onSuccess(text || '');
      })
      .catch(function () {
        tryXhr();
      });
  }

  /**
   * メインコンテンツブロック等: block_manager.render は content_tpl が無く空になる。現在URLのHTMLを取得し
   * 同一 snapping の要素を抜き出して差し替える（ログイン直後のセッションで再描画される）。
   *
   * mainbox_general.tpl は {if $content|trim} のため本文が空の HTML には id="snapping_id_*" 自体が出ない。
   * Edge/CF が古い本文空キャッシュを返すと抽出に失敗しうる。
   * メイン枠は商品一覧を含み HTML が極大になり、DOMParser / parseHTML が実質失敗することがあるため、
   * id 属性基準の文字列スキャン（div の入れ子深度）も試す。
   * 自動 location.reload は「取得HTMLに ID が無いが live DOM にはある」ケースで毎回再発し無限ループになるため行わない。
   */
  function reloadBlockViaFullPageSnapping(item, apScTs) {
    var fetchUrl = getApSafecacheReloadFallbackPageUrl();
    if (!fetchUrl || typeof fetchUrl !== 'string') {
      return;
    }
    var sep = fetchUrl.indexOf('?') >= 0 ? '&' : '?';
    fetchUrl = fetchUrl + sep + 'ap_sc_fb=' + encodeURIComponent(String(apScTs));
    if (window.AP_SAFECACHE_LOG_AJAX_BLOCK_RELOAD) {
      try {
        console.info('[ap_safecache] reloadBlock fallback GET (empty block_content)', {
          element_id: item.element_id,
          block_id: item.block_id
        });
      } catch (e) {}
    }
    var blockHeaders = {
      'Cache-Control': 'no-cache',
      Pragma: 'no-cache'
    };
    var extraHb = window.AP_SAFECACHE_DOM_FETCH_HEADERS;
    if (extraHb && typeof extraHb === 'object') {
      var hkb;
      for (hkb in extraHb) {
        if (Object.prototype.hasOwnProperty.call(extraHb, hkb) && typeof extraHb[hkb] === 'string') {
          blockHeaders[hkb] = extraHb[hkb];
        }
      }
    }
    var onHtml = function (html) {
      if (!html || typeof html !== 'string') {
        return;
      }
      var el = findSnappingElementInHtmlString(html, item.element_id);
      var raw = el && el.outerHTML ? el.outerHTML : '';
      if (!raw) {
        raw = extractOuterHtmlForDivWithId(html, item.element_id);
      }
      if (raw) {
        applyReloadBlockHtml(item, raw, apScTs);
        return;
      }
      if (window.AP_SAFECACHE_LOG_AJAX_BLOCK_RELOAD) {
        try {
          console.warn('[ap_safecache] reloadBlock fallback: node not found in fetched HTML (no auto-reload)', item.element_id);
        } catch (e4) {}
      }
    };
    fetchFullPageHtmlNoAjaxHeader(fetchUrl, blockHeaders, onHtml, function () {
      if (window.AP_SAFECACHE_LOG_AJAX_BLOCK_RELOAD) {
        try {
          console.warn('[ap_safecache] reloadBlock fallback GET failed');
        } catch (e5) {}
      }
    });
  }

  /**
   * HTML 文字列から id 設定どおりに断片を抜き出して live DOM へ適用する（GET 応答・Ajax JSON 内 HTML 兼用）。
   *
   * @param {string} html
   * @param {string[]} ids
   * @param {number} apScTs
   * @param {boolean} logMiss 取得 HTML に無い id を warn するか（GET 時 true、Ajax スニファ時 false）
   */
  function applyDomFragmentPatchesFromHtmlString(html, ids, apScTs, logMiss) {
    ids = ids || [];
    if (!html || typeof html !== 'string') {
      return;
    }
    var k;
    for (k = 0; k < ids.length; k++) {
      var eid = ids[k];
      if (!eid || typeof eid !== 'string') {
        continue;
      }
      var raw = extractOuterHtmlForAnyElementById(html, eid);
      if (raw) {
        applyReloadBlockHtml({ element_id: eid }, raw, apScTs);
      } else if (logMiss && window.AP_SAFECACHE_LOG_AJAX_BLOCK_RELOAD) {
        try {
          console.warn('[ap_safecache] dom reload: id not found in fetched HTML', eid);
        } catch (eDom1) {}
      }
    }
  }

  /**
   * Tygh Ajax の JSON（text 全文／html 断片）に DOM 再取得対象が含まれていれば即適用する。
   * ログイン直後など GET がまだゲストキャッシュを返す場合の補助。
   */
  function tryApplyDomFragmentsFromAjaxResponse(response_data, ids, apScTs) {
    if (!response_data || typeof response_data !== 'object') {
      return;
    }
    ids = ids || [];
    if (!ids.length) {
      return;
    }
    var chunks = [];
    if (typeof response_data.text === 'string' && response_data.text.length) {
      chunks.push(response_data.text);
    }
    if (response_data.html && typeof response_data.html === 'object') {
      var hid;
      for (hid in response_data.html) {
        if (!Object.prototype.hasOwnProperty.call(response_data.html, hid)) {
          continue;
        }
        var hv = response_data.html[hid];
        if (typeof hv === 'string' && hv.length) {
          chunks.push(hv);
        }
      }
    }
    var ci;
    for (ci = 0; ci < chunks.length; ci++) {
      applyDomFragmentPatchesFromHtmlString(chunks[ci], ids, apScTs, false);
    }
  }

  /**
   * 設定された HTML id のノードを、現在ページの GET HTML から抜き出して差し替える。
   * Cloudflare 等で「カート／ウィッシュリストだけバイパス」のとき、他 URL はエッジのゲスト HTML のまま返り得る。
   * その場合は本関数の GET もキャッシュヒットし、ID 抜き差しは実行されても中身が変わらない。キャッシュキー用に
   * `ap_sc_dom` に加え `_ap_safecache_nocache` を付与し、必要なら `window.AP_SAFECACHE_DOM_FETCH_HEADERS` で独自ヘッダを足す。
   * 取得は `fetch`／XHR（`X-Requested-With` なし）。jQuery `$.ajax` は Tygh が Ajax 扱いし本文が空になることがある。
   *
   * @param {string[]} ids
   * @param {number} apScTs
   */
  function reloadDomFragmentsViaFullPage(ids, apScTs) {
    ids = ids || [];
    if (!ids.length) {
      return;
    }
    var fetchUrl = getApSafecacheReloadFallbackPageUrl();
    if (!fetchUrl || typeof fetchUrl !== 'string') {
      return;
    }
    var sep = fetchUrl.indexOf('?') >= 0 ? '&' : '?';
    fetchUrl =
      fetchUrl +
      sep +
      'ap_sc_dom=' +
      encodeURIComponent(String(apScTs)) +
      '&_ap_safecache_nocache=' +
      encodeURIComponent(String(apScTs));
    if (window.AP_SAFECACHE_LOG_AJAX_BLOCK_RELOAD) {
      try {
        console.info('[ap_safecache] reloadDomFragmentsViaFullPage', {
          ids: ids,
          ap_sc_ts: apScTs
        });
      } catch (eDom0) {}
    }
    var ajaxHeaders = {
      'Cache-Control': 'no-cache',
      Pragma: 'no-cache'
    };
    var extraH = window.AP_SAFECACHE_DOM_FETCH_HEADERS;
    if (extraH && typeof extraH === 'object') {
      var hk;
      for (hk in extraH) {
        if (Object.prototype.hasOwnProperty.call(extraH, hk) && typeof extraH[hk] === 'string') {
          ajaxHeaders[hk] = extraH[hk];
        }
      }
    }
    fetchFullPageHtmlNoAjaxHeader(
      fetchUrl,
      ajaxHeaders,
      function (html) {
        applyDomFragmentPatchesFromHtmlString(html, ids, apScTs, true);
      },
      function () {
        if (window.AP_SAFECACHE_LOG_AJAX_BLOCK_RELOAD) {
          try {
            console.warn('[ap_safecache] dom reload: GET failed');
          } catch (eDom2) {}
        }
      }
    );
  }

  /**
   * 商品一覧ブロック: #pagination_contents がこの snapping 配下なら、block_manager.render は TYPE_MAIN で常に空。
   * フィルタと同様に Tygh の result_ids Ajax で #pagination_contents だけ再取得する（会員価格が反映される）。
   */
  function shouldReloadListingViaPaginationContents(item) {
    if (!item || !item.element_id) {
      return false;
    }
    try {
      var $pc = $('#pagination_contents');
      if (!$pc.length) {
        return false;
      }
      var wrapId = $pc.closest('[id^="snapping_id_"]').prop('id');
      return !!wrapId && wrapId === item.element_id;
    } catch (e) {
      return false;
    }
  }

  function reloadListingViaPaginationContents(apScTs) {
    if (typeof $.ceAjax !== 'function') {
      return false;
    }
    var base = getApSafecacheReloadFallbackPageUrl();
    if (!base || typeof base !== 'string') {
      return false;
    }
    var sep = base.indexOf('?') >= 0 ? '&' : '?';
    var url = base + sep + 'ap_sc_pl=' + encodeURIComponent(String(apScTs));
    if (window.AP_SAFECACHE_LOG_AJAX_BLOCK_RELOAD) {
      try {
        console.info('[ap_safecache] reloadBlock: pagination_contents (Tygh result_ids)', { ap_sc_ts: apScTs });
      } catch (e) {}
    }
    $.ceAjax('request', url, {
      method: 'get',
      result_ids: 'pagination_contents',
      hidden: true,
      caching: false
    });
    return true;
  }

  function reloadBlock(item) {
    var apScTs = Date.now();
    if (window.AP_SAFECACHE_LOG_AJAX_BLOCK_RELOAD) {
      try {
        console.info('[ap_safecache] reloadBlock', {
          element_id: item.element_id,
          block_id: item.block_id,
          snapping_id: item.snapping_id,
          ap_sc_ts: apScTs
        });
      } catch (e) {}
    }
    if (shouldReloadListingViaPaginationContents(item) && reloadListingViaPaginationContents(apScTs)) {
      return;
    }
    var url = fn_url('block_manager.render');
    $.ceAjax('request', url, {
      // GET: コア block_loader と同様。CS-Cart の CSRF は POST のみ検証するため、
      // キャッシュ HTML 内の security_hash とセッションがずれても弾かれない。
      method: 'get',
      hidden: true,
      caching: false,
      data: {
        object_key: item.object_key,
        redirect_url: _.current_url,
        ap_sc_ts: String(apScTs)
      },
      callback: function (response) {
        var rawHtml = response && response.block_content;
        if (rawHtml && typeof rawHtml === 'string' && $.trim(rawHtml).length) {
          applyReloadBlockHtml(item, rawHtml, apScTs);
          return;
        }
        reloadBlockViaFullPageSnapping(item, apScTs);
      }
    });
  }

  /** 初回のみ。viewport 手前のマージンまで入ったら block_manager.render（未対応ブラウザは即時）。 */
  var AP_SAFECACHE_LAZY_LAYOUT_ROOT_MARGIN = '200px 0px 200px 0px';

  function reloadLayoutBlockWhenVisible(item) {
    var elId = item.element_id;
    if (!elId) {
      reloadBlock(item);
      return;
    }
    var $target;
    if (typeof $.escapeSelector === 'function') {
      $target = $('#' + $.escapeSelector(elId));
    } else {
      $target = $('#' + elId);
    }
    if (!$target.length) {
      reloadBlock(item);
      return;
    }
    if (!window.IntersectionObserver) {
      reloadBlock(item);
      return;
    }
    var node = $target[0];
    var obs = new IntersectionObserver(function (entries) {
      var k;
      for (k = 0; k < entries.length; k++) {
        if (entries[k].isIntersecting) {
          obs.disconnect();
          reloadBlock(item);
          return;
        }
      }
    }, {
      root: null,
      rootMargin: AP_SAFECACHE_LAZY_LAYOUT_ROOT_MARGIN,
      threshold: 0
    });
    obs.observe(node);
  }

  /**
   * Lazy 初回ブロック再読み込みが有効か。明示的に false のときだけオフ。
   * 未設定（テンプレ未反映・キャッシュ）のときは true（addon 既定）。
   */
  function isApSafecacheLazyReloadLayoutBlocksEnabled() {
    return window.AP_SAFECACHE_LAZY_RELOAD_LAYOUT_BLOCKS !== false;
  }

  /**
   * fn_change_options（exceptions.js）と同様のペイロード。商品詳細のみで使用。
   */
  function buildCmReloadProductsOptionsPayload(objId) {
    var formData = [];
    var varNames = [];
    var updateIds = [];
    var cacheQuery = true;
    var defaultValues = {};
    var parents = $('.cm-reload-' + objId);
    $.each(parents, function (idx, parentElm) {
      var reloadId = $(parentElm).prop('id');
      if (!reloadId) {
        return true;
      }
      updateIds.push(reloadId);
      defaultValues[reloadId] = {};
      var elms = $(':input:not([type=radio]):not([type=checkbox])', parentElm);
      $.each(elms, function (id2, elm) {
        if ($(elm).prop('disabled')) {
          return true;
        }
        if (elm.type !== 'submit' && elm.type !== 'file' && !($(elm).hasClass('cm-hint') && elm.value === elm.defaultValue) && elm.name && elm.name.length !== 0) {
          if (elm.name === 'no_cache' && elm.value) {
            cacheQuery = false;
          }
          formData.push({
            name: elm.name,
            value: elm.value
          });
          varNames.push(elm.name);
        }
      });
      elms = $(':input', parentElm);
      $.each(elms, function (id2, elm) {
        var elmId = $(elm).prop('id');
        if (!elmId) {
          return true;
        }
        if ($(elm).is('select')) {
          $('option', elm).each(function () {
            if (this.defaultSelected) {
              defaultValues[reloadId][elmId] = this.value;
            }
          });
        } else if ($(elm).is('input[type=radio], input[type=checkbox]')) {
          defaultValues[reloadId][elmId] = elm.defaultChecked;
        } else if (!$(elm).is('input[type=file]')) {
          defaultValues[reloadId][elmId] = elm.defaultValue;
        }
      });
    });
    var radio = $('input[type=radio]:checked, input[type=checkbox]', parents);
    $.each(radio, function (id2, elm) {
      if ($(elm).prop('disabled')) {
        return true;
      }
      var value = elm.value;
      if ($(elm).is('input[type=checkbox]:checked')) {
        if (!$(elm).hasClass('cm-no-change')) {
          value = $(elm).val();
        }
      } else if ($(elm).is('input[type=checkbox]')) {
        if ($.inArray(elm.name, varNames) !== -1) {
          return true;
        }
        if (!$(elm).hasClass('cm-no-change')) {
          value = 'unchecked';
        } else {
          value = '';
        }
      }
      formData.push({
        name: elm.name,
        value: value
      });
    });
    return {
      formData: formData,
      updateIds: updateIds,
      cacheQuery: cacheQuery,
      defaultValues: defaultValues
    };
  }

  function parseOptionIdAttribute(oid) {
    if (!oid || oid.indexOf('option_') !== 0) {
      return null;
    }
    var rest = oid.substring('option_'.length);
    var lu = rest.lastIndexOf('_');
    if (lu <= 0) {
      return null;
    }
    return {
      composite: rest.substring(0, lu),
      optionTail: rest.substring(lu + 1)
    };
  }

  /**
   * products.options を Tygh コアと同じ内容で再取得。hidden: true でローディング枠を出さない。
   */
  function requestProductOptionsReloadHidden(formSuffix, objKey, optionTail) {
    if (typeof $.ceAjax !== 'function' || typeof fn_url !== 'function') {
      return;
    }
    var pre = typeof fn_pre_process_form_files === 'function' ? fn_pre_process_form_files : function () {};
    var post = typeof fn_post_process_form_files === 'function' ? fn_post_process_form_files : function () {};

    var built = buildCmReloadProductsOptionsPayload(formSuffix);
    var formData = built.formData;
    var updateIds = built.updateIds;
    if (!updateIds.length) {
      return;
    }
    var cacheQuery = built.cacheQuery;
    var defaultValues = built.defaultValues;

    var apScPo = String(Date.now());
    var baseUrl =
      optionTail !== ''
        ? fn_url('products.options?changed_option[' + objKey + ']=' + encodeURIComponent(optionTail))
        : fn_url('products.options');
    var q0 = baseUrl.indexOf('?') >= 0 ? '&' : '?';
    var url = baseUrl + q0 + 'ap_sc_po=' + encodeURIComponent(apScPo);
    var i;
    for (i = 0; i < formData.length; i++) {
      url += '&' + formData[i].name + '=' + encodeURIComponent(formData[i].value);
    }

    var selfEl =
      optionTail !== ''
        ? $(':input[id*=_' + formSuffix + '_' + optionTail + ']').last()[0]
        : undefined;

    $.ceEvent('trigger', 'ce.product_option_changed', [formSuffix, objKey, optionTail, updateIds, formData]);

    $.ceAjax('request', url, {
      result_ids: updateIds.join(',').toString(),
      caching: cacheQuery,
      force_exec: true,
      hidden: true,
      pre_processing: pre,
      callback: function (data, params) {
        if (!data) {
          return;
        }
        post(data, params);
        var parents2 = $('.cm-reload-' + formSuffix);
        $.each(parents2, function (id3, parentElm) {
          if (data.html && data.html[$(parentElm).prop('id')]) {
            var reloadId = $(parentElm).prop('id');
            var elms = $(':input', parentElm);
            var checkedElms = [];
            if (defaultValues[reloadId] != null) {
              $.each(elms, function (id4, elm) {
                var elm_id = $(elm).prop('id');
                if (elm_id && defaultValues[reloadId][elm_id] != null) {
                  if ($(elm).is('select')) {
                    var selected = {};
                    var isSelected = false;
                    $('option', elm).each(function () {
                      selected[this.value] = this.defaultSelected;
                      this.defaultSelected = defaultValues[reloadId][elm_id] == this.value ? true : false;
                    });
                    $('option', elm).each(function () {
                      this.selected = selected[this.value];
                      if (this.selected == true) {
                        isSelected = true;
                      }
                    });
                    if (!isSelected) {
                      var firstOpt = $('option', elm).get(0);
                      if (firstOpt) {
                        firstOpt.selected = true;
                      }
                    }
                  } else if ($(elm).is('input[type=radio], input[type=checkbox]')) {
                    var checked = elm.defaultChecked;
                    if (checked) {
                      checkedElms.push(elm);
                    }
                    elm.defaultChecked = defaultValues[reloadId][elm_id];
                    elm.checked = checked;
                  } else {
                    var value = elm.defaultValue;
                    elm.defaultValue = defaultValues[reloadId][elm_id];
                    elm.value = value;
                  }
                }
              });
              $(checkedElms).prop('checked', true);
            }
          }
        });
        if (data.notifications) {
          for (var notificationKey in data.notifications) {
            if (data.notifications.hasOwnProperty(notificationKey)) {
              var notify = data.notifications[notificationKey];
              if (notify.extra == 'zero_inventory') {
                return;
              }
            }
          }
        }
        $.ceEvent('trigger', 'ce.product_option_changed_post', [
          formSuffix,
          objKey,
          optionTail,
          updateIds,
          formData,
          data,
          params,
          selfEl
        ]);
      },
      method: 'post'
    });
  }

  /**
   * 商品詳細か。PHP の window.AP_SAFECACHE_IS_PRODUCT_VIEW を優先し、
   * 未設定（テンプレ未反映・スマートキャッシュ等）のときは URL で判定する。
   */
  function isApSafecacheProductViewPage() {
    var v = window.AP_SAFECACHE_IS_PRODUCT_VIEW;
    if (v === true) {
      return true;
    }
    if (v === false) {
      return false;
    }
    try {
      var q = window.location.search || '';
      if (/[?&]dispatch=products\.view(?:&|$)/.test(q) && /[?&]product_id=\d+/.test(q)) {
        return true;
      }
    } catch (e) {}
    return false;
  }

  function reloadProductDetailForms() {
    if (!isApSafecacheProductViewPage()) {
      return;
    }
    $('form[name^="product_form_"]').each(function () {
      var $form = $(this);
      var name = $form.attr('name') || '';
      var m = /^product_form_(.+)$/.exec(name);
      if (!m) {
        return;
      }
      var formSuffix = m[1];
      if (!$('.cm-reload-' + formSuffix).length) {
        return;
      }
      var $pid = $form.find('input[name^="product_data["][name$="[product_id]"]');
      if (!$pid.length) {
        return;
      }
      var pm = /product_data\[(\d+)\]/.exec($pid.attr('name') || '');
      if (!pm) {
        return;
      }
      var objKey = pm[1];

      var optionTail = null;
      var $withId = $form.find('select[id^="option_"], input[id^="option_"]').first();
      if ($withId.length) {
        var parsed = parseOptionIdAttribute($withId.attr('id') || '');
        if (parsed && parsed.composite === formSuffix) {
          optionTail = parsed.optionTail;
        }
      }
      if (optionTail == null) {
        var $sel = $form.find('select[name*="product_options"]').first();
        if ($sel.length) {
          var om = /\[product_options\]\[(\d+)\]/.exec($sel.attr('name') || '');
          if (om) {
            optionTail = om[1];
          }
        }
      }
      if (optionTail == null) {
        requestProductOptionsReloadHidden(formSuffix, objKey, '');
        return;
      }
      requestProductOptionsReloadHidden(formSuffix, objKey, optionTail);
    });
  }

  /**
   * URL 文字列が auth.login / auth.logout / login_by_otp を向いているか（cm-ajax リンク用）。
   */
  function apSafecacheUrlLooksLikeAuthSessionChange(href) {
    if (!href || typeof href !== 'string') {
      return false;
    }
    var dec = href;
    try {
      dec = decodeURIComponent(href);
    } catch (e0) {}
    if (/dispatch[^&=]*=auth\.(?:logout|login|login_by_otp)\b/.test(dec)) {
      return true;
    }
    if (/dispatch\[auth\.(?:logout|login|login_by_otp)\]/i.test(dec)) {
      return true;
    }
    if (/dispatch%5Bauth\.(?:logout|login|login_by_otp)%5D/i.test(href)) {
      return true;
    }
    if (/\/auth\/logout(?:[/?#]|$)/i.test(dec) || /\/auth\/login(?:[/?#]|$)/i.test(dec)) {
      return true;
    }
    return false;
  }

  /**
   * ログイン／ログアウト系の Ajax 完了か（フォーム送信・cm-ajax リンクの両方）。
   * Tygh のリンク Ajax は params.form が無く params.obj に a 要素が乗る。
   */
  function isAuthSessionAjaxForm(params) {
    if (!params) {
      return false;
    }
    var blob = '';
    if (params.form && params.form.length) {
      var $f = params.form;
      $f.find(
        'input[name="dispatch"], input[name^="dispatch["], button[name^="dispatch["], select[name="dispatch"], select[name^="dispatch["]'
      ).each(function () {
        blob += ' ' + String($(this).val() || '');
      });
      if (/auth\.(login|logout|login_by_otp)/.test(blob)) {
        return true;
      }
      var nm = $f.attr('name') || '';
      if (/^login_/i.test(nm)) {
        return true;
      }
    }
    try {
      var $obj = params.obj;
      if ($obj && $obj.length) {
        if ($obj.is('a')) {
          var ah = $obj.prop('href') || $obj.attr('href') || '';
          if (apSafecacheUrlLooksLikeAuthSessionChange(String(ah))) {
            return true;
          }
        } else {
          var $a = $obj.closest('a');
          if ($a.length) {
            var ah2 = $a.prop('href') || $a.attr('href') || '';
            if (apSafecacheUrlLooksLikeAuthSessionChange(String(ah2))) {
              return true;
            }
          }
        }
      }
    } catch (eObj) {}
    try {
      var data = params.data;
      if (data && typeof data === 'object') {
        var dk;
        for (dk in data) {
          if (!Object.prototype.hasOwnProperty.call(data, dk)) {
            continue;
          }
          var v = data[dk];
          if (typeof v === 'string' && /auth\.(login|logout|login_by_otp)/.test(v)) {
            return true;
          }
        }
      }
    } catch (eData) {}
    return false;
  }

  /**
   * 店頭注入値が配列／JSON 文字列のどちらでも string[] に揃える（Smarty やミドルウェアで二重化した場合の保険）。
   */
  function normalizeApSafecacheStringList(value) {
    if ($.isArray(value)) {
      var out = [];
      var i;
      for (i = 0; i < value.length; i++) {
        if (typeof value[i] === 'string' && $.trim(value[i]).length) {
          out.push($.trim(value[i]));
        }
      }
      return out;
    }
    if (typeof value === 'string') {
      var s = $.trim(value);
      if (!s.length) {
        return [];
      }
      try {
        if (typeof JSON !== 'undefined' && JSON.parse) {
          var p = JSON.parse(s);
          if ($.isArray(p)) {
            return normalizeApSafecacheStringList(p);
          }
        }
      } catch (e0) {}
      if (typeof _.parseJSON === 'function') {
        try {
          var p2 = _.parseJSON(s);
          if ($.isArray(p2)) {
            return normalizeApSafecacheStringList(p2);
          }
        } catch (e1) {}
      }
    }
    return [];
  }

  /**
   * DOM 断片の再取得対象は `AP_SAFECACHE_AJAX_RELOAD_DOM_IDS`（サイト画面の一覧）に書いた id のみ。
   * テーマによって #navbar_mobile が無いため、コード側で id を自動追加しない。
   *
   * 従来: ページに #navbar_mobile があれば一覧に無くても追加していた。復旧する場合は下のコメントブロックを
   * 有効化し、`document.ready` 内の `ensureLiveNavbarMobileInDomIds(domIds);` のコメントも外す。
   */
  /*
  function ensureLiveNavbarMobileInDomIds(domIds) {
    if (window.AP_SAFECACHE_DISABLE_AUTO_NAVBAR_MOBILE_DOM) {
      return;
    }
    try {
      if (!document.getElementById('navbar_mobile')) {
        return;
      }
      var id = 'navbar_mobile';
      var i;
      for (i = 0; i < domIds.length; i++) {
        if (domIds[i] === id) {
          return;
        }
      }
      domIds.push(id);
    } catch (eNav) {}
  }
  */

  /**
   * Ajax の response_data.html に、セッション／ミニカート／マイアカウント周りの断片が含まれるとき true。
   * result_ids が tygh_main_container のみの一覧更新では反応しない。
   * profiles / wishlist / orders 等は cart_status を返さないことが多いためキーを広げる。
   */
  function isAjaxDomReloadFromSessionishHtmlKeys(response_data) {
    if (!response_data || !response_data.html || typeof response_data.html !== 'object') {
      return false;
    }
    var sessionishRe = /^(cart_status|account_info|sign_in|checkout_login|checkout_dropdown|auth_info|minicart|wishlist|profiles|orders|downloads|subscriptions|user_info|return_requests|reward_points|vendor_communication|gift_certificates|product_notifications)/i;
    var hid;
    for (hid in response_data.html) {
      if (!response_data.html.hasOwnProperty(hid)) {
        continue;
      }
      if (sessionishRe.test(hid)) {
        return true;
      }
    }
    return false;
  }

  $(document).ready(function () {
    var blocks = window.AP_SAFECACHE_AJAX_RELOAD_BLOCKS || [];
    if (!$.isArray(blocks)) {
      blocks = [];
    }
    var domIds = normalizeApSafecacheStringList(window.AP_SAFECACHE_AJAX_RELOAD_DOM_IDS);
    /* 自動で navbar_mobile を足す場合: 上の ensureLiveNavbarMobileInDomIds をコメント解除し、こちらも解除。 */
    // ensureLiveNavbarMobileInDomIds(domIds);
    var hasBlocks = blocks.length > 0;
    var hasDomIds = domIds.length > 0;
    var hasDomTargets = hasDomIds;
    var productDetail = isApSafecacheProductViewPage();
    var hasProductForms = $('form[name^="product_form_"]').length > 0;

    if (!hasBlocks && !(productDetail && hasProductForms) && !hasDomTargets) {
      return;
    }

    var debounceBlocks = null;
    function flushReloadLayoutBlocks() {
      var i;
      for (i = 0; i < blocks.length; i++) {
        reloadBlock(blocks[i]);
      }
    }
    function scheduleReloadBlocks() {
      if (!hasBlocks) {
        return;
      }
      if (debounceBlocks) {
        clearTimeout(debounceBlocks);
      }
      debounceBlocks = setTimeout(function () {
        debounceBlocks = null;
        if (window.AP_SAFECACHE_LOG_AJAX_BLOCK_RELOAD) {
          try {
            console.info('[ap_safecache] scheduleReloadBlocks', {
              blockCount: blocks.length
            });
          } catch (e) {}
        }
        flushReloadLayoutBlocks();
      }, 120);
    }
    function scheduleInitialLayoutBlocks() {
      var i;
      if (isApSafecacheLazyReloadLayoutBlocksEnabled()) {
        for (i = 0; i < blocks.length; i++) {
          reloadLayoutBlockWhenVisible(blocks[i]);
        }
      } else {
        scheduleReloadBlocks();
      }
    }

    var debounceDomFragments = null;
    function flushReloadDomFragments() {
      reloadDomFragmentsViaFullPage(domIds, Date.now());
    }
    function scheduleReloadDomFragments() {
      if (!hasDomTargets) {
        return;
      }
      if (debounceDomFragments) {
        clearTimeout(debounceDomFragments);
      }
      debounceDomFragments = setTimeout(function () {
        debounceDomFragments = null;
        if (window.AP_SAFECACHE_LOG_AJAX_BLOCK_RELOAD) {
          try {
            console.info('[ap_safecache] scheduleReloadDomFragments', {
              domIdCount: domIds.length
            });
          } catch (eDom3) {}
        }
        flushReloadDomFragments();
      }, 120);
    }
    function scheduleInitialDomFragments() {
      if (!hasDomTargets) {
        return;
      }
      /**
       * レイアウトブロック用 Lazy（viewport 入場）とは切り離す。
       * フッターや固定ナビは画面外にあり得、IntersectionObserver では初回再取得が来ない。
       */
      scheduleReloadDomFragments();
    }

    var debounceProductForms = null;
    function scheduleProductDetailFormReload(reason) {
      if (!productDetail || !hasProductForms) {
        return;
      }
      if (debounceProductForms) {
        clearTimeout(debounceProductForms);
      }
      debounceProductForms = setTimeout(function () {
        debounceProductForms = null;
        if (window.AP_SAFECACHE_LOG_AJAX_BLOCK_RELOAD) {
          try {
            console.info('[ap_safecache] scheduleProductDetailFormReload', { reason: reason || '' });
          } catch (e) {}
        }
        reloadProductDetailForms();
      }, 150);
    }

    if (hasBlocks || hasDomTargets) {
      $.ceEvent('on', 'ce.ajaxdone', function (elms, scripts, params, response_data) {
        // 商品フィルタ等（tygh_main_container のみ）では再読み込みしない。
        // 認証系 Ajax、または cart_status / account_info 等の断片が返る Ajax では DOM／ブロックを更新する。
        var authAjax = isAuthSessionAjaxForm(params);
        var sessionHtml = hasDomTargets && isAjaxDomReloadFromSessionishHtmlKeys(response_data);
        if (!authAjax && !sessionHtml) {
          return;
        }
        if (window.AP_SAFECACHE_LOG_AJAX_BLOCK_RELOAD && sessionHtml && !authAjax) {
          try {
            console.info('[ap_safecache] ce.ajaxdone dom reload (sessionish html keys)');
          } catch (eLog) {}
        }
        if (hasBlocks && authAjax) {
          scheduleReloadBlocks();
        }
        if (hasDomTargets) {
          tryApplyDomFragmentsFromAjaxResponse(response_data, domIds, Date.now());
          scheduleReloadDomFragments();
        }
      });
    }
    if (hasBlocks) {
      scheduleInitialLayoutBlocks();
    }
    if (hasDomTargets) {
      scheduleInitialDomFragments();
      /**
       * document.ready だけだと描画・キャッシュと競合することがある。window.load 後にもう一度だけスケジュール。
       * `window.AP_SAFECACHE_DOM_RELOAD_ON_WINDOW_LOAD = false` で無効化。
       */
      if (window.AP_SAFECACHE_DOM_RELOAD_ON_WINDOW_LOAD !== false) {
        $(window).one('load.ap_safecache_dom', function () {
          scheduleReloadDomFragments();
        });
      }
      /**
       * 一覧に明示した `navbar_mobile` について、トップ等で Tygh より遅れて挿入されると初回 GET で置換先が無い。
       * ready 時に未存在のときだけ遅延で再スケジュール。一覧に含めていない id では動かない。
       * `window.AP_SAFECACHE_DOM_FRAGMENT_RETRY_MS = 0` で無効化。
       */
      var domRetryMs = window.AP_SAFECACHE_DOM_FRAGMENT_RETRY_MS;
      if (domRetryMs == null) {
        domRetryMs = 450;
      }
      if (domRetryMs > 0 && hasDomIds && domIds.indexOf('navbar_mobile') >= 0) {
        try {
          if (!document.getElementById('navbar_mobile')) {
            setTimeout(function () {
              try {
                if (document.getElementById('navbar_mobile')) {
                  scheduleReloadDomFragments();
                }
              } catch (eRetryNav) {}
            }, domRetryMs);
          }
        } catch (eRetryGate) {}
      }
      window.addEventListener('pageshow', function (ev) {
        if (ev.persisted) {
          scheduleReloadDomFragments();
        }
      });
    }

    if (productDetail && hasProductForms) {
      scheduleProductDetailFormReload('load');

      $.ceEvent('on', 'ce.ajaxdone', function (elms, scripts, params, response_data) {
        if (!isAuthSessionAjaxForm(params)) {
          return;
        }
        if (!$('form[name^="product_form_"]').length) {
          return;
        }
        scheduleProductDetailFormReload('auth_ajax');
      });

      window.addEventListener('pageshow', function (ev) {
        if (ev.persisted && $('form[name^="product_form_"]').length) {
          scheduleProductDetailFormReload('pageshow');
        }
      });
    }
  });
})(Tygh, Tygh.$);
