<?php

/**
 * Pro の危険操作前に、自社ゲートウェイから短命トークンを取得してセッションに保持する（スコープは 1 種類で統一）。
 *
 * ゲートウェイ期待: POST JSON で
 *   product_id, install_uid, site_url, addon_version, license_key（任意）, scope（固定 "pro_cf_write"）
 * 応答 JSON: token または access_token、expires_at（Unix）または expires_in（秒）
 *
 * URL 未設定時はチェックしない（従来どおり Pro のみで可）。
 */

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}

require_once __DIR__ . '/ap_safecache_freemius_config.php';

use Tygh\Http;
use Tygh\Registry;

if (!defined('AP_SAFECACHE_LICENSE_ACTION_TOKEN_SCOPE')) {
    define('AP_SAFECACHE_LICENSE_ACTION_TOKEN_SCOPE', 'pro_cf_write');
}

/**
 * @return bool
 */
function fn_ap_safecache_license_action_token_gateway_configured()
{
    return defined('AP_SAFECACHE_LICENSE_ACTION_TOKEN_URL')
        && trim((string) AP_SAFECACHE_LICENSE_ACTION_TOKEN_URL) !== '';
}

/**
 * @return array<string, int|string>
 */
function fn_ap_safecache_license_action_token_get_bucket()
{
    // Tygh::$app['session'] は ArrayAccess（Tygh\Web\Session）のため is_array() に依存しない
    if (empty(Tygh::$app['session']) || !isset(Tygh::$app['session']['ap_safecache_license_action_token'])) {
        return [];
    }

    $b = Tygh::$app['session']['ap_safecache_license_action_token'];

    return is_array($b) ? $b : [];
}

/**
 * @return bool
 */
function fn_ap_safecache_license_action_token_session_valid()
{
    $b = fn_ap_safecache_license_action_token_get_bucket();
    $t = isset($b['t']) ? trim((string) $b['t']) : '';
    $exp = isset($b['exp']) ? (int) $b['exp'] : 0;

    // 同一秒・軽い時刻ずれでも有効とみなす
    return $t !== '' && $exp > (time() - 1);
}

/**
 * @param string $token
 * @param int    $exp_unix
 */
function fn_ap_safecache_license_action_token_save_to_session($token, $exp_unix)
{
    if (empty(Tygh::$app['session'])) {
        return;
    }

    Tygh::$app['session']['ap_safecache_license_action_token'] = [
        't'   => $token,
        'exp' => (int) $exp_unix,
    ];
}

/**
 * ゲートウェイ設定済みかつ Pro で、セッションに有効トークンが無い。
 *
 * @return bool
 */
function fn_ap_safecache_license_action_token_needs_fetch_for_pro_write()
{
    return fn_ap_safecache_license_action_token_gateway_configured()
        && fn_ap_safecache_is_pro()
        && !fn_ap_safecache_license_action_token_session_valid();
}

/**
 * Pro 書き込み前にゲートウェイへトークンを自動取得する。成功時はセッションに保持。
 *
 * @return array{0: bool, 1: string} [ok, message] message は失敗時のみ（成功時は空）
 */
function fn_ap_safecache_license_action_token_ensure_for_pro_write()
{
    if (function_exists('fn_ap_safecache_ensure_freemius_for_pro_write')) {
        list($license_ok, $license_msg) = fn_ap_safecache_ensure_freemius_for_pro_write();
        if (!$license_ok) {
            return [false, $license_msg !== '' ? $license_msg : __('ap_safecache.license_pro_only')];
        }
    }

    if (!fn_ap_safecache_license_action_token_gateway_configured()) {
        return [true, ''];
    }
    if (!fn_ap_safecache_is_pro()) {
        return [true, ''];
    }
    if (fn_ap_safecache_license_action_token_session_valid()) {
        return [true, ''];
    }

    return fn_ap_safecache_license_action_token_fetch_now();
}

/**
 * 管理画面 POST 等でブロックする。true = 中止（通知済み）。トークンは直前に自動取得を試みる。
 *
 * @return bool
 */
function fn_ap_safecache_license_action_token_abort_pro_write()
{
    if (!fn_ap_safecache_license_action_token_gateway_configured()) {
        return false;
    }
    if (!fn_ap_safecache_is_pro()) {
        return false;
    }

    list($ok, $msg) = fn_ap_safecache_license_action_token_ensure_for_pro_write();
    if ($ok) {
        return false;
    }

    fn_set_notification('E', __('ap_safecache.notification_title_license'), $msg);

    return true;
}

/**
 * @param string $safecache_focus_id fn_ap_safecache_manage_redirect_url 用
 *
 * @return array|null
 */
function fn_ap_safecache_license_action_token_redirect_or_null($safecache_focus_id)
{
    if (!fn_ap_safecache_license_action_token_gateway_configured() || !fn_ap_safecache_is_pro()) {
        return null;
    }

    list($ok, $msg) = fn_ap_safecache_license_action_token_ensure_for_pro_write();
    if ($ok) {
        return null;
    }

    fn_set_notification('E', __('ap_safecache.notification_title_license'), $msg);

    return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url($safecache_focus_id)];
}

/**
 * ページ表示用の「トークン未取得」文言は出さない（取得は各操作直前に自動）。常に null。
 *
 * @return null
 */
function fn_ap_safecache_license_action_token_block_message_or_null()
{
    return null;
}

/**
 * ゲートウェイからトークンを取得してセッションに保存。
 *
 * @return array{0: bool, 1: string}
 */
function fn_ap_safecache_license_action_token_fetch_now()
{
    if (!fn_ap_safecache_license_action_token_gateway_configured()) {
        return [false, __('ap_safecache.license_action_token_err_not_configured')];
    }

    if (!fn_ap_safecache_is_pro()) {
        return [false, __('ap_safecache.license_pro_only')];
    }

    if (fn_ap_safecache_license_action_token_session_valid()) {
        $b = fn_ap_safecache_license_action_token_get_bucket();
        $exp = isset($b['exp']) ? (int) $b['exp'] : 0;

        return [
            true,
            __('ap_safecache.license_action_token_ok_already_valid', ['[time]' => date('Y-m-d H:i:s', $exp)]),
        ];
    }

    $url = trim((string) AP_SAFECACHE_LICENSE_ACTION_TOKEN_URL);
    $license_key = function_exists('fn_ap_safecache_freemius_get_license_key_trimmed')
        ? fn_ap_safecache_freemius_get_license_key_trimmed()
        : '';
    if ($license_key === '') {
        $addon = Registry::get('addons.ap_safecache');
        $addon = is_array($addon) ? $addon : [];
        $license_key = isset($addon['freemius_license_key']) ? trim((string) $addon['freemius_license_key']) : '';
    }

    $site_url = function_exists('fn_get_storefront_url') ? fn_get_storefront_url('http', 0) : '';
    if ($site_url === '') {
        $site_url = Registry::get('config.http_location');
    }
    $site_url = is_string($site_url) ? rtrim($site_url, '/') : '';
    if ($site_url === '') {
        $site_url = 'https://example.invalid';
    }

    $body = [
        'product_id' => fn_ap_safecache_freemius_get_product_id(),
        'install_uid' => fn_ap_safecache_freemius_ensure_uid(),
        'site_url' => $site_url,
        'addon_version' => fn_ap_safecache_get_addon_version(),
        'license_key' => $license_key,
        'scope' => AP_SAFECACHE_LICENSE_ACTION_TOKEN_SCOPE,
    ];

    $extra = [
        'timeout' => 45,
        'headers' => [
            'Content-Type: application/json',
        ],
    ];
    $api_key = defined('AP_SAFECACHE_LICENSE_ACTION_TOKEN_API_KEY')
        ? trim((string) AP_SAFECACHE_LICENSE_ACTION_TOKEN_API_KEY)
        : '';
    if ($api_key !== '') {
        $extra['headers'][] = 'Authorization: Bearer ' . $api_key;
    }

    $payload = json_encode($body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $response = Http::post($url, $payload !== false ? $payload : '{}', $extra);
    $status = (int) Http::getStatus();

    if ($response === false) {
        return [false, __('ap_safecache.license_action_token_err_http')];
    }

    $data = json_decode($response, true);
    if (!is_array($data)) {
        return [false, __('ap_safecache.license_action_token_err_bad_response')];
    }

    $http_ok = $status >= 200 && $status < 300;
    if (!$http_ok) {
        $gwErr = !empty($data['error']) ? strtolower(trim((string) $data['error'])) : '';
        $gwDetail = !empty($data['detail']) ? trim((string) $data['detail']) : '';

        if ($gwErr === 'license_utilized') {
            $portal = function_exists('fn_ap_safecache_freemius_get_customer_portal_url')
                ? fn_ap_safecache_freemius_get_customer_portal_url()
                : '';

            return [
                false,
                __('ap_safecache.freemius_err_license_utilized', [
                    '[portal_url]' => $portal !== '' ? $portal : 'https://customers.freemius.com/',
                    '[detail]'      => $gwDetail !== '' ? $gwDetail : $gwErr,
                ]),
            ];
        }

        $suffix = '';
        if ($gwErr !== '') {
            $suffix .= ' （ゲートウェイ: ' . trim((string) $data['error']) . '）';
        }
        if ($gwDetail !== '') {
            $suffix .= ' ' . $gwDetail;
        }

        return [
            false,
            __('ap_safecache.license_action_token_err_http_status', ['[code]' => (string) $status]) . $suffix,
        ];
    }

    $token = '';
    if (!empty($data['token'])) {
        $token = trim((string) $data['token']);
    } elseif (!empty($data['access_token'])) {
        $token = trim((string) $data['access_token']);
    }

    if ($token === '') {
        return [false, __('ap_safecache.license_action_token_err_no_token')];
    }

    $exp = 0;
    if (isset($data['expires_at'])) {
        $exp = (int) $data['expires_at'];
    }
    if ($exp <= time() && isset($data['expires_in'])) {
        $exp = time() + max(60, (int) $data['expires_in']);
    }
    if ($exp <= time()) {
        $ttl = defined('AP_SAFECACHE_LICENSE_ACTION_TOKEN_DEFAULT_TTL')
            ? (int) AP_SAFECACHE_LICENSE_ACTION_TOKEN_DEFAULT_TTL
            : 900;
        if ($ttl < 60) {
            $ttl = 900;
        }
        $exp = time() + $ttl;
    }

    fn_ap_safecache_license_action_token_save_to_session($token, $exp);

    return [
        true,
        __('ap_safecache.license_action_token_ok', ['[time]' => date('Y-m-d H:i:s', $exp)]),
    ];
}

/**
 * @return string
 */
function fn_ap_safecache_update_check_url()
{
    $url = defined('AP_SAFECACHE_UPDATE_CHECK_URL')
        ? trim((string) AP_SAFECACHE_UPDATE_CHECK_URL)
        : '';
    if ($url !== '') {
        return $url;
    }

    if (!fn_ap_safecache_license_action_token_gateway_configured()) {
        return '';
    }

    $token_url = trim((string) AP_SAFECACHE_LICENSE_ACTION_TOKEN_URL);
    if ($token_url === '') {
        return '';
    }

    $normalized = preg_replace('~/(token|downloads)/?$~', '/update-compat', $token_url);
    if (!is_string($normalized) || trim($normalized) === '') {
        return '';
    }

    return trim($normalized);
}

/**
 * @param string $version
 *
 * @return string
 */
function fn_ap_safecache_normalize_core_version_string($version)
{
    $v = strtolower(trim((string) $version));
    $v = ltrim($v, 'v');
    $v = str_replace('_', '-', $v);

    return preg_replace('/\s+/', '', $v);
}

/**
 * @return string
 */
function fn_ap_safecache_detect_core_distribution()
{
    if (defined('PRODUCT_VERSION')) {
        $pv = fn_ap_safecache_normalize_core_version_string((string) PRODUCT_VERSION);
        if (strpos($pv, 'jp-') !== false || strpos($pv, '-jp') !== false) {
            return 'jp';
        }
    }

    if (defined('PRODUCT_BUILD')) {
        $build = strtolower(trim((string) PRODUCT_BUILD));
        if ($build !== '' && (strpos($build, 'jp') !== false || strpos($build, 'ja') !== false)) {
            return 'jp';
        }
    }

    return 'upstream';
}

/**
 * 本体アップデート互換判定 API 呼び出し。
 *
 * @param string $target_core_version 次期本体バージョン
 *
 * @return array{0: bool, 1: array<string, mixed>|string} [ok, data|error]
 */
function fn_ap_safecache_fetch_update_compatibility($target_core_version)
{
    $target_core_version = fn_ap_safecache_normalize_core_version_string($target_core_version);
    if ($target_core_version === '') {
        return [false, 'target_core_version_required'];
    }

    $url = fn_ap_safecache_update_check_url();
    if ($url === '') {
        return [false, 'update_check_url_not_configured'];
    }

    $site_url = function_exists('fn_get_storefront_url') ? fn_get_storefront_url('http', 0) : '';
    if ($site_url === '') {
        $site_url = Registry::get('config.http_location');
    }
    $site_url = is_string($site_url) ? rtrim($site_url, '/') : '';
    if ($site_url === '') {
        $site_url = 'https://example.invalid';
    }

    $license_key = function_exists('fn_ap_safecache_freemius_get_license_key_trimmed')
        ? fn_ap_safecache_freemius_get_license_key_trimmed()
        : '';

    $body = [
        'product_id' => fn_ap_safecache_freemius_get_product_id(),
        'install_uid' => fn_ap_safecache_freemius_ensure_uid(),
        'site_url' => $site_url,
        'addon_version' => fn_ap_safecache_get_addon_version(),
        'license_key' => $license_key,
        'distribution' => fn_ap_safecache_detect_core_distribution(),
        'current_core_version' => defined('PRODUCT_VERSION') ? fn_ap_safecache_normalize_core_version_string((string) PRODUCT_VERSION) : '',
        'target_core_version' => $target_core_version,
    ];

    $extra = [
        'timeout' => 20,
        'headers' => [
            'Content-Type: application/json',
        ],
    ];
    $api_key = defined('AP_SAFECACHE_LICENSE_ACTION_TOKEN_API_KEY')
        ? trim((string) AP_SAFECACHE_LICENSE_ACTION_TOKEN_API_KEY)
        : '';
    if ($api_key !== '') {
        $extra['headers'][] = 'Authorization: Bearer ' . $api_key;
    }

    $payload = json_encode($body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $response = Http::post($url, $payload !== false ? $payload : '{}', $extra);
    $status = (int) Http::getStatus();

    if ($response === false) {
        return [false, 'http_request_failed'];
    }

    $data = json_decode($response, true);
    if (!is_array($data)) {
        return [false, 'invalid_response'];
    }

    if ($status < 200 || $status >= 300) {
        return [false, 'http_status_' . $status];
    }

    $compat = isset($data['compatibility_status']) ? trim((string) $data['compatibility_status']) : 'unknown';
    if ($compat !== 'unknown' && $compat !== 'update_required' && $compat !== 'supported') {
        $compat = 'unknown';
    }
    $data['compatibility_status'] = $compat;

    return [true, $data];
}
