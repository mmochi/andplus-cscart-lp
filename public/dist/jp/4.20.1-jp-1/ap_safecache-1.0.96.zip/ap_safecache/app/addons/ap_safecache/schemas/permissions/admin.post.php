<?php

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}

$schema['ap_safecache'] = [
    'permissions' => ['GET' => 'view_settings', 'POST' => 'update_settings'],
];

return $schema;
