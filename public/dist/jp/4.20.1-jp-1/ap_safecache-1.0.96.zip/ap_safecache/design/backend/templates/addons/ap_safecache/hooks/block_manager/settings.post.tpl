{if $id > 0}
    <div class="control-group">
        <label class="control-label">{__("ap_safecache.block_layout_section")}</label>
        <div class="controls">
            <a href="{"ap_safecache.manage?add_ajax_block_id=`$id`"|fn_url}" class="btn">{__("ap_safecache.btn_add_block_from_layout")}</a>
            <p class="muted">{__("ap_safecache.block_layout_hint")}</p>
        </div>
    </div>
{/if}
