<?php

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}

use Tygh\Enum\SiteArea;
use Tygh\Registry;

/**
 * Cloudflare Cache Rules 向けの CS-Cart 推奨ルール。
 * URL / パスは fn_url・config から取得（ドメイン等をハードコードしない）。
 *
 * 評価順: ルールは配列の先頭から適用され、最初に一致したものが使われます。
 * このテンプレートは次の意図で並べています。
 *   1) GET で「店頭向けキャッシュ可能」と判断できるものだけ set_cache_settings
 *   2) 管理 / ベンダー / API / dispatch 系は bypass
 *   3) GET 以外は bypass
 *
 * 式の形: ルール2は path / query をフラットな or で1組の括弧にまとめる。
 * dispatch 動的 URL は http.request.uri.query の contains を or 列挙（matches は上位プラン限定のため使わない）。
 * SEO アドオンが有効なときは ?:seo_names（SEO ルール・object_id=0・type=s）の name をパス断片として or 列挙し、
 * きれいな URL 時に query に dispatch= が無いケースもバイパス対象に含める。
 */

/**
 * 推奨ルールでバイパス対象とする dispatch=… の左辺（ needles 一覧の単一ソース）。
 *
 * @return list<string>
 */
function fn_ap_safecache_cf_rec_get_dispatch_bypass_needles()
{
    return [
        'dispatch=checkout.checkout',
        'dispatch=checkout.cart',
        'dispatch=checkout.complete',
        'dispatch=checkout.checkout_login',
        'dispatch=auth.login',
        'dispatch=auth.logout',
        'dispatch=auth.recover_password',
        'dispatch=profiles.update',
        'dispatch=profiles.success_add',
        'dispatch=orders.search',
        'dispatch=orders.details',
        'dispatch=wishlist.view',
        'dispatch=product_features.compare',
        'dispatch=discussion.add',
        'dispatch=call_requests.request',
        'dispatch=embed',
    ];
}

/**
 * SEO アドオンが有効か（推奨ルール生成用）。
 *
 * @return bool
 */
function fn_ap_safecache_cf_rec_is_seo_addon_active()
{
    $row = Registry::get('addons.seo');

    return is_array($row) && isset($row['status']) && $row['status'] === 'A';
}

/**
 * needles から dispatch 名（例: checkout.cart）の一覧を得る。
 *
 * @return list<string>
 */
function fn_ap_safecache_cf_rec_get_bypass_dispatch_strings_from_needles()
{
    $out = [];
    foreach (fn_ap_safecache_cf_rec_get_dispatch_bypass_needles() as $needle) {
        if (preg_match('/^dispatch=(.+)$/i', (string) $needle, $m)) {
            $out[] = $m[1];
        }
    }

    return array_values(array_unique($out));
}

/**
 * 表示用に SEO アドオン設定の主要キーをスナップショット（addons.seo のサブセット）。
 *
 * @return array<string, string>
 */
function fn_ap_safecache_cf_rec_get_seo_addon_settings_snapshot_for_rec()
{
    $keys = [
        'non_latin_symbols',
        'single_url',
        'seo_language',
        'seo_other_type',
        'seo_page_type',
        'seo_category_type',
        'seo_product_type',
    ];
    $seo = Registry::get('addons.seo');
    if (!is_array($seo)) {
        return [];
    }
    $out = [];
    foreach ($keys as $k) {
        $out[$k] = isset($seo[$k]) ? (string) $seo[$k] : '';
    }

    return $out;
}

/**
 * needles に対応する dispatch について、SEO ルール（?:seo_names）の name から path contains 素片を生成する。
 * SEO 無効時や seo 関数未ロード時は空配列。
 *
 * @return list<string>
 */
function fn_ap_safecache_cf_rec_get_seo_path_atoms_for_bypass_dispatches()
{
    if (!fn_ap_safecache_cf_rec_is_seo_addon_active() || !function_exists('fn_get_seo_company_condition')) {
        return [];
    }

    $dispatches = fn_ap_safecache_cf_rec_get_bypass_dispatch_strings_from_needles();
    if ($dispatches === []) {
        return [];
    }

    $condition = fn_get_seo_company_condition('?:seo_names.company_id');

    $rows = db_get_array(
        'SELECT DISTINCT name, dispatch FROM ?:seo_names WHERE object_id = ?i AND type = ?s AND dispatch IN (?a) ?p ORDER BY name',
        0,
        's',
        $dispatches,
        $condition
    );

    if (!is_array($rows) || $rows === []) {
        return [];
    }

    $atoms = [];
    $seen = [];

    foreach ($rows as $row) {
        $name = isset($row['name']) ? trim((string) $row['name']) : '';
        if ($name === '') {
            continue;
        }

        $norm = trim(str_replace('\\', '/', $name), '/');
        if ($norm === '') {
            continue;
        }

        $fragment = '/' . $norm;
        if (isset($seen[$fragment])) {
            continue;
        }
        $seen[$fragment] = true;

        $atoms[] = fn_ap_safecache_cf_rec_expr_path_atom($fragment);
    }

    return $atoms;
}

/**
 * Cloudflare Rules 式の文字列リテラル用エスケープ（path / query 用）。
 */
function fn_ap_safecache_cf_rec_escape_string_literal($s)
{
    $s = (string) $s;

    return str_replace(['\\', '"'], ['\\\\', '\\"'], $s);
}

/**
 * path 条件の素片（括弧なし）。ルール全体で1組の括弧にまとめるため。
 *
 * @return string 例: http.request.uri.path contains "/admin.php"
 */
function fn_ap_safecache_cf_rec_expr_path_atom($path_fragment)
{
    $path_fragment = (string) $path_fragment;
    if ($path_fragment === '') {
        return 'false';
    }

    $e = fn_ap_safecache_cf_rec_escape_string_literal($path_fragment);

    return 'http.request.uri.path contains "' . $e . '"';
}

/**
 * ?:seo_names から取れないが、バイパスに含める path contains 素片（きれいな URL 用）。
 * 例: マイアカウント一覧 `/profiles`（dispatch=profiles.update とは別パス）。
 *
 * @return list<string>
 */
function fn_ap_safecache_cf_rec_get_fixed_bypass_path_atoms()
{
    return [
        fn_ap_safecache_cf_rec_expr_path_atom('/profiles'),
    ];
}

/**
 * dispatch/SEO 合成の or 列から、vendor 入口パスを含む素片を除く（ルール1・2 側の not path contains vendor と重複しないよう整理）。
 *
 * @param list<string> $atoms
 * @param string       $vendor_uri_path vendor パス断片（例: /ap_vendor.php）
 *
 * @return list<string>
 */
function fn_ap_safecache_cf_rec_drop_atoms_matching_vendor_uri_path(array $atoms, $vendor_uri_path)
{
    $vendor_uri_path = trim((string) $vendor_uri_path);
    if ($vendor_uri_path === '') {
        return $atoms;
    }

    $out = [];
    foreach ($atoms as $a) {
        if (!is_string($a) || $a === '') {
            continue;
        }
        if (stripos($a, $vendor_uri_path) !== false) {
            continue;
        }
        $out[] = $a;
    }

    return array_values($out);
}

/**
 * query 条件の素片（括弧なし）。
 *
 * @return string
 */
function fn_ap_safecache_cf_rec_expr_query_atom($needle)
{
    $needle = (string) $needle;
    if ($needle === '') {
        return 'false';
    }

    $e = fn_ap_safecache_cf_rec_escape_string_literal($needle);

    return 'http.request.uri.query contains "' . $e . '"';
}

/**
 * @return string 例: (http.request.uri.path contains "/admin.php")
 */
function fn_ap_safecache_cf_rec_expr_path_contains($path_fragment)
{
    return '(' . fn_ap_safecache_cf_rec_expr_path_atom($path_fragment) . ')';
}

/**
 * @return string
 */
function fn_ap_safecache_cf_rec_expr_query_contains($needle)
{
    return '(' . fn_ap_safecache_cf_rec_expr_query_atom($needle) . ')';
}

/**
 * fn_url からパス部分を取得（失敗時は空）。
 *
 * @param string $url_urn
 * @param string $area SiteArea::*
 */
function fn_ap_safecache_cf_rec_path_from_fn_url($url_urn, $area, $protocol = 'https')
{
    $full = fn_url($url_urn, $area, $protocol);
    $path = parse_url($full, PHP_URL_PATH);

    return is_string($path) ? $path : '';
}

/**
 * index.php と同階層の api.php のパスを推定。
 */
function fn_ap_safecache_cf_rec_guess_api_path()
{
    $conf = Registry::get('config');
    $conf = is_array($conf) ? $conf : [];
    $customer_index = isset($conf['customer_index']) ? (string) $conf['customer_index'] : 'index.php';

    $idx_path = fn_ap_safecache_cf_rec_path_from_fn_url('index.index', SiteArea::STOREFRONT, 'https');
    if ($idx_path !== '' && strpos($idx_path, $customer_index) !== false) {
        return str_replace($customer_index, 'api.php', $idx_path);
    }

    $http_path = isset($conf['http_path']) ? rtrim((string) $conf['http_path'], '/') : '';

    return ($http_path !== '' ? $http_path : '') . '/api.php';
}

/**
 * dispatch= の代表的な動的 URL 用の query 条件（素片の配列）。
 * contains のみ（全プランで利用可能）。matches はエンタイトルメントが要るゾーンがあるため使わない。
 *
 * @return list<string>
 */
function fn_ap_safecache_cf_rec_get_dispatch_query_atoms()
{
    $atoms = [];
    foreach (fn_ap_safecache_cf_rec_get_dispatch_bypass_needles() as $n) {
        $atoms[] = fn_ap_safecache_cf_rec_expr_query_atom($n);
    }

    return $atoms;
}

/**
 * 管理画面表示用に Rules 式を改行・インデントする（API 送信値は変更しない）。
 * and / and not / or の前で改行し、単純な 1 組括弧の式は括弧を縦に広げる。
 *
 * @param string $s
 *
 * @return string
 */
function fn_ap_safecache_cf_rec_format_expression_for_display($s)
{
    $s = trim((string) $s);
    if ($s === '') {
        return '';
    }

    $ind = '  ';

    // 長いトークンから順に（and not を and より先に）
    $s = preg_replace('/\s+and\s+not\s+/iu', "\n{$ind}and not ", $s);
    $s = preg_replace('/\s+and\s+(?!not\b)/iu', "\n{$ind}and ", $s);
    $s = preg_replace('/\s+or\s+/iu', "\n{$ind}or ", $s);

    // 入れ子のない ( 単一式 ) は括弧を改行して見やすくする
    if (preg_match('/^\(([^()]+)\)$/s', $s, $m)) {
        $inner = trim($m[1]);

        return "(\n{$ind}" . $inner . "\n)";
    }

    return $s;
}

/**
 * 推奨 Cache Rules（3 件・順序固定）のペイロードと表示用メタ。
 *
 * @return array{
 *   rules: list<array<string, mixed>>,
 *   rows: list<array{order: int, title: string, expression: string, hint: string, action: string, source_label: string, source_value: string}>,
 *   json_rules: string
 * }
 */
function fn_ap_safecache_cf_get_recommended_cache_rules_payload()
{
    $conf = Registry::get('config');
    $conf = is_array($conf) ? $conf : [];

    $admin_index = isset($conf['admin_index']) ? (string) $conf['admin_index'] : 'admin.php';
    $admin_path = fn_ap_safecache_cf_rec_path_from_fn_url('index.index', SiteArea::ADMIN_PANEL, 'https');
    if ($admin_path === '') {
        $admin_path = '/' . ltrim($admin_index, '/');
    }
    $admin_url = fn_url('index.index', SiteArea::ADMIN_PANEL, 'https');

    // vendor 行は Pro Multi Vendor（Freemius promv）または Freemius 未使用／Free 時のみ。Pro Single Store では出さない。
    $include_vendor_paths = !function_exists('fn_ap_safecache_freemius_should_include_vendor_paths_in_cf_recommendations')
        || fn_ap_safecache_freemius_should_include_vendor_paths_in_cf_recommendations();

    $vendor_path = '';
    $vendor_url = '';
    $vendor_index = isset($conf['vendor_index']) ? trim((string) $conf['vendor_index']) : '';
    if ($include_vendor_paths && $vendor_index !== '') {
        $vendor_path = fn_ap_safecache_cf_rec_path_from_fn_url('index.index', SiteArea::VENDOR_PANEL, 'https');
        if ($vendor_path === '') {
            $vendor_path = '/' . ltrim($vendor_index, '/');
        }
        $vendor_url = fn_url('index.index', SiteArea::VENDOR_PANEL, 'https');
    }

    $api_path = fn_ap_safecache_cf_rec_guess_api_path();
    $store_root = fn_url('', SiteArea::STOREFRONT, 'https');
    $api_url = $store_root;
    if (is_string($api_path) && $api_path !== '') {
        $pu = parse_url($store_root);
        if (is_array($pu) && !empty($pu['scheme']) && !empty($pu['host'])) {
            $port = isset($pu['port']) ? ':' . (int) $pu['port'] : '';
            $api_url = $pu['scheme'] . '://' . $pu['host'] . $port . $api_path;
        }
    }

    $dispatch_atoms = fn_ap_safecache_cf_rec_get_dispatch_query_atoms();
    $seo_path_atoms = fn_ap_safecache_cf_rec_get_seo_path_atoms_for_bypass_dispatches();
    $fixed_path_atoms = fn_ap_safecache_cf_rec_get_fixed_bypass_path_atoms();
    $bypass_dispatch_or_seo = array_values(array_unique(array_merge($dispatch_atoms, $seo_path_atoms, $fixed_path_atoms)));
    if ($include_vendor_paths && $vendor_path !== '') {
        $bypass_dispatch_or_seo = fn_ap_safecache_cf_rec_drop_atoms_matching_vendor_uri_path(
            $bypass_dispatch_or_seo,
            $vendor_path
        );
    }

    $seo_settings_snap = fn_ap_safecache_cf_rec_is_seo_addon_active()
        ? fn_ap_safecache_cf_rec_get_seo_addon_settings_snapshot_for_rec()
        : [];
    $seo_settings_line = '';
    if ($seo_settings_snap !== []) {
        $pairs = [];
        foreach ($seo_settings_snap as $k => $v) {
            $pairs[] = $k . '=' . $v;
        }
        $seo_settings_line = implode(', ', $pairs);
    }

    $atom_admin = fn_ap_safecache_cf_rec_expr_path_atom($admin_path);
    $atom_api = fn_ap_safecache_cf_rec_expr_path_atom($api_path);
    $atom_vendor = ($vendor_path !== '') ? fn_ap_safecache_cf_rec_expr_path_atom($vendor_path) : '';

    // 外側の1組の括弧だけにする（(GET) を二重にしない）。dispatch query と SEO パスは contains の or 列（matches はプラン制限あり）。
    $parts_rule1 = [
        'http.request.method eq "GET"',
        'not ' . $atom_admin,
    ];
    if ($atom_vendor !== '') {
        $parts_rule1[] = 'not ' . $atom_vendor;
    }
    $parts_rule1[] = 'not ' . $atom_api;
    $parts_rule1[] = 'not (' . implode(' or ', $bypass_dispatch_or_seo) . ')';

    $expr_rule1 = '(' . implode(' and ', $parts_rule1) . ')';

    $parts_rule2 = [$atom_admin];
    if ($atom_vendor !== '') {
        $parts_rule2[] = $atom_vendor;
    }
    $parts_rule2[] = $atom_api;
    foreach ($bypass_dispatch_or_seo as $b) {
        $parts_rule2[] = $b;
    }
    $expr_rule2 = '(' . implode(' or ', $parts_rule2) . ')';

    $expr_rule3 = '(http.request.method ne "GET")';

    $action_params_cache = [
        'cache'                => true,
        'respect_strong_etags' => true,
        'edge_ttl'             => [
            'mode'    => 'override_origin',
            'default' => 7200,
        ],
        'browser_ttl'          => [
            'mode'    => 'override_origin',
            'default' => 3600,
        ],
    ];

    $rules = [
        [
            'action'             => 'set_cache_settings',
            'expression'         => $expr_rule1,
            'description'        => 'CS-Cart: cache eligible GET (ap_safecache 1/3)',
            'action_parameters'  => $action_params_cache,
        ],
        [
            'action'             => 'set_cache_settings',
            'expression'         => $expr_rule2,
            'description'        => 'CS-Cart: bypass admin/vendor/API/dispatch (ap_safecache 2/3)',
            'action_parameters'  => [
                'cache' => false,
            ],
        ],
        [
            'action'             => 'set_cache_settings',
            'expression'         => $expr_rule3,
            'description'        => 'CS-Cart: bypass non-GET (ap_safecache 3/3)',
            'action_parameters'  => [
                'cache' => false,
            ],
        ],
    ];

    $src2 = $admin_url;
    if ($vendor_url !== '') {
        $src2 .= ' · ' . $vendor_url;
    }
    $src2 .= ' · ' . $api_url;
    $src2 .= ' · ' . fn_url('index.index', SiteArea::STOREFRONT, 'https');
    if ($seo_settings_line !== '') {
        $src2 .= "\n" . __('ap_safecache.cf_rec_source_rule2_seo_addon_line', ['[settings]' => $seo_settings_line]);
    }

    $use_seo_paths = $seo_path_atoms !== [];
    $title_rule1 = $use_seo_paths
        ? __('ap_safecache.cf_rec_title_rule1_seo')
        : __('ap_safecache.cf_rec_title_rule1');
    $title_rule2 = $use_seo_paths
        ? __('ap_safecache.cf_rec_title_rule2_seo')
        : __('ap_safecache.cf_rec_title_rule2');
    $hint_rule1 = $use_seo_paths
        ? __('ap_safecache.cf_rec_hint_rule1_seo')
        : __('ap_safecache.cf_rec_hint_rule1');
    $hint_rule2 = $use_seo_paths
        ? __('ap_safecache.cf_rec_hint_rule2_seo')
        : __('ap_safecache.cf_rec_hint_rule2');

    $source_rule1_detail = __('ap_safecache.cf_rec_source_rule1_detail');
    if ($seo_settings_line !== '') {
        $source_rule1_detail .= "\n\n" . __('ap_safecache.cf_rec_source_rule1_detail_seo_addon', ['[settings]' => $seo_settings_line]);
    }
    if ($use_seo_paths) {
        $source_rule1_detail .= "\n\n" . __('ap_safecache.cf_rec_source_rule1_detail_seo_paths');
    }

    $rows = [
        [
            'order'        => 1,
            'title'        => $title_rule1,
            'expression'   => fn_ap_safecache_cf_rec_format_expression_for_display($expr_rule1),
            'hint'         => $hint_rule1,
            'action'       => 'set_cache_settings',
            'source_label' => __('ap_safecache.cf_rec_source_rule1'),
            'source_value' => $source_rule1_detail,
        ],
        [
            'order'        => 2,
            'title'        => $title_rule2,
            'expression'   => fn_ap_safecache_cf_rec_format_expression_for_display($expr_rule2),
            'hint'         => $hint_rule2,
            'action'       => 'set_cache_settings (cache: false)',
            'source_label' => __('ap_safecache.cf_rec_source_rule2'),
            'source_value' => $src2,
        ],
        [
            'order'        => 3,
            'title'        => __('ap_safecache.cf_rec_title_rule3'),
            'expression'   => fn_ap_safecache_cf_rec_format_expression_for_display($expr_rule3),
            'hint'         => __('ap_safecache.cf_rec_hint_rule3'),
            'action'       => 'set_cache_settings (cache: false)',
            'source_label' => __('ap_safecache.cf_rec_source_rule3'),
            'source_value' => '—',
        ],
    ];

    $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
    if (defined('JSON_PRETTY_PRINT')) {
        $flags |= JSON_PRETTY_PRINT;
    }
    $json_rules = (string) json_encode($rules, $flags);

    return [
        'rules'      => $rules,
        'rows'       => $rows,
        'json_rules' => $json_rules,
    ];
}

/**
 * 取得済みルールの先頭が Cloudflare プリセット「Cache Everything」相当か（ルール名は API の description）。
 * これが先頭にないと後続の CS-Cart 細則と組み合わせたときに意図した評価順にならないケースがあるため、
 * 推奨ルールの挿入位置決定に使う。
 *
 * @param array<string, mixed> $rule
 *
 * @return bool
 */
function fn_ap_safecache_cf_rec_rule_looks_like_cache_everything($rule)
{
    if (!is_array($rule)) {
        return false;
    }

    $desc = isset($rule['description']) ? trim((string) $rule['description']) : '';
    if ($desc === '') {
        return false;
    }

    if (stripos($desc, 'cache everything') !== false) {
        return true;
    }

    if (strpos($desc, 'キャッシュ') !== false && strpos($desc, 'すべて') !== false) {
        return true;
    }

    return false;
}

/**
 * セッション内の Cache Rules に推奨 3 ルールを挿入（同一 expression の既存ルールは除去して重複回避）。
 * 先頭のルールが「Cache Everything」相当なら、その直後に挿入し、先頭は維持する。それ以外は従来どおり一覧先頭に挿入。
 * 除去する既存ルールの Cloudflare id は、付け直す推奨ルールへ引き継ぐ（差分表示が「削除+__new_」に見えないようにする）。
 * 取得済みの ruleset が必要。
 *
 * @return bool
 */
function fn_ap_safecache_cf_append_recommended_cache_rules_to_session()
{
    if (!fn_ap_safecache_is_pro()) {
        fn_set_notification('E', __('ap_safecache.notification_title_license'), __('ap_safecache.license_pro_only'));

        return false;
    }

    if (fn_ap_safecache_license_action_token_abort_pro_write()) {
        return false;
    }

    $payload = fn_ap_safecache_cf_get_recommended_cache_rules_payload();
    $bucket = fn_ap_safecache_cf_session_get_bucket();

    if (empty($bucket['fetched_at'])) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_fetch_first'));

        return false;
    }

    if (empty($bucket['cache_ruleset']) || !is_array($bucket['cache_ruleset'])) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_fetch_first'));

        return false;
    }

    $existing = isset($bucket['cache_ruleset']['rules']) && is_array($bucket['cache_ruleset']['rules'])
        ? $bucket['cache_ruleset']['rules']
        : [];

    $incoming_exprs = [];
    foreach ($payload['rules'] as $nr) {
        if (is_array($nr) && isset($nr['expression'])) {
            $incoming_exprs[(string) $nr['expression']] = true;
        }
    }

    // 同一 expression の既存ルール（差し替え対象）を式ごとにキュー化し、後で id を先頭ルールへ渡す
    $stale_by_expr = [];
    foreach ($existing as $r) {
        if (!is_array($r) || !isset($r['expression'])) {
            continue;
        }
        $ex = (string) $r['expression'];
        if (!empty($incoming_exprs[$ex])) {
            if (!isset($stale_by_expr[$ex])) {
                $stale_by_expr[$ex] = [];
            }
            $stale_by_expr[$ex][] = $r;
        }
    }

    $filtered = [];
    foreach ($existing as $r) {
        if (!is_array($r) || !isset($r['expression'])) {
            $filtered[] = $r;

            continue;
        }
        if (!empty($incoming_exprs[(string) $r['expression']])) {
            continue;
        }
        $filtered[] = $r;
    }

    $prepended = [];
    foreach ($payload['rules'] as $nr) {
        if (!is_array($nr)) {
            $prepended[] = $nr;

            continue;
        }
        $copy = $nr;
        if (isset($nr['expression'])) {
            $ex = (string) $nr['expression'];
            if (!empty($stale_by_expr[$ex])) {
                $old = array_shift($stale_by_expr[$ex]);
                if (is_array($old) && isset($old['id'])) {
                    $copy['id'] = $old['id'];
                }
            }
        }
        $prepended[] = $copy;
    }

    $insert_offset = 0;
    if (!empty($filtered[0]) && is_array($filtered[0]) && fn_ap_safecache_cf_rec_rule_looks_like_cache_everything($filtered[0])) {
        $insert_offset = 1;
    }

    $merged = array_merge(
        array_slice($filtered, 0, $insert_offset),
        $prepended,
        array_slice($filtered, $insert_offset)
    );
    $bucket['cache_ruleset']['rules'] = $merged;
    fn_ap_safecache_cf_session_set_bucket($bucket);

    $n = (string) count($payload['rules']);
    if ($insert_offset === 1) {
        fn_set_notification(
            'N',
            __('ap_safecache.cf_notification_title'),
            __('ap_safecache.cf_ok_rec_inserted_after_cache_everything', ['[n]' => $n])
        );
    } else {
        fn_set_notification(
            'N',
            __('ap_safecache.cf_notification_title'),
            __('ap_safecache.cf_ok_rec_prepended', ['[n]' => $n])
        );
    }

    return true;
}
