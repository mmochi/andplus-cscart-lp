<?php

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}

// メニュー表示はキーが言語変数名になる（__("ap_safecache.menu")）。Addons::description は未使用。
$schema['top']['administration']['items']['ap_safecache.menu'] = [
    'attrs' => [
        'class' => 'is-addon',
    ],
    'href'  => 'ap_safecache.manage',
    'position' => 10507,
    'icon'  => 'cloud',
];

return $schema;
