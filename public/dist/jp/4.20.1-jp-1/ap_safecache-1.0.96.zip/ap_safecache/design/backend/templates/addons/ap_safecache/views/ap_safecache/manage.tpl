{capture name="adv_buttons"}
    {include file="common/tools.tpl"
        tool_href="addons.update?addon=ap_safecache"
        tool_override_meta="btn btn-primary nav__actions-btn-primary"
        prefix="ap_safecache_settings"
        hide_tools=true
        title=__("ap_safecache.open_addon_settings")
        link_text=__("ap_safecache.open_addon_settings")
        icon="icon-cog"
    }
{/capture}

{capture name="mainbox"}

{* ページソース検索用: このコメントが無ければ別テンプレが読まれている *}
<!-- ap_safecache-manage-template -->

<style>
.ap-safecache-manage-fold > summary { cursor: pointer; font-weight: 600; list-style: none; padding: 10px 14px; font-size: 13px; display:flex; align-items:center; justify-content:space-between; gap:8px; }
.ap-safecache-manage-fold > summary::-webkit-details-marker { display: none; }
.ap-safecache-manage-fold > summary::after { content:''; flex:0 0 auto; width:8px; height:8px; border-right:2px solid #666; border-bottom:2px solid #666; transform:rotate(45deg); transition:transform .15s ease, margin-top .15s ease; margin-left:8px; }
.ap-safecache-manage-fold[open] > summary::after { transform:rotate(-135deg); margin-top:4px; }
.ap-safecache-manage-tabs.nav-tabs { margin-bottom: 0; border-bottom: 1px solid #ddd; }
.ap-safecache-manage-tabs.nav-tabs > li > a { padding: 10px 14px; }
</style>

<div class="alert alert-info">
    <p>{__("ap_safecache.manage_intro")}</p>
    <p class="muted" style="margin-top:8px;margin-bottom:0;font-size:12px;line-height:1.5;">{__("ap_safecache.manage_layout_hint")}</p>
</div>

<div id="ap-safecache-license-funnel" class="well" style="margin-top:12px;border-left:4px solid #5bc0de;padding:12px 14px;background:#f9fcfd;scroll-margin-top:72px;">
    <p style="margin:0 0 8px 0;"><strong>{__("ap_safecache.freemius_funnel_title")}</strong></p>
    <p class="muted" style="font-size:12px;line-height:1.55;margin-bottom:10px;">{__("ap_safecache.freemius_funnel_intro")}</p>
    <p style="margin:0 0 10px 0;">
        <span class="label label-default">{__("ap_safecache.edition_badge_current")}</span>
        <strong>{$ap_safecache_license_edition_label|default:""|escape}</strong>
    </p>
    {if $ap_safecache_freemius_enabled|default:false}
        <p class="muted" style="font-size:12px;margin-bottom:10px;">
            {__("ap_safecache.freemius_status_plan", ["[plan]" => $ap_safecache_freemius_last_plan_label|default:""|escape])}
            {if $ap_safecache_freemius_last_sync_at|default:0}
                <span class="muted"> · {__("ap_safecache.freemius_last_sync", ["[time]" => $ap_safecache_freemius_last_sync_at|date_format:"%Y-%m-%d %H:%M"])}</span>
            {/if}
        </p>
    {/if}
    {if $ap_safecache_freemius_show_mv_plan_mismatch_notice|default:false}
        <div class="alert alert-danger" style="margin:0 0 10px 0;padding:10px 12px;">
            <p style="margin:0;"><strong>{__("ap_safecache.freemius_mv_plan_mismatch_title")}</strong></p>
            <p class="muted" style="margin:8px 0 0 0;font-size:12px;line-height:1.55;margin-bottom:0;">{__("ap_safecache.freemius_mv_plan_mismatch_body", ["[plan]" => $ap_safecache_freemius_last_plan_label|default:""|escape])}</p>
        </div>
    {/if}
    <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;">
        {if $ap_safecache_freemius_show_free_purchase_links|default:false}
            {if ($ap_safecache_freemius_show_checkout_pro_single_store|default:true) && $ap_safecache_freemius_checkout_url_pro_ss|default:""}
                <a href="{$ap_safecache_freemius_checkout_url_pro_ss|escape:'html'}" class="btn btn-success" target="_blank" rel="noopener noreferrer">{__("ap_safecache.freemius_btn_checkout_pro_single_store")}</a>
            {/if}
            {if ($ap_safecache_freemius_show_checkout_pro_multi_vendor|default:true) && $ap_safecache_freemius_checkout_url_pro_mv|default:""}
                <a href="{$ap_safecache_freemius_checkout_url_pro_mv|escape:'html'}" class="btn btn-success" target="_blank" rel="noopener noreferrer">{__("ap_safecache.freemius_btn_checkout_pro_multi_vendor")}</a>
            {/if}
        {/if}
        <a href="{$ap_safecache_freemius_addon_settings_url|fn_url}" class="btn btn-default">{__("ap_safecache.freemius_btn_license_settings")}</a>
        {if $ap_safecache_freemius_customer_portal_url|default:""}
            <a href="{$ap_safecache_freemius_customer_portal_url|escape:'html'}" class="btn btn-default" target="_blank" rel="noopener noreferrer">{__("ap_safecache.freemius_btn_customer_portal")}</a>
        {/if}
        {if $ap_safecache_freemius_enabled|default:false && ($ap_safecache_freemius_show_activate_button|default:false)}
        <div style="display:inline-flex;flex-wrap:wrap;gap:8px;align-items:center;margin:0;">
        <form action="{""|fn_url}" method="post" style="display:inline-flex;margin:0;padding:0;border:0;">
            {include file="buttons/button.tpl"
                but_role="submit"
                but_meta="btn btn-primary"
                but_name="dispatch[ap_safecache.freemius_sync_license]"
                but_text=__("ap_safecache.freemius_btn_sync")
            }
        </form>
        </div>
        {/if}
    </div>
    <p class="muted" style="margin:10px 0 0 0;font-size:11px;line-height:1.5;">{__("ap_safecache.freemius_funnel_hint")}</p>
</div>

{if !($ap_safecache_license_is_pro|default:true)}
<div class="alert alert-warning">
    <p><strong>{__("ap_safecache.license_free_banner_title")}</strong></p>
    <p class="muted" style="margin-bottom:0;">{__("ap_safecache.license_free_banner_body")}</p>
</div>
{/if}

<ul class="nav nav-tabs ap-safecache-manage-tabs">
    <li class="{if $ap_safecache_manage_tab == 'overview'}active{/if}">
        <a href="{$ap_safecache_manage_tab_urls.overview|fn_url}">{__("ap_safecache.manage_tab_overview")}</a>
    </li>
    <li class="{if $ap_safecache_manage_tab == 'rules'}active{/if}">
        <a href="{$ap_safecache_manage_tab_urls.rules|fn_url}">{__("ap_safecache.manage_tab_rules")}</a>
    </li>
    <li class="{if $ap_safecache_manage_tab == 'monitor'}active{/if}">
        <a href="{$ap_safecache_manage_tab_urls.monitor|fn_url}">{__("ap_safecache.manage_tab_monitor")}</a>
    </li>
    <li class="{if $ap_safecache_manage_tab == 'cache'}active{/if}">
        <a href="{$ap_safecache_manage_tab_urls.cache|fn_url}">{__("ap_safecache.manage_tab_cache")}</a>
    </li>
    <li class="{if $ap_safecache_manage_tab == 'advanced'}active{/if}">
        <a href="{$ap_safecache_manage_tab_urls.advanced|fn_url}">{__("ap_safecache.manage_tab_advanced")}</a>
    </li>
</ul>

<div class="ap-safecache-manage-tab-panels" style="margin-top:12px;">
{if $ap_safecache_manage_tab == 'overview'}
    {include file="addons/ap_safecache/views/ap_safecache/manage_tab_overview.tpl"}
{elseif $ap_safecache_manage_tab == 'rules'}
    {include file="addons/ap_safecache/views/ap_safecache/manage_tab_rules.tpl"}
{elseif $ap_safecache_manage_tab == 'monitor'}
    {* ap-safecache-cf-poll: markup is in manage_tab_monitor.tpl (fn_ap_safecache_manage_notify_if_tpl_missing_cf_poll) *}
    {include file="addons/ap_safecache/views/ap_safecache/manage_tab_monitor.tpl"}
{elseif $ap_safecache_manage_tab == 'cache'}
    {include file="addons/ap_safecache/views/ap_safecache/manage_tab_cache.tpl"}
{else}
    {include file="addons/ap_safecache/views/ap_safecache/manage_tab_advanced.tpl"}
{/if}
</div>

{if $ap_safecache_manage_focus_id}
<script>
(function(w) {
    var id = '{$ap_safecache_manage_focus_id|escape:"javascript"}';
    function run() {
        var el = w.document.getElementById(id);
        if (!el) {
            return;
        }
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    if (w.document.readyState === 'loading') {
        w.document.addEventListener('DOMContentLoaded', run);
    } else {
        run();
    }
})(window);
</script>
{/if}

{/capture}

{include file="common/mainbox.tpl"
    title=__("ap_safecache.page_title")
    content=$smarty.capture.mainbox
    adv_buttons=$smarty.capture.adv_buttons
}
