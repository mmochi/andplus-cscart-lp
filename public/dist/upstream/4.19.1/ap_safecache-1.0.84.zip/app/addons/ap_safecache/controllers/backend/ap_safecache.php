<?php

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}

if ($mode === 'cron_cf_poll' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    fn_ap_safecache_cf_poll_cron_http_response();
    exit;
}
if ($mode === 'cron_freemius_sync' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    fn_ap_safecache_freemius_sync_cron_http_response();
    exit;
}

if ($mode === 'manage' && !empty($_REQUEST['add_ajax_block_id']) && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $bid = (int) $_REQUEST['add_ajax_block_id'];
    if ($bid > 0) {
        if (fn_ap_safecache_merge_ajax_reload_block_id($bid)) {
            fn_set_notification(
                'N',
                __('ap_safecache.notification_title_ajax_blocks'),
                __('ap_safecache.ok_block_added_to_ajax_reload', ['[id]' => (string) $bid])
            );
        } else {
            fn_set_notification(
                'E',
                __('ap_safecache.notification_title_ajax_blocks'),
                __('ap_safecache.err_block_not_found')
            );
        }
    }

    return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-site')];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($mode === 'ping_recommendation_api') {
        fn_ap_safecache_ping_recommendation_api();

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-connection')];
    }

    if ($mode === 'ping_cloudflare') {
        fn_ap_safecache_ping_cloudflare();

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-connection')];
    }

    if ($mode === 'purge_cloudflare_cache') {
        $r = fn_ap_safecache_license_pro_redirect_or_null('ap-safecache-purge');
        if ($r !== null) {
            return $r;
        }
        fn_ap_safecache_purge_cloudflare_cache();

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-purge')];
    }

    if ($mode === 'purge_cloudflare_urls') {
        $r = fn_ap_safecache_license_pro_redirect_or_null('ap-safecache-purge');
        if ($r !== null) {
            return $r;
        }
        $raw = isset($_REQUEST['ap_safecache_purge_urls']) ? (string) $_REQUEST['ap_safecache_purge_urls'] : '';
        fn_ap_safecache_purge_cloudflare_cache_by_urls($raw);

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-purge')];
    }

    if ($mode === 'save_ajax_reload_blocks') {
        $raw = isset($_REQUEST['ap_safecache_ajax_block_ids']) && is_array($_REQUEST['ap_safecache_ajax_block_ids'])
            ? $_REQUEST['ap_safecache_ajax_block_ids']
            : [];
        fn_ap_safecache_save_ajax_reload_blocks_from_post($raw);
        $dom_raw = isset($_REQUEST['ap_safecache_ajax_reload_dom_ids']) ? (string) $_REQUEST['ap_safecache_ajax_reload_dom_ids'] : '';
        fn_ap_safecache_save_ajax_reload_dom_ids_from_raw($dom_raw);
        $cf_status = fn_ap_safecache_after_save_ajax_reload_blocks();

        $msg = __('ap_safecache.ok_ajax_reload_blocks_saved')
            . ' '
            . __('ap_safecache.msg_ajax_save_store_cache_cleared');
        if ($cf_status === 'ok') {
            $msg .= ' ' . __('ap_safecache.msg_ajax_save_cf_purge_ok');
        }

        fn_set_notification(
            'N',
            __('ap_safecache.notification_title_ajax_blocks'),
            $msg
        );

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-site')];
    }

    if ($mode === 'cf_fetch_rules') {
        list($ok, $msg) = fn_ap_safecache_cf_fetch_rules_to_session();
        fn_set_notification($ok ? 'N' : 'E', __('ap_safecache.cf_notification_title'), $msg);

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-cf-sync')];
    }

    if ($mode === 'cf_poll_now') {
        list($ok, $msg) = fn_ap_safecache_cf_poll_live_now();
        fn_set_notification($ok ? 'N' : 'E', __('ap_safecache.cf_notification_title'), $msg);

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-cf-poll')];
    }

    if ($mode === 'cf_append_recommended_cache_rules') {
        $r = fn_ap_safecache_license_pro_redirect_or_null('ap-safecache-cf-cache-rules-anchor');
        if ($r !== null) {
            return $r;
        }
        fn_ap_safecache_cf_append_recommended_cache_rules_to_session();

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-cf-cache-rules-anchor')];
    }

    if ($mode === 'cf_show_diff') {
        fn_ap_safecache_cf_run_diff_from_post();

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-cf-editor')];
    }

    if ($mode === 'cf_apply_cache_rules') {
        fn_ap_safecache_cf_apply_cache_rules_from_post();

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-cf-editor')];
    }

    if ($mode === 'cf_apply_page_rules') {
        fn_ap_safecache_cf_apply_page_rules_from_post();

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-cf-editor')];
    }

    if ($mode === 'cf_backup_create_page') {
        list($ok, $msg) = fn_ap_safecache_cf_backup_create_page_now();
        fn_set_notification($ok ? 'N' : 'E', __('ap_safecache.cf_notification_title'), $msg);

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-cf-backup')];
    }

    if ($mode === 'cf_backup_create_cache') {
        $r = fn_ap_safecache_license_pro_redirect_or_null('ap-safecache-cf-backup');
        if ($r !== null) {
            return $r;
        }
        list($ok, $msg) = fn_ap_safecache_cf_backup_create_cache_now();
        fn_set_notification($ok ? 'N' : 'E', __('ap_safecache.cf_notification_title'), $msg);

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-cf-backup')];
    }

    if ($mode === 'cf_rollback_page') {
        $r = fn_ap_safecache_license_pro_redirect_or_null('ap-safecache-cf-backup');
        if ($r !== null) {
            return $r;
        }
        $bid = isset($_REQUEST['backup_id']) ? (int) $_REQUEST['backup_id'] : 0;
        fn_ap_safecache_cf_rollback_page($bid);

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-cf-backup')];
    }

    if ($mode === 'cf_rollback_cache') {
        $r = fn_ap_safecache_license_pro_redirect_or_null('ap-safecache-cf-backup');
        if ($r !== null) {
            return $r;
        }
        $bid = isset($_REQUEST['backup_id']) ? (int) $_REQUEST['backup_id'] : 0;
        fn_ap_safecache_cf_rollback_cache($bid);

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-cf-backup')];
    }

    if ($mode === 'cf_backup_delete_page') {
        $r = fn_ap_safecache_license_pro_redirect_or_null('ap-safecache-cf-backup');
        if ($r !== null) {
            return $r;
        }
        $bid = isset($_REQUEST['backup_id']) ? (int) $_REQUEST['backup_id'] : 0;
        fn_ap_safecache_cf_backup_delete_page($bid);

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-cf-backup')];
    }

    if ($mode === 'cf_backup_delete_cache') {
        $r = fn_ap_safecache_license_pro_redirect_or_null('ap-safecache-cf-backup');
        if ($r !== null) {
            return $r;
        }
        $bid = isset($_REQUEST['backup_id']) ? (int) $_REQUEST['backup_id'] : 0;
        fn_ap_safecache_cf_backup_delete_cache($bid);

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-cf-backup')];
    }

    if ($mode === 'freemius_sync_license') {
        if (function_exists('fn_ap_safecache_freemius_sync_license')) {
            list($ok, $msg) = fn_ap_safecache_freemius_sync_license();
            fn_set_notification($ok ? 'N' : 'E', __('ap_safecache.notification_title_license'), $msg);
        }

        return [CONTROLLER_STATUS_REDIRECT, fn_ap_safecache_manage_redirect_url('ap-safecache-license-funnel')];
    }
}

if ($mode === 'manage') {
    if (function_exists('fn_ap_safecache_freemius_auto_sync_on_manage_get')) {
        fn_ap_safecache_freemius_auto_sync_on_manage_get();
    }
    fn_ap_safecache_ensure_addon_settings_objects_registered();
    Tygh::$app['view']->assign('ap_safecache_license_is_pro', fn_ap_safecache_is_pro());
    Tygh::$app['view']->assign('ap_safecache_payment_ip', fn_ap_safecache_get_payment_ip_context_for_manage());
    Tygh::$app['view']->assign('ap_safecache_env', fn_ap_safecache_get_environment_snapshot());
    Tygh::$app['view']->assign('ap_safecache_settings', fn_ap_safecache_get_settings_display());
    Tygh::$app['view']->assign('ap_safecache_addon_version', fn_ap_safecache_get_addon_version());
    Tygh::$app['view']->assign('ap_safecache_diagnostic_json', fn_ap_safecache_get_diagnostic_payload_json());
    Tygh::$app['view']->assign('ap_safecache_purge_url_max', (string) AP_SAFECACHE_CF_PURGE_MAX_URLS_TOTAL);

    $sf = isset($_REQUEST['safecache_sf']) ? (int) $_REQUEST['safecache_sf'] : 0;
    if ($sf <= 0) {
        $sf = fn_ap_safecache_get_active_storefront_id_for_picker();
    }
    Tygh::$app['view']->assign('ap_safecache_picker_storefront_id', $sf);
    Tygh::$app['view']->assign('ap_safecache_storefronts', fn_ap_safecache_get_storefronts_for_picker());
    $blocks = fn_ap_safecache_get_blocks_for_picker($sf);
    $ajax_sel = fn_ap_safecache_get_ajax_reload_block_ids();
    Tygh::$app['view']->assign(
        'ap_safecache_blocks_picker',
        fn_ap_safecache_merge_ajax_reload_selection_into_blocks($blocks, $ajax_sel)
    );
    Tygh::$app['view']->assign('ap_safecache_ajax_block_ids_selected', $ajax_sel);
    Tygh::$app['view']->assign('ap_safecache_ajax_block_selected', array_fill_keys($ajax_sel, true));
    Tygh::$app['view']->assign(
        'ap_safecache_ajax_reload_dom_ids_text',
        implode("\n", fn_ap_safecache_get_ajax_reload_dom_ids_manage())
    );

    foreach (fn_ap_safecache_cf_get_manage_assignments() as $k => $v) {
        Tygh::$app['view']->assign($k, $v);
    }

    foreach (fn_ap_safecache_freemius_get_manage_assignments() as $k => $v) {
        Tygh::$app['view']->assign($k, $v);
    }

    $allowed_focus = [
        'ap-safecache-connection',
        'ap-safecache-site',
        'ap-safecache-cf-sync',
        'ap-safecache-cf-poll',
        'ap-safecache-cf-recommended',
        'ap-safecache-cf-editor',
        'ap-safecache-cf-cache-rules-anchor',
        'ap-safecache-cf-backup',
        'ap-safecache-purge',
        'ap-safecache-diagnostics',
        'ap-safecache-license-funnel',
    ];
    $allowed_tabs = ['overview', 'rules', 'monitor', 'cache', 'advanced'];

    $focus = isset($_REQUEST['safecache_focus']) ? (string) $_REQUEST['safecache_focus'] : '';
    if ($focus !== '' && in_array($focus, $allowed_focus, true)) {
        Tygh::$app['view']->assign('ap_safecache_manage_focus_id', $focus);
        $manage_tab = fn_ap_safecache_manage_focus_id_to_tab($focus);
    } else {
        $tab_raw = isset($_REQUEST['safecache_tab']) ? (string) $_REQUEST['safecache_tab'] : 'overview';
        $manage_tab = in_array($tab_raw, $allowed_tabs, true) ? $tab_raw : 'overview';
    }
    Tygh::$app['view']->assign('ap_safecache_manage_tab', $manage_tab);

    $sf_list = fn_ap_safecache_get_storefronts_for_picker();
    $sf_suffix = count($sf_list) > 1 ? '&safecache_sf=' . (int) $sf : '';
    $tab_urls = [];
    foreach ($allowed_tabs as $t) {
        $tab_urls[$t] = 'ap_safecache.manage?safecache_tab=' . rawurlencode($t) . $sf_suffix;
    }
    Tygh::$app['view']->assign('ap_safecache_manage_tab_urls', $tab_urls);

    fn_ap_safecache_manage_notify_if_tpl_missing_cf_poll();
}
