<?php
/***************************************************************************
 * ap_safecache — block_manager.render の追跡ログ（コアの block_manager.pre より先に実行）
 ***************************************************************************/

defined('BOOTSTRAP') or die('Access denied');

if ($mode === 'render' && fn_ap_safecache_is_ajax_block_reload_logging_enabled()) {
    $ctx = [
        'dispatch' => 'block_manager.render',
        'ap_sc_ts' => isset($_REQUEST['ap_sc_ts']) ? (string) $_REQUEST['ap_sc_ts'] : null,
    ];

    if (empty($_REQUEST['object_key'])) {
        $ctx['object_key'] = 'missing';
    } else {
        $plain = fn_decrypt_text($_REQUEST['object_key']);
        if (is_string($plain) && strpos($plain, ':') !== false) {
            $parts = explode(':', $plain, 2);
            $ctx['block_id'] = isset($parts[0]) ? (int) $parts[0] : 0;
            $ctx['snapping_id'] = isset($parts[1]) ? (int) $parts[1] : 0;
        } else {
            $ctx['decrypt_ok'] = false;
        }
    }

    fn_ap_safecache_log_ajax_block_reload_event('block_manager_render', $ctx);
}
