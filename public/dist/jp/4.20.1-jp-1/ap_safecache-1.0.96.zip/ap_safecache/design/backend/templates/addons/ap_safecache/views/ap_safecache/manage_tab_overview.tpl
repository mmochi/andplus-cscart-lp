<div class="dashboard-row" id="ap-safecache-connection" style="scroll-margin-top:72px;">
    <div>
        {include file="common/subheader.tpl" title=__("ap_safecache.ui_group_connection")}
        <p class="muted">{__("ap_safecache.ui_group_connection_hint")}</p>
        <p class="muted">{__("ap_safecache.settings_hint")}</p>

        <p style="margin-top: 12px;"><strong>{__("ap_safecache.ui_external_services")}</strong></p>
        <div class="table-responsive-wrapper">
            <table class="table table-middle table--relative">
                <tbody>
                    <tr>
                        <td width="35%" class="muted">{__("ap_safecache.opt_recommendation_api_base_url")}</td>
                        <td>
                            {if $ap_safecache_settings.recommendation_api_base_url}
                                {$ap_safecache_settings.recommendation_api_base_url|escape}
                            {else}
                                <span class="muted">{__("ap_safecache.not_set")}</span>
                            {/if}
                        </td>
                    </tr>
                    <tr>
                        <td class="muted">{__("ap_safecache.opt_cloudflare_zone_id")}</td>
                        <td>
                            {if $ap_safecache_settings.cloudflare_zone_id}
                                {$ap_safecache_settings.cloudflare_zone_id|escape}
                            {else}
                                <span class="muted">{__("ap_safecache.not_set")}</span>
                            {/if}
                        </td>
                    </tr>
                    <tr>
                        <td class="muted">{__("ap_safecache.opt_cloudflare_api_token")}</td>
                        <td>
                            {if $ap_safecache_settings.cloudflare_api_token_set}
                                {__("ap_safecache.token_set")}
                            {else}
                                <span class="muted">{__("ap_safecache.token_not_set")}</span>
                            {/if}
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <details class="ap-safecache-manage-fold" style="margin-top:12px;border:1px solid #e0e0e0;border-radius:4px;background:#fafafa;">
            <summary>{__("ap_safecache.manage_fold_site_behavior")}</summary>
            <div style="padding:10px 12px 12px 12px;border-top:1px solid #e8e8e8;">
                <p style="margin:0 0 8px 0;"><strong>{__("ap_safecache.ui_site_behavior_settings")}</strong></p>
                <div class="table-responsive-wrapper">
                    <table class="table table-middle table--relative">
                        <tbody>
                            <tr>
                                <td width="35%" class="muted">{__("ap_safecache.opt_ajax_reload_blocks")}</td>
                                <td>{$ap_safecache_settings.ajax_reload_block_count|escape}</td>
                            </tr>
                            <tr>
                                <td class="muted">{__("ap_safecache.opt_ajax_reload_dom_ids_merged")}</td>
                                <td>{$ap_safecache_settings.ajax_reload_dom_id_merged_count|escape}</td>
                            </tr>
                            <tr>
                                <td class="muted">{__("ap_safecache.opt_restore_remote_addr_from_cf")}</td>
                                <td>{if $ap_safecache_settings.restore_remote_addr_from_cf}{__("yes")}{else}{__("no")}{/if}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </details>

        <div style="margin-top: 16px; padding-top: 12px; border-top: 1px solid #e8e8e8;">
            {include file="common/subheader.tpl" title=__("ap_safecache.connectivity_checks")}
            <p class="muted">{__("ap_safecache.connectivity_checks_hint")}</p>
            <form action="{""|fn_url}" method="post" id="ap_safecache_connectivity_form" name="ap_safecache_connectivity_form">
                <div class="btn-group">
                    {include file="buttons/button.tpl"
                        but_role="submit"
                        but_meta="btn"
                        but_name="dispatch[ap_safecache.ping_recommendation_api]"
                        but_text=__("ap_safecache.btn_ping_recommendation_api")
                    }
                    {include file="buttons/button.tpl"
                        but_role="submit"
                        but_meta="btn"
                        is_btn_primary=false
                        but_name="dispatch[ap_safecache.ping_cloudflare]"
                        but_text=__("ap_safecache.btn_ping_cloudflare")
                    }
                </div>
            </form>
        </div>
    </div>
</div>

<div id="ap-safecache-overview-summary" class="well well-small" style="margin-top:16px;border-left:4px solid #5bc0de;">
    <p style="margin:0 0 8px 0;"><strong>{__("ap_safecache.overview_status_heading")}</strong></p>
    <p style="margin:0 0 6px 0;font-size:13px;line-height:1.5;">
        <span class="muted">{__("ap_safecache.cf_sync_section_title")}:</span>
        {if $ap_safecache_cf_fetched_at}
            {$ap_safecache_cf_fetched_at|date_format:"%Y-%m-%d %H:%M"}
        {else}
            <span class="muted">{__("ap_safecache.cf_not_fetched")}</span>
        {/if}
    </p>
    <p style="margin:0 0 6px 0;font-size:13px;line-height:1.5;">
        {if $ap_safecache_cf_poll_display.status_code == 'none'}
            <span class="muted">{__("ap_safecache.cf_poll_never")}</span>
        {else}
            <strong>{__("ap_safecache.cf_poll_card_headline")}</strong> {$ap_safecache_cf_poll_display.status_label|escape}
            {if $ap_safecache_cf_poll_display.last_success_at}
                <span class="muted" style="margin-left:6px;">({__("ap_safecache.cf_poll_disp_last_success", ["[time]" => $ap_safecache_cf_poll_display.last_success_at|date_format:"%Y-%m-%d %H:%M"])})</span>
            {/if}
        {/if}
    </p>
    <p class="muted" style="margin:0;font-size:12px;line-height:1.45;">{__("ap_safecache.overview_status_footer")}</p>
    <p style="margin:10px 0 0 0;">
        <a href="{$ap_safecache_manage_tab_urls.monitor|fn_url}" class="btn btn-default btn-sm">{__("ap_safecache.manage_tab_monitor")}</a>
        <a href="{$ap_safecache_manage_tab_urls.rules|fn_url}" class="btn btn-default btn-sm" style="margin-left:6px;">{__("ap_safecache.manage_tab_rules")}</a>
    </p>
</div>
