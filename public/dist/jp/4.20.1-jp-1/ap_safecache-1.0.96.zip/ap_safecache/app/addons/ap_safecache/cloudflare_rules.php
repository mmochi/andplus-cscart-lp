<?php

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}

use Tygh\Http;
use Tygh\Registry;
use Tygh\Tygh;

/**
 * Cloudflare Rules API（Page Rules / Cache Rules の Rulesets）用。WAF 系は扱わない。
 */

/**
 * DB テーブル（バックアップ：Page / Cache を別テーブル・別世代）。新規インストール・アップグレード両対応。
 */
function fn_ap_safecache_cf_ensure_backup_table()
{
    static $done = false;

    if ($done) {
        return;
    }

    db_query(
        'CREATE TABLE IF NOT EXISTS ?:ap_safecache_cf_page_backups ('
        . ' backup_id int(11) unsigned NOT NULL auto_increment,'
        . ' zone_id varchar(64) NOT NULL default \'\','
        . ' generation int(11) unsigned NOT NULL default 0,'
        . ' created_at int(11) unsigned NOT NULL default 0,'
        . ' user_id int(11) unsigned NOT NULL default 0,'
        . ' payload mediumtext,'
        . ' PRIMARY KEY (backup_id),'
        . ' KEY zone_id (zone_id),'
        . ' KEY zone_gen (zone_id, generation)'
        . ') ENGINE=MyISAM DEFAULT CHARSET=utf8'
    );

    db_query(
        'CREATE TABLE IF NOT EXISTS ?:ap_safecache_cf_cache_backups ('
        . ' backup_id int(11) unsigned NOT NULL auto_increment,'
        . ' zone_id varchar(64) NOT NULL default \'\','
        . ' generation int(11) unsigned NOT NULL default 0,'
        . ' created_at int(11) unsigned NOT NULL default 0,'
        . ' user_id int(11) unsigned NOT NULL default 0,'
        . ' payload mediumtext,'
        . ' PRIMARY KEY (backup_id),'
        . ' KEY zone_id (zone_id),'
        . ' KEY zone_gen (zone_id, generation)'
        . ') ENGINE=MyISAM DEFAULT CHARSET=utf8'
    );

    fn_ap_safecache_cf_migrate_legacy_combined_backup_table_if_needed();

    $done = true;
}

/**
 * 旧 ap_safecache_cf_backups（1 行に Page + Cache）があれば分割テーブルへ移行して削除する。
 */
function fn_ap_safecache_cf_migrate_legacy_combined_backup_table_if_needed()
{
    static $migrated = false;

    if ($migrated) {
        return;
    }

    $full_name = Registry::get('config.table_prefix') . 'ap_safecache_cf_backups';
    $exists = (int) db_get_field(
        'SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?s',
        $full_name
    );

    if ($exists < 1) {
        $migrated = true;

        return;
    }

    $rows = db_get_array('SELECT * FROM ?:ap_safecache_cf_backups ORDER BY backup_id ASC');
    if (!empty($rows)) {
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $z = isset($row['zone_id']) ? (string) $row['zone_id'] : '';
            $gen = isset($row['generation']) ? (int) $row['generation'] : 0;
            $ca = isset($row['created_at']) ? (int) $row['created_at'] : 0;
            $uid = isset($row['user_id']) ? (int) $row['user_id'] : 0;
            $pj = isset($row['page_rules']) ? (string) $row['page_rules'] : '[]';
            $cj = isset($row['cache_ruleset']) ? (string) $row['cache_ruleset'] : '{}';

            db_query(
                'INSERT INTO ?:ap_safecache_cf_page_backups ?e',
                [
                    'zone_id'    => $z,
                    'generation' => $gen,
                    'created_at' => $ca,
                    'user_id'    => $uid,
                    'payload'    => $pj,
                ]
            );
            db_query(
                'INSERT INTO ?:ap_safecache_cf_cache_backups ?e',
                [
                    'zone_id'    => $z,
                    'generation' => $gen,
                    'created_at' => $ca,
                    'user_id'    => $uid,
                    'payload'    => $cj,
                ]
            );
        }
    }

    db_query('DROP TABLE IF EXISTS ?:ap_safecache_cf_backups');
    $migrated = true;
}

/**
 * 既存 DB 向け: ap_safecache_cf_poll_state に表示用カラムを追加。
 */
function fn_ap_safecache_cf_poll_state_migrate_columns()
{
    static $migrated = false;

    if ($migrated) {
        return;
    }
    $migrated = true;

    $check = db_get_row('SHOW COLUMNS FROM ?:ap_safecache_cf_poll_state WHERE Field = ?s', 'last_status');
    if (!empty($check)) {
        return;
    }

    db_query(
        'ALTER TABLE ?:ap_safecache_cf_poll_state'
        . ' ADD COLUMN last_status varchar(16) NOT NULL default \'ok\','
        . ' ADD COLUMN changed_targets varchar(16) NOT NULL default \'\','
        . ' ADD COLUMN last_error_message varchar(512) NOT NULL default \'\','
        . ' ADD COLUMN last_failed_at int(11) unsigned NOT NULL default 0'
    );
}

/**
 * ライブ設定ポール用テーブル（ゾーン単位の直近ハッシュ＋履歴ログ）。
 */
function fn_ap_safecache_cf_ensure_poll_tables()
{
    static $done = false;

    if ($done) {
        return;
    }

    db_query(
        'CREATE TABLE IF NOT EXISTS ?:ap_safecache_cf_poll_state ('
        . ' zone_id varchar(64) NOT NULL,'
        . ' page_hash char(64) NOT NULL default \'\','
        . ' cache_hash char(64) NOT NULL default \'\','
        . ' last_checked_at int(11) unsigned NOT NULL default 0,'
        . ' last_changed_at int(11) unsigned NOT NULL default 0,'
        . ' last_status varchar(16) NOT NULL default \'ok\','
        . ' changed_targets varchar(16) NOT NULL default \'\','
        . ' last_error_message varchar(512) NOT NULL default \'\','
        . ' last_failed_at int(11) unsigned NOT NULL default 0,'
        . ' PRIMARY KEY (zone_id)'
        . ') ENGINE=MyISAM DEFAULT CHARSET=utf8'
    );

    fn_ap_safecache_cf_poll_state_migrate_columns();

    db_query(
        'CREATE TABLE IF NOT EXISTS ?:ap_safecache_cf_poll_log ('
        . ' log_id int(11) unsigned NOT NULL auto_increment,'
        . ' zone_id varchar(64) NOT NULL default \'\','
        . ' created_at int(11) unsigned NOT NULL default 0,'
        . ' user_id int(11) unsigned NOT NULL default 0,'
        . ' page_hash char(64) NOT NULL default \'\','
        . ' cache_hash char(64) NOT NULL default \'\','
        . ' prev_page_hash char(64) NOT NULL default \'\','
        . ' prev_cache_hash char(64) NOT NULL default \'\','
        . ' changed tinyint(1) unsigned NOT NULL default 0,'
        . ' backup_ok tinyint(1) unsigned NOT NULL default 0,'
        . ' error_message varchar(512) NOT NULL default \'\','
        . ' source varchar(16) NOT NULL default \'manual\','
        . ' PRIMARY KEY (log_id),'
        . ' KEY zone_id (zone_id),'
        . ' KEY zone_created (zone_id, created_at)'
        . ') ENGINE=MyISAM DEFAULT CHARSET=utf8'
    );

    $done = true;
}

/**
 * 前回ハッシュと今回ハッシュから、どちらのルール集合が変わったかを正規化。
 *
 * @return string page|cache|both|''
 */
function fn_ap_safecache_cf_poll_resolve_changed_targets($prev_p, $prev_c, $ph, $ch)
{
    $p_changed = ((string) $prev_p !== (string) $ph);
    $c_changed = ((string) $prev_c !== (string) $ch);
    if ($p_changed && $c_changed) {
        return 'both';
    }
    if ($p_changed) {
        return 'page';
    }
    if ($c_changed) {
        return 'cache';
    }

    return '';
}

/**
 * API 取得失敗時: 既存のポール状態行があれば last_status=error を記録（ハッシュは更新しない）。
 */
function fn_ap_safecache_cf_poll_state_record_error($zone_id, $err_msg)
{
    fn_ap_safecache_cf_ensure_poll_tables();
    $zone_id = trim((string) $zone_id);
    if ($zone_id === '') {
        return;
    }
    $exists = db_get_row('SELECT zone_id FROM ?:ap_safecache_cf_poll_state WHERE zone_id = ?s', $zone_id);
    if (empty($exists)) {
        return;
    }
    $err_msg = substr((string) $err_msg, 0, 512);
    $now = time();
    db_query(
        'UPDATE ?:ap_safecache_cf_poll_state SET last_status = ?s, last_error_message = ?s, last_failed_at = ?i WHERE zone_id = ?s',
        'error',
        $err_msg,
        $now,
        $zone_id
    );
}

/**
 * 管理画面ポール欄用: DB に保存された最終観測をラベル化。
 *
 * @param array<string, int|string>|null $row fn_ap_safecache_cf_get_poll_state_for_zone の戻り
 *
 * @return array<string, int|string>
 */
function fn_ap_safecache_cf_get_poll_state_display_for_manage($row)
{
    $base_none = [
        'status_code'       => 'none',
        'status_label'      => '',
        'targets_label'     => '',
        'last_success_at'   => 0,
        'last_failed_at'    => 0,
        'error_message'     => '',
        'card_tone'         => 'neutral',
        'page_line_code'    => 'none',
        'cache_line_code'   => 'none',
        'page_line_label'   => '',
        'cache_line_label'  => '',
    ];

    if ($row === null || !is_array($row) || empty($row['zone_id'])) {
        return $base_none;
    }

    $status = isset($row['last_status']) ? (string) $row['last_status'] : 'ok';
    if ($status === '') {
        $status = 'ok';
    }
    if (!in_array($status, ['ok', 'changed', 'error'], true)) {
        $status = 'ok';
    }

    $labels = [
        'ok'      => __('ap_safecache.cf_poll_disp_status_ok'),
        'changed' => __('ap_safecache.cf_poll_disp_status_changed'),
        'error'   => __('ap_safecache.cf_poll_disp_status_error'),
    ];
    $status_label = isset($labels[$status]) ? $labels[$status] : $labels['ok'];

    $targets = isset($row['changed_targets']) ? (string) $row['changed_targets'] : '';
    $targets_label = '';
    if ($status === 'changed') {
        if ($targets === 'page') {
            $targets_label = __('ap_safecache.cf_poll_disp_targets_page');
        } elseif ($targets === 'cache') {
            $targets_label = __('ap_safecache.cf_poll_disp_targets_cache');
        } elseif ($targets === 'both') {
            $targets_label = __('ap_safecache.cf_poll_disp_targets_both');
        }
    }

    $lbl_ok = __('ap_safecache.cf_poll_line_ok');
    $lbl_changed = __('ap_safecache.cf_poll_line_changed');
    $lbl_unknown = __('ap_safecache.cf_poll_line_unknown');
    $lbl_none = __('ap_safecache.cf_poll_line_none');

    $card_tone = 'neutral';
    $page_line_code = 'ok';
    $cache_line_code = 'ok';
    $page_line_label = $lbl_ok;
    $cache_line_label = $lbl_ok;

    if ($status === 'ok') {
        $card_tone = 'success';
    } elseif ($status === 'error') {
        $card_tone = 'danger';
        $page_line_code = 'unknown';
        $cache_line_code = 'unknown';
        $page_line_label = $lbl_unknown;
        $cache_line_label = $lbl_unknown;
    } elseif ($status === 'changed') {
        $card_tone = 'warning';
        if ($targets === 'page') {
            $page_line_code = 'changed';
            $cache_line_code = 'ok';
            $page_line_label = $lbl_changed;
            $cache_line_label = $lbl_ok;
        } elseif ($targets === 'cache') {
            $page_line_code = 'ok';
            $cache_line_code = 'changed';
            $page_line_label = $lbl_ok;
            $cache_line_label = $lbl_changed;
        } else {
            $page_line_code = 'changed';
            $cache_line_code = 'changed';
            $page_line_label = $lbl_changed;
            $cache_line_label = $lbl_changed;
        }
    }

    return [
        'status_code'       => $status,
        'status_label'      => $status_label,
        'targets_label'     => $targets_label,
        'last_success_at'   => (int) ($row['last_checked_at'] ?? 0),
        'last_failed_at'    => (int) ($row['last_failed_at'] ?? 0),
        'error_message'     => isset($row['last_error_message']) ? (string) $row['last_error_message'] : '',
        'card_tone'         => $card_tone,
        'page_line_code'    => $page_line_code,
        'cache_line_code'   => $cache_line_code,
        'page_line_label'   => $page_line_label,
        'cache_line_label'  => $cache_line_label,
    ];
}

/**
 * ポールログ1行の「どちらが変わったか」短ラベル（テーブル列用）。
 *
 * @param array<string, int|string> $row
 */
function fn_ap_safecache_cf_poll_log_row_targets_short(array $row)
{
    $em = isset($row['error_message']) ? trim((string) $row['error_message']) : '';
    if ($em !== '') {
        return __('ap_safecache.cf_poll_log_targets_error');
    }
    if (empty($row['changed'])) {
        return '—';
    }
    $pp = (string) ($row['prev_page_hash'] ?? '');
    $pc = (string) ($row['prev_cache_hash'] ?? '');
    $p = (string) ($row['page_hash'] ?? '');
    $c = (string) ($row['cache_hash'] ?? '');
    $pg = ($pp !== $p);
    $cg = ($pc !== $c);
    if ($pg && $cg) {
        return __('ap_safecache.cf_poll_disp_targets_both');
    }
    if ($pg) {
        return __('ap_safecache.cf_poll_disp_targets_page');
    }
    if ($cg) {
        return __('ap_safecache.cf_poll_disp_targets_cache');
    }

    return __('ap_safecache.cf_poll_log_targets_changed_unknown');
}

/**
 * 管理テーブル用にログ行へ UI メタを付与。
 *
 * @param list<array<string, int|string>> $rows
 *
 * @return list<array<string, int|string>>
 */
function fn_ap_safecache_cf_enrich_poll_log_for_manage_ui(array $rows)
{
    $out = [];
    foreach ($rows as $r) {
        if (!is_array($r)) {
            continue;
        }
        $em = isset($r['error_message']) ? trim((string) $r['error_message']) : '';
        if ($em !== '') {
            $r['ui_row_tone'] = 'error';
        } elseif (!empty($r['changed'])) {
            $r['ui_row_tone'] = 'warning';
        } else {
            $r['ui_row_tone'] = 'ok';
        }
        $r['ui_targets_short'] = fn_ap_safecache_cf_poll_log_row_targets_short($r);
        $out[] = $r;
    }

    return $out;
}

/**
 * @param string               $zone_id
 * @param int                  $user_id
 * @param array<string, mixed> $fields
 */
function fn_ap_safecache_cf_poll_insert_log($zone_id, $user_id, array $fields)
{
    fn_ap_safecache_cf_ensure_poll_tables();

    $row = array_merge(
        [
            'zone_id'        => (string) $zone_id,
            'created_at'     => time(),
            'user_id'        => (int) $user_id,
            'page_hash'      => '',
            'cache_hash'     => '',
            'prev_page_hash' => '',
            'prev_cache_hash' => '',
            'changed'        => 0,
            'backup_ok'      => 0,
            'error_message'  => '',
            'source'         => 'manual',
        ],
        $fields
    );

    db_query('INSERT INTO ?:ap_safecache_cf_poll_log ?e', $row);
}

/**
 * ライブ Page / Cache を取得しフィンガープリント。前回と異なればバックアップを取得する。
 *
 * @param string $poll_source ログ用: manual（管理画面）| cron（wget / サーバ cron）
 *
 * @return array{0: bool, 1: string, 2: array<string, int|string|bool>}
 */
function fn_ap_safecache_cf_poll_live_now($poll_source = 'manual')
{
    fn_ap_safecache_cf_ensure_poll_tables();
    fn_ap_safecache_cf_ensure_backup_table();

    $poll_src = ($poll_source === 'cron') ? 'cron' : 'manual';

    list($ok_cred, $_t, $zone_id) = fn_ap_safecache_cf_get_credentials();
    if (!$ok_cred) {
        return [false, __('ap_safecache.cf_err_credentials'), ['changed' => false, 'backup_ok' => false]];
    }

    $user_id = 0;
    if ($poll_src !== 'cron' && !empty(Tygh::$app['session']['auth']['user_id'])) {
        $user_id = (int) Tygh::$app['session']['auth']['user_id'];
    }

    list($ok_live, $page_rules, $cache_ruleset, $err) = fn_ap_safecache_cf_fetch_live_configuration();
    if (!$ok_live) {
        fn_ap_safecache_cf_poll_insert_log($zone_id, $user_id, [
            'error_message' => $err,
            'source'        => $poll_src,
        ]);
        fn_ap_safecache_cf_poll_state_record_error($zone_id, $err);

        return [false, $err, ['changed' => false, 'backup_ok' => false]];
    }

    $page_rules = is_array($page_rules) ? $page_rules : [];
    $cache_ruleset = is_array($cache_ruleset) ? $cache_ruleset : [];

    $ph = fn_ap_safecache_cf_fingerprint_hash_page_rules($page_rules);
    $ch = fn_ap_safecache_cf_fingerprint_hash_cache_ruleset($cache_ruleset);
    $now = time();

    $row = db_get_row('SELECT * FROM ?:ap_safecache_cf_poll_state WHERE zone_id = ?s', $zone_id);

    if (empty($row) || !is_array($row)) {
        db_query(
            'INSERT INTO ?:ap_safecache_cf_poll_state ?e',
            [
                'zone_id'             => $zone_id,
                'page_hash'           => $ph,
                'cache_hash'          => $ch,
                'last_checked_at'     => $now,
                'last_changed_at'     => $now,
                'last_status'         => 'ok',
                'changed_targets'     => '',
                'last_error_message'  => '',
                'last_failed_at'      => 0,
            ]
        );
        fn_ap_safecache_cf_poll_insert_log($zone_id, $user_id, [
            'page_hash'       => $ph,
            'cache_hash'      => $ch,
            'prev_page_hash'  => '',
            'prev_cache_hash' => '',
            'changed'         => 0,
            'backup_ok'       => 0,
            'source'          => $poll_src,
        ]);

        return [true, __('ap_safecache.cf_poll_ok_first'), ['changed' => false, 'backup_ok' => false, 'page_hash' => $ph, 'cache_hash' => $ch]];
    }

    $prev_p = isset($row['page_hash']) ? (string) $row['page_hash'] : '';
    $prev_c = isset($row['cache_hash']) ? (string) $row['cache_hash'] : '';
    $changed = ($prev_p !== $ph || $prev_c !== $ch);

    if (!$changed) {
        db_query(
            'UPDATE ?:ap_safecache_cf_poll_state SET last_checked_at = ?i, last_status = ?s, changed_targets = ?s, last_error_message = ?s, last_failed_at = ?i WHERE zone_id = ?s',
            $now,
            'ok',
            '',
            '',
            0,
            $zone_id
        );
        fn_ap_safecache_cf_poll_insert_log($zone_id, $user_id, [
            'page_hash'       => $ph,
            'cache_hash'      => $ch,
            'prev_page_hash'  => $prev_p,
            'prev_cache_hash' => $prev_c,
            'changed'         => 0,
            'backup_ok'       => 0,
            'source'          => $poll_src,
        ]);

        return [true, __('ap_safecache.cf_poll_ok_unchanged'), ['changed' => false, 'backup_ok' => false, 'page_hash' => $ph, 'cache_hash' => $ch]];
    }

    $backup_ok = true;
    $backup_err = '';
    if (fn_ap_safecache_is_pro()) {
        list($ok_bp, $msg_bp) = fn_ap_safecache_cf_backup_create_page_now(['skip_license_action_token' => true]);
        if (!$ok_bp) {
            $backup_ok = false;
            $backup_err .= $msg_bp . ' ';
        }
        list($ok_bc, $msg_bc) = fn_ap_safecache_cf_backup_create_cache_now(['skip_license_action_token' => true]);
        if (!$ok_bc) {
            $backup_ok = false;
            $backup_err .= $msg_bc . ' ';
        }
    } else {
        $backup_ok = false;
    }

    $targets = fn_ap_safecache_cf_poll_resolve_changed_targets($prev_p, $prev_c, $ph, $ch);

    db_query(
        'UPDATE ?:ap_safecache_cf_poll_state SET page_hash = ?s, cache_hash = ?s, last_checked_at = ?i, last_changed_at = ?i, last_status = ?s, changed_targets = ?s, last_error_message = ?s, last_failed_at = ?i WHERE zone_id = ?s',
        $ph,
        $ch,
        $now,
        $now,
        'changed',
        $targets,
        '',
        0,
        $zone_id
    );

    fn_ap_safecache_cf_poll_insert_log($zone_id, $user_id, [
        'page_hash'       => $ph,
        'cache_hash'      => $ch,
        'prev_page_hash'  => $prev_p,
        'prev_cache_hash' => $prev_c,
        'changed'         => 1,
        'backup_ok'       => $backup_ok ? 1 : 0,
        'error_message'   => trim($backup_err),
        'source'          => $poll_src,
    ]);

    if (!fn_ap_safecache_is_pro()) {
        $msg = __('ap_safecache.cf_poll_ok_changed_free');

        return [true, $msg, ['changed' => true, 'backup_ok' => false, 'page_hash' => $ph, 'cache_hash' => $ch]];
    }

    $msg = $backup_ok
        ? __('ap_safecache.cf_poll_ok_changed_backup')
        : __('ap_safecache.cf_poll_ok_changed_backup_partial', ['[detail]' => trim($backup_err)]);

    return [true, $msg, ['changed' => true, 'backup_ok' => $backup_ok, 'page_hash' => $ph, 'cache_hash' => $ch]];
}

/**
 * @return array<string, int|string>|null
 */
function fn_ap_safecache_cf_get_poll_state_for_zone($zone_id)
{
    fn_ap_safecache_cf_ensure_poll_tables();
    $zone_id = trim((string) $zone_id);
    if ($zone_id === '') {
        return null;
    }

    $row = db_get_row('SELECT * FROM ?:ap_safecache_cf_poll_state WHERE zone_id = ?s', $zone_id);

    return is_array($row) ? $row : null;
}

/**
 * @return list<array<string, int|string>>
 */
function fn_ap_safecache_cf_get_poll_log_recent($zone_id, $limit = 15)
{
    fn_ap_safecache_cf_ensure_poll_tables();
    $zone_id = trim((string) $zone_id);
    if ($zone_id === '') {
        return [];
    }
    $limit = max(1, min(50, (int) $limit));

    return db_get_array(
        'SELECT log_id, zone_id, created_at, user_id, page_hash, cache_hash, prev_page_hash, prev_cache_hash, changed, backup_ok, error_message, source'
        . ' FROM ?:ap_safecache_cf_poll_log WHERE zone_id = ?s ORDER BY log_id DESC LIMIT ?i',
        $zone_id,
        $limit
    );
}

/**
 * Cloudflare API から Page Rules のみ取得（バックアップ用に単体 GET）。
 *
 * @return array{0: bool, 1: list<array<string, mixed>>, 2: string}
 */
function fn_ap_safecache_cf_fetch_live_page_rules_only()
{
    list($ok, $_t, $zone_id) = fn_ap_safecache_cf_get_credentials();
    if (!$ok) {
        return [false, [], __('ap_safecache.cf_err_credentials')];
    }

    list($ok_pr, $data_pr, $err_pr) = fn_ap_safecache_cf_api('GET', 'zones/' . rawurlencode($zone_id) . '/pagerules');
    if (!$ok_pr) {
        return [false, [], __('ap_safecache.cf_err_fetch_page_rules') . ' ' . $err_pr];
    }

    $page_rules = [];
    if (!empty($data_pr['result']) && is_array($data_pr['result'])) {
        $page_rules = $data_pr['result'];
    }

    return [true, $page_rules, ''];
}

/**
 * Cloudflare API から Cache Rules（http_request_cache_settings entrypoint）のみ取得。
 *
 * @return array{0: bool, 1: array<string, mixed>, 2: string}
 */
function fn_ap_safecache_cf_fetch_live_cache_ruleset_only()
{
    list($ok, $_t, $zone_id) = fn_ap_safecache_cf_get_credentials();
    if (!$ok) {
        return [false, [], __('ap_safecache.cf_err_credentials')];
    }

    $path_cache = 'zones/' . rawurlencode($zone_id) . '/rulesets/phases/http_request_cache_settings/entrypoint';
    list($ok_cr, $data_cr, $err_cr) = fn_ap_safecache_cf_api('GET', $path_cache);
    if (!$ok_cr) {
        return [false, [], __('ap_safecache.cf_err_fetch_cache_rules') . ' ' . $err_cr];
    }

    $cache_ruleset = isset($data_cr['result']) && is_array($data_cr['result']) ? $data_cr['result'] : [];

    return [true, $cache_ruleset, ''];
}

/**
 * Cloudflare API から現在の Page Rules と Cache Rules（entrypoint）を取得（セッションによらない）。
 *
 * @return array{0: bool, 1: list<array<string, mixed>>|array<string, mixed>, 2: array<string, mixed>|list<array<string, mixed>>, 3: string}
 *         [ok, page_rules, cache_ruleset, error_message]
 */
function fn_ap_safecache_cf_fetch_live_configuration()
{
    list($ok_p, $page_rules, $err_p) = fn_ap_safecache_cf_fetch_live_page_rules_only();
    if (!$ok_p) {
        return [false, [], [], $err_p];
    }

    list($ok_c, $cache_ruleset, $err_c) = fn_ap_safecache_cf_fetch_live_cache_ruleset_only();
    if (!$ok_c) {
        return [false, $page_rules, [], $err_c];
    }

    return [true, $page_rules, $cache_ruleset, ''];
}

/**
 * @return array{0: bool, 1: string, 2: string} [ok, token, zone_id]
 */
function fn_ap_safecache_cf_get_credentials()
{
    $addon = Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];
    $token = isset($addon['cloudflare_api_token']) ? trim((string) $addon['cloudflare_api_token']) : '';
    $zone_id = isset($addon['cloudflare_zone_id']) ? trim((string) $addon['cloudflare_zone_id']) : '';

    if ($token === '' || $zone_id === '') {
        return [false, '', ''];
    }

    return [true, $token, $zone_id];
}

/**
 * @param 'GET'|'POST'|'PUT'|'DELETE' $method
 * @param string                     $path_after_v4 zones/... （先頭・末尾スラッシュなし）
 *
 * @return array{0: bool, 1: array|null, 2: string} [ok, decoded_or_null, error_detail]
 */
function fn_ap_safecache_cf_api($method, $path_after_v4, $body = null)
{
    list($ok, $token, $zone_id) = fn_ap_safecache_cf_get_credentials();
    if (!$ok) {
        return [false, null, __('ap_safecache.cf_err_credentials')];
    }

    $url = 'https://api.cloudflare.com/client/v4/' . $path_after_v4;
    $extra = [
        'timeout' => 90,
        'headers' => [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
        ],
    ];

    $payload = $body !== null ? json_encode($body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : '';

    if ($method === 'GET') {
        $response = Http::get($url, [], $extra);
    } elseif ($method === 'POST') {
        $response = Http::post($url, $payload, $extra);
    } elseif ($method === 'PUT') {
        $response = Http::put($url, $payload, $extra);
    } elseif ($method === 'DELETE') {
        $response = Http::delete($url, $extra);
    } else {
        return [false, null, 'Bad method'];
    }

    $status = (int) Http::getStatus();

    if ($response === false) {
        return [false, null, __('ap_safecache.err_http_request_failed')];
    }

    $data = json_decode($response, true);
    if (!is_array($data)) {
        return [false, null, __('ap_safecache.cf_err_invalid_json')];
    }

    if ($status < 200 || $status >= 300 || empty($data['success'])) {
        $detail = '';
        if (!empty($data['errors']) && is_array($data['errors'])) {
            $msgs = [];
            foreach ($data['errors'] as $err) {
                if (!empty($err['message'])) {
                    $msgs[] = (string) $err['message'];
                }
            }
            if ($msgs !== []) {
                $detail = ' ' . implode('; ', $msgs);
            }
        }

        return [false, $data, __('ap_safecache.err_http_status', ['[status]' => (string) $status]) . $detail];
    }

    return [true, $data, ''];
}

/**
 * @return array<string, mixed>
 */
function fn_ap_safecache_cf_session_get_bucket()
{
    if (empty(Tygh::$app['session']['ap_safecache_cf'])) {
        Tygh::$app['session']['ap_safecache_cf'] = [];
    }

    return Tygh::$app['session']['ap_safecache_cf'];
}

/**
 * @param array<string, mixed> $data
 */
function fn_ap_safecache_cf_session_set_bucket(array $data)
{
    Tygh::$app['session']['ap_safecache_cf'] = $data;
}

/**
 * Cloudflare から Page Rules と Cache Rules（http_request_cache_settings エントリポイント）を取得しセッションに保存。
 *
 * @return array{0: bool, 1: string} [ok, message]
 */
function fn_ap_safecache_cf_fetch_rules_to_session()
{
    list($ok, $page_rules, $cache_ruleset, $err) = fn_ap_safecache_cf_fetch_live_configuration();
    if (!$ok) {
        return [false, $err];
    }

    fn_ap_safecache_cf_session_set_bucket([
        'page_rules'                  => $page_rules,
        'cache_ruleset'               => $cache_ruleset,
        'fetched_at'                  => time(),
        'page_rules_diff_baseline'    => fn_ap_safecache_cf_deep_copy_array($page_rules),
        'cache_ruleset_diff_baseline' => fn_ap_safecache_cf_deep_copy_array($cache_ruleset),
    ]);

    return [true, __('ap_safecache.cf_ok_fetch')];
}

/**
 * セッション保持用の深いコピー（差分ベースラインと編集内容の参照共有を避ける）。
 *
 * @param mixed $data
 *
 * @return array<mixed>|list<mixed>
 */
function fn_ap_safecache_cf_deep_copy_array($data)
{
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        return is_array($data) ? $data : [];
    }
    $copy = json_decode($json, true);

    return is_array($copy) ? $copy : [];
}

/**
 * @param mixed $data
 */
function fn_ap_safecache_cf_json_stable($data)
{
    return (string) json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

/**
 * Cache Rules: ルール配列を id でマップ（id なしは仮 id）。
 *
 * @param list<array<string, mixed>> $rules
 *
 * @return array<string, array<string, mixed>>
 */
function fn_ap_safecache_cf_map_rules_by_id(array $rules)
{
    $map = [];
    $n = 0;

    foreach ($rules as $r) {
        if (!is_array($r)) {
            continue;
        }
        $id = isset($r['id']) ? (string) $r['id'] : '__new_' . (string) $n;
        $map[$id] = $r;
        $n++;
    }

    return $map;
}

/**
 * @param array<string, mixed> $baseline
 * @param array<string, mixed> $edited
 *
 * @return array{summary: string, equal: bool}
 */
function fn_ap_safecache_cf_diff_cache_ruleset(array $baseline, array $edited)
{
    $b_rules = isset($baseline['rules']) && is_array($baseline['rules']) ? $baseline['rules'] : [];
    $e_rules = isset($edited['rules']) && is_array($edited['rules']) ? $edited['rules'] : [];

    $bm = fn_ap_safecache_cf_map_rules_by_id($b_rules);
    $em = fn_ap_safecache_cf_map_rules_by_id($e_rules);

    $lines = [];
    $all_ids = array_unique(array_merge(array_keys($bm), array_keys($em)));
    sort($all_ids);

    $changed = 0;
    foreach ($all_ids as $id) {
        $has_b = isset($bm[$id]);
        $has_e = isset($em[$id]);
        if ($has_b && !$has_e) {
            $lines[] = '- ' . __('ap_safecache.cf_diff_rule_removed', ['[id]' => $id]);
            $changed++;
        } elseif (!$has_b && $has_e) {
            $lines[] = '+ ' . __('ap_safecache.cf_diff_rule_added', ['[id]' => $id]);
            $changed++;
        } else {
            $js_b = fn_ap_safecache_cf_json_stable($bm[$id]);
            $js_e = fn_ap_safecache_cf_json_stable($em[$id]);
            if ($js_b !== $js_e) {
                $lines[] = '~ ' . __('ap_safecache.cf_diff_rule_changed', ['[id]' => $id]);
                $changed++;
            }
        }
    }

    $meta_b = $baseline;
    $meta_e = $edited;
    unset($meta_b['rules'], $meta_e['rules']);
    if (fn_ap_safecache_cf_json_stable($meta_b) !== fn_ap_safecache_cf_json_stable($meta_e)) {
        $lines[] = '~ ' . __('ap_safecache.cf_diff_ruleset_meta_changed');
        $changed++;
    }

    $summary = $changed === 0
        ? __('ap_safecache.cf_diff_no_changes')
        : implode("\n", $lines);

    return ['summary' => $summary, 'equal' => $changed === 0];
}

/**
 * @param list<array<string, mixed>> $baseline
 * @param list<array<string, mixed>> $edited
 *
 * @return array{summary: string, equal: bool}
 */
function fn_ap_safecache_cf_diff_page_rules(array $baseline, array $edited)
{
    $bm = [];
    foreach ($baseline as $r) {
        if (is_array($r) && isset($r['id'])) {
            $bm[(string) $r['id']] = $r;
        }
    }
    $em = [];
    foreach ($edited as $r) {
        if (is_array($r) && isset($r['id'])) {
            $em[(string) $r['id']] = $r;
        }
    }

    $lines = [];
    $ids = array_unique(array_merge(array_keys($bm), array_keys($em)));
    sort($ids);

    $changed = 0;
    foreach ($ids as $id) {
        $has_b = isset($bm[$id]);
        $has_e = isset($em[$id]);
        if ($has_b && !$has_e) {
            $lines[] = '- ' . __('ap_safecache.cf_diff_page_removed', ['[id]' => $id]);
            $changed++;
        } elseif (!$has_b && $has_e) {
            $lines[] = '+ ' . __('ap_safecache.cf_diff_page_added', ['[id]' => $id]);
            $changed++;
        } else {
            if (fn_ap_safecache_cf_json_stable($bm[$id]) !== fn_ap_safecache_cf_json_stable($em[$id])) {
                $lines[] = '~ ' . __('ap_safecache.cf_diff_page_changed', ['[id]' => $id]);
                $changed++;
            }
        }
    }

    $summary = $changed === 0
        ? __('ap_safecache.cf_diff_no_changes')
        : implode("\n", $lines);

    return ['summary' => $summary, 'equal' => $changed === 0];
}

/**
 * 編集 JSON をパースし baseline と比較。結果をセッションに格納（リダイレクト後に表示）。
 *
 * @return bool
 */
function fn_ap_safecache_cf_run_diff_from_post()
{
    $bucket = fn_ap_safecache_cf_session_get_bucket();
    if (empty($bucket['fetched_at'])) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_fetch_first'));

        return false;
    }

    $raw_page = isset($_REQUEST['ap_safecache_cf_page_rules_json']) ? (string) $_REQUEST['ap_safecache_cf_page_rules_json'] : '';
    $raw_cache = isset($_REQUEST['ap_safecache_cf_cache_ruleset_json']) ? (string) $_REQUEST['ap_safecache_cf_cache_ruleset_json'] : '';

    $page_edited = json_decode($raw_page, true);
    if (!is_array($page_edited)) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_json_page'));

        return false;
    }

    $cache_edited = json_decode($raw_cache, true);
    if (!is_array($cache_edited)) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_json_cache'));

        return false;
    }

    // 差分は「最後に取得したスナップショット」と編集欄の比較。先頭挿入等で cache_ruleset だけ更新しても差分が出るよう、
    // fetch 時点のコピーを cache_ruleset_diff_baseline に保持する（append ではここは書き換えない）。
    $base_page = [];
    if (!empty($bucket['page_rules_diff_baseline']) && is_array($bucket['page_rules_diff_baseline'])) {
        $base_page = $bucket['page_rules_diff_baseline'];
    } elseif (isset($bucket['page_rules']) && is_array($bucket['page_rules'])) {
        $base_page = $bucket['page_rules'];
    }

    $base_cache = [];
    if (!empty($bucket['cache_ruleset_diff_baseline']) && is_array($bucket['cache_ruleset_diff_baseline'])) {
        $base_cache = $bucket['cache_ruleset_diff_baseline'];
    } elseif (isset($bucket['cache_ruleset']) && is_array($bucket['cache_ruleset'])) {
        $base_cache = $bucket['cache_ruleset'];
    }

    $d_page = fn_ap_safecache_cf_diff_page_rules($base_page, $page_edited);
    $d_cache = fn_ap_safecache_cf_diff_cache_ruleset($base_cache, $cache_edited);

    Tygh::$app['session']['ap_safecache_cf_diff_flash'] = [
        'page_summary'  => $d_page['summary'],
        'cache_summary' => $d_cache['summary'],
        'page_equal'    => $d_page['equal'],
        'cache_equal'   => $d_cache['equal'],
    ];

    fn_set_notification('N', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_ok_diff'));

    return true;
}

/**
 * @param list<array<string, mixed>> $baseline 現在 Cloudflare 上の Page Rules
 * @param list<array<string, mixed>> $edited_list 目標の Page Rules 配列
 *
 * @return bool
 */
function fn_ap_safecache_cf_apply_page_rules_sync($zone_id, array $baseline, array $edited_list)
{
    $zone_id = (string) $zone_id;

    $bm = [];
    foreach ($baseline as $r) {
        if (is_array($r) && isset($r['id'])) {
            $bm[(string) $r['id']] = $r;
        }
    }

    $em = [];
    $new_rules = [];
    foreach ($edited_list as $r) {
        if (!is_array($r)) {
            continue;
        }
        if (isset($r['id']) && $r['id'] !== '') {
            $em[(string) $r['id']] = $r;
        } else {
            $new_rules[] = $r;
        }
    }

    foreach ($bm as $id => $_r) {
        if (!isset($em[$id])) {
            list($ok_d, $_d, $err) = fn_ap_safecache_cf_api('DELETE', 'zones/' . rawurlencode($zone_id) . '/pagerules/' . rawurlencode($id));
            if (!$ok_d) {
                fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_page_delete', ['[id]' => $id]) . ' ' . $err);

                return false;
            }
        }
    }

    foreach ($em as $id => $rule) {
        $body = $rule;
        unset($body['id']);
        list($ok_u, $_u, $err) = fn_ap_safecache_cf_api(
            'PUT',
            'zones/' . rawurlencode($zone_id) . '/pagerules/' . rawurlencode($id),
            $body
        );
        if (!$ok_u) {
            fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_page_update', ['[id]' => $id]) . ' ' . $err);

            return false;
        }
    }

    foreach ($new_rules as $rule) {
        list($ok_c, $_c, $err) = fn_ap_safecache_cf_api('POST', 'zones/' . rawurlencode($zone_id) . '/pagerules', $rule);
        if (!$ok_c) {
            fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_page_create') . ' ' . $err);

            return false;
        }
    }

    return true;
}

/**
 * Cache Rules（http_request_cache_settings）PUT 用に、API が返したルールから読み取り専用フィールドを除く。
 *
 * @param list<array<string, mixed>> $rules
 *
 * @return list<array<string, mixed>>
 */
function fn_ap_safecache_cf_sanitize_cache_rules_for_put(array $rules)
{
    $out = [];
    $strip = ['last_updated', 'version', 'ref'];

    foreach ($rules as $r) {
        if (!is_array($r)) {
            continue;
        }
        foreach ($strip as $k) {
            unset($r[$k]);
        }
        // 旧ダッシュボード表記の bypass_cache は Rulesets API では無効。set_cache_settings + cache:false に正規化。
        if (isset($r['action']) && (string) $r['action'] === 'bypass_cache') {
            $r['action'] = 'set_cache_settings';
            $r['action_parameters'] = ['cache' => false];
        }
        $out[] = $r;
    }

    return $out;
}

/**
 * Cache Rules をエントリポイント URL に PUT（rules 全体を置換）。GET と同じ phase の URL で更新する。
 *
 * @param list<array<string, mixed>> $rules
 *
 * @return array{0: bool, 1: array<string, mixed>|null} [ok, api result.result or null]
 */
function fn_ap_safecache_cf_apply_cache_rules_put($zone_id, array $rules)
{
    $path = 'zones/' . rawurlencode((string) $zone_id) . '/rulesets/phases/http_request_cache_settings/entrypoint';
    $rules = fn_ap_safecache_cf_sanitize_cache_rules_for_put($rules);
    list($ok_put, $data, $err) = fn_ap_safecache_cf_api('PUT', $path, ['rules' => $rules]);

    if (!$ok_put) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_apply_cache') . ' ' . $err);

        return [false, null];
    }

    $result = null;
    if (is_array($data) && isset($data['result']) && is_array($data['result'])) {
        $result = $data['result'];
    }

    return [true, $result];
}

/**
 * Cache Rules を PUT（rules 全体を置換）。WAF 以外の http_request_cache_settings のみ。
 *
 * @return bool
 */
function fn_ap_safecache_cf_apply_cache_rules_from_post()
{
    if (!fn_ap_safecache_is_pro()) {
        fn_set_notification('E', __('ap_safecache.notification_title_license'), __('ap_safecache.license_pro_only'));

        return false;
    }

    if (fn_ap_safecache_license_action_token_abort_pro_write()) {
        return false;
    }

    list($ok, $_token, $zone_id) = fn_ap_safecache_cf_get_credentials();
    if (!$ok) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_credentials'));

        return false;
    }

    $bucket = fn_ap_safecache_cf_session_get_bucket();
    if (empty($bucket['fetched_at'])) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_fetch_first'));

        return false;
    }

    $raw = isset($_REQUEST['ap_safecache_cf_cache_ruleset_json']) ? (string) $_REQUEST['ap_safecache_cf_cache_ruleset_json'] : '';
    $edited = json_decode($raw, true);
    if (!is_array($edited)) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_json_cache'));

        return false;
    }

    $rules = isset($edited['rules']) && is_array($edited['rules']) ? $edited['rules'] : null;
    if ($rules === null) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_cache_need_rules'));

        return false;
    }

    list($ok_put, $api_result) = fn_ap_safecache_cf_apply_cache_rules_put($zone_id, $rules);
    if (!$ok_put) {
        return false;
    }

    $meta = '';
    if (is_array($api_result)) {
        $ver = isset($api_result['version']) ? (string) $api_result['version'] : '';
        $n = isset($api_result['rules']) && is_array($api_result['rules']) ? count($api_result['rules']) : count($rules);
        if ($ver !== '') {
            $meta = ' ' . __('ap_safecache.cf_ok_apply_cache_meta', ['[version]' => $ver, '[n]' => (string) $n]);
        }
    }

    fn_set_notification('N', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_ok_apply_cache') . $meta);
    fn_ap_safecache_cf_fetch_rules_to_session();

    return true;
}

/**
 * Page Rules: 追加・更新・削除を同期。
 *
 * @return bool
 */
function fn_ap_safecache_cf_apply_page_rules_from_post()
{
    if (!fn_ap_safecache_is_pro()) {
        fn_set_notification('E', __('ap_safecache.notification_title_license'), __('ap_safecache.license_pro_only'));

        return false;
    }

    list($ok, $_token, $zone_id) = fn_ap_safecache_cf_get_credentials();
    if (!$ok) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_credentials'));

        return false;
    }

    $bucket = fn_ap_safecache_cf_session_get_bucket();
    $baseline = isset($bucket['page_rules']) && is_array($bucket['page_rules']) ? $bucket['page_rules'] : [];

    $raw = isset($_REQUEST['ap_safecache_cf_page_rules_json']) ? (string) $_REQUEST['ap_safecache_cf_page_rules_json'] : '';
    $edited_list = json_decode($raw, true);
    if (!is_array($edited_list)) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_json_page'));

        return false;
    }

    if (!fn_ap_safecache_cf_apply_page_rules_sync($zone_id, $baseline, $edited_list)) {
        return false;
    }

    fn_set_notification('N', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_ok_apply_page'));
    fn_ap_safecache_cf_fetch_rules_to_session();

    return true;
}

/**
 * 指定ゾーンの古いバックアップを削除し最大世代数を維持する（テーブルごと）。
 *
 * @param 'page'|'cache' $kind
 */
function fn_ap_safecache_cf_backup_prune($zone_id, $kind)
{
    $zone_id = (string) $zone_id;
    $max = (int) AP_SAFECACHE_CF_BACKUP_MAX_GENERATIONS;
    if ($max < 1) {
        $max = 1;
    }

    if ($kind === 'cache') {
        $all_ids = db_get_fields(
            'SELECT backup_id FROM ?:ap_safecache_cf_cache_backups WHERE zone_id = ?s ORDER BY backup_id DESC',
            $zone_id
        );
    } else {
        $all_ids = db_get_fields(
            'SELECT backup_id FROM ?:ap_safecache_cf_page_backups WHERE zone_id = ?s ORDER BY backup_id DESC',
            $zone_id
        );
    }

    if (empty($all_ids) || count($all_ids) <= $max) {
        return;
    }

    $to_delete = array_slice(array_map('intval', $all_ids), $max);
    if ($to_delete === []) {
        return;
    }

    if ($kind === 'cache') {
        db_query('DELETE FROM ?:ap_safecache_cf_cache_backups WHERE backup_id IN (?n)', $to_delete);
    } else {
        db_query('DELETE FROM ?:ap_safecache_cf_page_backups WHERE backup_id IN (?n)', $to_delete);
    }
}

/**
 * Cloudflare 上の Page Rules のみ API で取得し DB にバックアップする。
 *
 * @return array{0: bool, 1: string}
 */
function fn_ap_safecache_cf_backup_create_page_now(array $opts = [])
{
    fn_ap_safecache_cf_ensure_backup_table();

    if (!fn_ap_safecache_is_pro()) {
        return [false, __('ap_safecache.license_pro_only')];
    }

    $skip_lat = !empty($opts['skip_license_action_token']);
    if (!$skip_lat) {
        list($lat_ok, $lat_msg) = fn_ap_safecache_license_action_token_ensure_for_pro_write();
        if (!$lat_ok) {
            return [false, $lat_msg];
        }
    }

    list($ok, $_t, $zone_id) = fn_ap_safecache_cf_get_credentials();
    if (!$ok) {
        return [false, __('ap_safecache.cf_err_credentials')];
    }

    list($ok_live, $page_rules, $err) = fn_ap_safecache_cf_fetch_live_page_rules_only();
    if (!$ok_live) {
        return [false, $err];
    }

    $next_gen = (int) db_get_field(
        'SELECT COALESCE(MAX(generation), 0) + 1 FROM ?:ap_safecache_cf_page_backups WHERE zone_id = ?s',
        $zone_id
    );

    $user_id = 0;
    if (!empty(Tygh::$app['session']['auth']['user_id'])) {
        $user_id = (int) Tygh::$app['session']['auth']['user_id'];
    }

    $payload = json_encode($page_rules, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    db_query(
        'INSERT INTO ?:ap_safecache_cf_page_backups ?e',
        [
            'zone_id'    => $zone_id,
            'generation' => $next_gen,
            'created_at' => time(),
            'user_id'    => $user_id,
            'payload'    => $payload !== false ? $payload : '[]',
        ]
    );

    fn_ap_safecache_cf_backup_prune($zone_id, 'page');

    return [true, __('ap_safecache.cf_ok_backup_created_page', ['[gen]' => (string) $next_gen])];
}

/**
 * Cloudflare 上の Cache Rules（entrypoint）のみ API で取得し DB にバックアップする。
 *
 * @return array{0: bool, 1: string}
 */
function fn_ap_safecache_cf_backup_create_cache_now(array $opts = [])
{
    fn_ap_safecache_cf_ensure_backup_table();

    if (!fn_ap_safecache_is_pro()) {
        return [false, __('ap_safecache.license_pro_only')];
    }

    $skip_lat = !empty($opts['skip_license_action_token']);
    if (!$skip_lat) {
        list($lat_ok, $lat_msg) = fn_ap_safecache_license_action_token_ensure_for_pro_write();
        if (!$lat_ok) {
            return [false, $lat_msg];
        }
    }

    list($ok, $_t, $zone_id) = fn_ap_safecache_cf_get_credentials();
    if (!$ok) {
        return [false, __('ap_safecache.cf_err_credentials')];
    }

    list($ok_live, $cache_ruleset, $err) = fn_ap_safecache_cf_fetch_live_cache_ruleset_only();
    if (!$ok_live) {
        return [false, $err];
    }

    $next_gen = (int) db_get_field(
        'SELECT COALESCE(MAX(generation), 0) + 1 FROM ?:ap_safecache_cf_cache_backups WHERE zone_id = ?s',
        $zone_id
    );

    $user_id = 0;
    if (!empty(Tygh::$app['session']['auth']['user_id'])) {
        $user_id = (int) Tygh::$app['session']['auth']['user_id'];
    }

    $payload = json_encode($cache_ruleset, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    db_query(
        'INSERT INTO ?:ap_safecache_cf_cache_backups ?e',
        [
            'zone_id'    => $zone_id,
            'generation' => $next_gen,
            'created_at' => time(),
            'user_id'    => $user_id,
            'payload'    => $payload !== false ? $payload : '{}',
        ]
    );

    fn_ap_safecache_cf_backup_prune($zone_id, 'cache');

    return [true, __('ap_safecache.cf_ok_backup_created_cache', ['[gen]' => (string) $next_gen])];
}

/**
 * @return list<array<string, int|string>>
 */
function fn_ap_safecache_cf_backup_list_page_for_current_zone()
{
    fn_ap_safecache_cf_ensure_backup_table();

    list($ok, $_t, $zone_id) = fn_ap_safecache_cf_get_credentials();
    if (!$ok) {
        return [];
    }

    return db_get_array(
        'SELECT backup_id, zone_id, generation, created_at, user_id FROM ?:ap_safecache_cf_page_backups WHERE zone_id = ?s ORDER BY backup_id DESC',
        $zone_id
    );
}

/**
 * @return list<array<string, int|string>>
 */
function fn_ap_safecache_cf_backup_list_cache_for_current_zone()
{
    fn_ap_safecache_cf_ensure_backup_table();

    list($ok, $_t, $zone_id) = fn_ap_safecache_cf_get_credentials();
    if (!$ok) {
        return [];
    }

    return db_get_array(
        'SELECT backup_id, zone_id, generation, created_at, user_id FROM ?:ap_safecache_cf_cache_backups WHERE zone_id = ?s ORDER BY backup_id DESC',
        $zone_id
    );
}

/**
 * @return array<string, mixed>|null
 */
function fn_ap_safecache_cf_backup_get_page_row($backup_id)
{
    fn_ap_safecache_cf_ensure_backup_table();

    $backup_id = (int) $backup_id;
    if ($backup_id <= 0) {
        return null;
    }

    $row = db_get_row('SELECT * FROM ?:ap_safecache_cf_page_backups WHERE backup_id = ?i', $backup_id);

    return is_array($row) ? $row : null;
}

/**
 * @return array<string, mixed>|null
 */
function fn_ap_safecache_cf_backup_get_cache_row($backup_id)
{
    fn_ap_safecache_cf_ensure_backup_table();

    $backup_id = (int) $backup_id;
    if ($backup_id <= 0) {
        return null;
    }

    $row = db_get_row('SELECT * FROM ?:ap_safecache_cf_cache_backups WHERE backup_id = ?i', $backup_id);

    return is_array($row) ? $row : null;
}

/**
 * 指定の Page Rules バックアップ行を削除（現在のゾーンに属する行のみ）。
 *
 * @return bool
 */
function fn_ap_safecache_cf_backup_delete_page($backup_id)
{
    fn_ap_safecache_cf_ensure_backup_table();

    if (!fn_ap_safecache_is_pro()) {
        fn_set_notification('E', __('ap_safecache.notification_title_license'), __('ap_safecache.license_pro_only'));

        return false;
    }

    if (fn_ap_safecache_license_action_token_abort_pro_write()) {
        return false;
    }

    $backup_id = (int) $backup_id;
    if ($backup_id <= 0) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_backup_not_found'));

        return false;
    }

    list($ok, $_t, $zone_id) = fn_ap_safecache_cf_get_credentials();
    if (!$ok) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_credentials'));

        return false;
    }

    $row = fn_ap_safecache_cf_backup_get_page_row($backup_id);
    if ($row === null || (string) $row['zone_id'] !== (string) $zone_id) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_backup_not_found'));

        return false;
    }

    $gen = (string) $row['generation'];
    db_query('DELETE FROM ?:ap_safecache_cf_page_backups WHERE backup_id = ?i AND zone_id = ?s', $backup_id, $zone_id);

    fn_set_notification(
        'N',
        __('ap_safecache.cf_notification_title'),
        __('ap_safecache.cf_ok_backup_deleted_page', ['[gen]' => $gen])
    );

    return true;
}

/**
 * 指定の Cache Rules バックアップ行を削除（現在のゾーンに属する行のみ）。
 *
 * @return bool
 */
function fn_ap_safecache_cf_backup_delete_cache($backup_id)
{
    fn_ap_safecache_cf_ensure_backup_table();

    if (!fn_ap_safecache_is_pro()) {
        fn_set_notification('E', __('ap_safecache.notification_title_license'), __('ap_safecache.license_pro_only'));

        return false;
    }

    if (fn_ap_safecache_license_action_token_abort_pro_write()) {
        return false;
    }

    $backup_id = (int) $backup_id;
    if ($backup_id <= 0) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_backup_not_found'));

        return false;
    }

    list($ok, $_t, $zone_id) = fn_ap_safecache_cf_get_credentials();
    if (!$ok) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_credentials'));

        return false;
    }

    $row = fn_ap_safecache_cf_backup_get_cache_row($backup_id);
    if ($row === null || (string) $row['zone_id'] !== (string) $zone_id) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_backup_not_found'));

        return false;
    }

    $gen = (string) $row['generation'];
    db_query('DELETE FROM ?:ap_safecache_cf_cache_backups WHERE backup_id = ?i AND zone_id = ?s', $backup_id, $zone_id);

    fn_set_notification(
        'N',
        __('ap_safecache.cf_notification_title'),
        __('ap_safecache.cf_ok_backup_deleted_cache', ['[gen]' => $gen])
    );

    return true;
}

/**
 * Page Rules のみバックアップ時点へロールバック。
 *
 * @return bool
 */
function fn_ap_safecache_cf_rollback_page($backup_id)
{
    fn_ap_safecache_cf_ensure_backup_table();

    if (!fn_ap_safecache_is_pro()) {
        fn_set_notification('E', __('ap_safecache.notification_title_license'), __('ap_safecache.license_pro_only'));

        return false;
    }

    if (fn_ap_safecache_license_action_token_abort_pro_write()) {
        return false;
    }

    $backup_id = (int) $backup_id;
    if ($backup_id <= 0) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_backup_not_found'));

        return false;
    }

    list($ok, $_t, $zone_id) = fn_ap_safecache_cf_get_credentials();
    if (!$ok) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_credentials'));

        return false;
    }

    $row = fn_ap_safecache_cf_backup_get_page_row($backup_id);
    if ($row === null || (string) $row['zone_id'] !== (string) $zone_id) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_backup_not_found'));

        return false;
    }

    $target_page = json_decode((string) $row['payload'], true);
    if (!is_array($target_page)) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_backup_corrupt'));

        return false;
    }

    list($ok_live, $live_page, $err) = fn_ap_safecache_cf_fetch_live_page_rules_only();
    if (!$ok_live) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), $err);

        return false;
    }

    if (!fn_ap_safecache_cf_apply_page_rules_sync($zone_id, $live_page, $target_page)) {
        return false;
    }

    fn_set_notification(
        'N',
        __('ap_safecache.cf_notification_title'),
        __('ap_safecache.cf_ok_rollback_page', ['[gen]' => (string) $row['generation']])
    );
    fn_ap_safecache_cf_fetch_rules_to_session();

    return true;
}

/**
 * Cache Rules のみバックアップ時点へロールバック。
 *
 * @return bool
 */
function fn_ap_safecache_cf_rollback_cache($backup_id)
{
    fn_ap_safecache_cf_ensure_backup_table();

    if (!fn_ap_safecache_is_pro()) {
        fn_set_notification('E', __('ap_safecache.notification_title_license'), __('ap_safecache.license_pro_only'));

        return false;
    }

    if (fn_ap_safecache_license_action_token_abort_pro_write()) {
        return false;
    }

    $backup_id = (int) $backup_id;
    if ($backup_id <= 0) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_backup_not_found'));

        return false;
    }

    list($ok, $_t, $zone_id) = fn_ap_safecache_cf_get_credentials();
    if (!$ok) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_credentials'));

        return false;
    }

    $row = fn_ap_safecache_cf_backup_get_cache_row($backup_id);
    if ($row === null || (string) $row['zone_id'] !== (string) $zone_id) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_backup_not_found'));

        return false;
    }

    $target_cache = json_decode((string) $row['payload'], true);
    if (!is_array($target_cache)) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_backup_corrupt'));

        return false;
    }

    $target_rules = isset($target_cache['rules']) && is_array($target_cache['rules']) ? $target_cache['rules'] : null;
    if ($target_rules === null) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), __('ap_safecache.cf_err_cache_need_rules'));

        return false;
    }

    list($ok_live, $live_cache, $err) = fn_ap_safecache_cf_fetch_live_cache_ruleset_only();
    if (!$ok_live) {
        fn_set_notification('E', __('ap_safecache.cf_notification_title'), $err);

        return false;
    }

    list($ok_put, $api_result) = fn_ap_safecache_cf_apply_cache_rules_put($zone_id, $target_rules);
    if (!$ok_put) {
        return false;
    }

    $meta = '';
    if (is_array($api_result)) {
        $ver = isset($api_result['version']) ? (string) $api_result['version'] : '';
        $n = isset($api_result['rules']) && is_array($api_result['rules']) ? count($api_result['rules']) : count($target_rules);
        if ($ver !== '') {
            $meta = ' ' . __('ap_safecache.cf_ok_apply_cache_meta', ['[version]' => $ver, '[n]' => (string) $n]);
        }
    }

    fn_set_notification(
        'N',
        __('ap_safecache.cf_notification_title'),
        __('ap_safecache.cf_ok_rollback_cache', ['[gen]' => (string) $row['generation']]) . $meta
    );
    fn_ap_safecache_cf_fetch_rules_to_session();

    return true;
}

/**
 * 管理画面用: セッションから JSON テキストとメタを返す。
 *
 * @return array<string, mixed>
 */
function fn_ap_safecache_cf_get_manage_assignments()
{
    fn_ap_safecache_cf_ensure_backup_table();
    fn_ap_safecache_cf_ensure_poll_tables();

    $poll_state = null;
    $poll_display = fn_ap_safecache_cf_get_poll_state_display_for_manage(null);
    $poll_log_recent = [];
    list($ok_poll_cred, $_pt, $poll_zone_id) = fn_ap_safecache_cf_get_credentials();
    if ($ok_poll_cred && $poll_zone_id !== '') {
        $poll_state = fn_ap_safecache_cf_get_poll_state_for_zone($poll_zone_id);
        $poll_display = fn_ap_safecache_cf_get_poll_state_display_for_manage($poll_state);
        $poll_log_limit = fn_ap_safecache_is_pro() ? 12 : 5;
        $poll_log_recent = fn_ap_safecache_cf_enrich_poll_log_for_manage_ui(
            fn_ap_safecache_cf_get_poll_log_recent($poll_zone_id, $poll_log_limit)
        );
    }

    $bucket = fn_ap_safecache_cf_session_get_bucket();
    $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
    if (defined('JSON_PRETTY_PRINT')) {
        $flags |= JSON_PRETTY_PRINT;
    }

    $page_rules = isset($bucket['page_rules']) && is_array($bucket['page_rules']) ? $bucket['page_rules'] : [];
    $cache_rs = isset($bucket['cache_ruleset']) && is_array($bucket['cache_ruleset']) ? $bucket['cache_ruleset'] : [];

    $cache_json = $cache_rs === []
        ? '{}'
        : (string) json_encode($cache_rs, $flags);

    $flash = !empty(Tygh::$app['session']['ap_safecache_cf_diff_flash'])
        ? Tygh::$app['session']['ap_safecache_cf_diff_flash']
        : null;
    if ($flash !== null) {
        unset(Tygh::$app['session']['ap_safecache_cf_diff_flash']);
    }

    $addon_cf = Registry::get('addons.ap_safecache');
    $addon_cf = is_array($addon_cf) ? $addon_cf : [];
    $cron_en = fn_ap_safecache_setting_value_is_yes($addon_cf['cf_poll_cron_enable'] ?? 'N');
    $cron_pw = isset($addon_cf['cf_poll_cron_password']) ? trim((string) $addon_cf['cf_poll_cron_password']) : '';
    $cron_url = fn_url('ap_safecache.cron_cf_poll', 'A', 'current');
    $pe_flush_cron_url = fn_url('ap_safecache.cron_pe_flush', 'A', 'current');
    $purge_queue_cron_url = fn_url('ap_safecache.cron_purge_queue', 'A', 'current');
    $purge_queue_cron_ready = function_exists('fn_ap_safecache_purge_queue_is_enabled')
        && fn_ap_safecache_purge_queue_is_enabled()
        && $cron_en
        && $cron_pw !== '';

    $purge_queue_recent = function_exists('fn_ap_safecache_purge_queue_get_recent_jobs_for_manage')
        ? fn_ap_safecache_purge_queue_get_recent_jobs_for_manage(12)
        : [];

    return [
        'ap_safecache_cf_page_rules_json'           => (string) json_encode($page_rules, $flags),
        'ap_safecache_cf_cache_ruleset_json'        => $cache_json,
        'ap_safecache_cf_fetched_at'                => !empty($bucket['fetched_at']) ? (int) $bucket['fetched_at'] : 0,
        'ap_safecache_cf_diff_flash'                => is_array($flash) ? $flash : null,
        'ap_safecache_cf_backups_page'              => fn_ap_safecache_cf_backup_list_page_for_current_zone(),
        'ap_safecache_cf_backups_cache'             => fn_ap_safecache_cf_backup_list_cache_for_current_zone(),
        'ap_safecache_cf_backup_max_generations'    => (int) AP_SAFECACHE_CF_BACKUP_MAX_GENERATIONS,
        'ap_safecache_cf_recommended'               => fn_ap_safecache_cf_get_recommended_cache_rules_payload(),
        'ap_safecache_cf_poll_state'                => $poll_state,
        'ap_safecache_cf_poll_display'              => $poll_display,
        'ap_safecache_cf_poll_log_recent'          => $poll_log_recent,
        'ap_safecache_cf_poll_cron_ready'          => $cron_en && $cron_pw !== '',
        'ap_safecache_cf_poll_cron_need_password'  => $cron_en && $cron_pw === '',
        'ap_safecache_cf_poll_cron_url'            => $cron_url,
        'ap_safecache_pe_flush_cron_url'          => $pe_flush_cron_url,
        'ap_safecache_purge_queue_cron_ready'     => $purge_queue_cron_ready,
        'ap_safecache_purge_queue_cron_url'       => $purge_queue_cron_url,
        'ap_safecache_purge_queue_recent'         => $purge_queue_recent,
    ];
}
