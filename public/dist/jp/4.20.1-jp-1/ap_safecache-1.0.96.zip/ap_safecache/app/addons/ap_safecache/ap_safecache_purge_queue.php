<?php

/**
 * Pro MV 向け Cloudflare パージキュー（タグ等）。Free / Pro SS（ULTIMATE 等）では無効。
 *
 * @see MEMO_保留事項.md §11 / §11.17
 */

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}

use Tygh\Http;
use Tygh\Registry;
use Tygh\Settings;

if (!defined('AP_SAFECACHE_PURGE_QUEUE_TAGS_PER_REQUEST')) {
    /** 1 回の purge_cache に載せるタグ数の上限（保守的） */
    define('AP_SAFECACHE_PURGE_QUEUE_TAGS_PER_REQUEST', 30);
}

if (!defined('AP_SAFECACHE_PURGE_QUEUE_CRON_MAX_CHUNKS')) {
    /** cron 1 回あたりに送る CF purge API の最大回数 */
    define('AP_SAFECACHE_PURGE_QUEUE_CRON_MAX_CHUNKS', 8);
}

if (!defined('AP_SAFECACHE_PURGE_QUEUE_MAX_ATTEMPTS')) {
    define('AP_SAFECACHE_PURGE_QUEUE_MAX_ATTEMPTS', 12);
}

if (!defined('AP_SAFECACHE_PURGE_QUEUE_PRUNE_DONE_AFTER_SEC')) {
    /** `done` を `updated_at` 基準で削除するまでの経過秒数。0 でこの種別は削除しない。 */
    define('AP_SAFECACHE_PURGE_QUEUE_PRUNE_DONE_AFTER_SEC', 14 * 86400);
}

if (!defined('AP_SAFECACHE_PURGE_QUEUE_PRUNE_FAILED_AFTER_SEC')) {
    /** `failed` を `updated_at` 基準で削除するまでの経過秒数。0 でこの種別は削除しない。 */
    define('AP_SAFECACHE_PURGE_QUEUE_PRUNE_FAILED_AFTER_SEC', 90 * 86400);
}

if (!defined('AP_SAFECACHE_PURGE_QUEUE_PRUNE_DELETE_LIMIT')) {
    /** 1 回の cron で各状態あたり削除する行数の上限 */
    define('AP_SAFECACHE_PURGE_QUEUE_PRUNE_DELETE_LIMIT', 500);
}

if (!defined('AP_SAFECACHE_PURGE_QUEUE_PRODUCT_CATEGORY_TAGS_MAX')) {
    /** 1 商品あたりキューに載せる `category-*` タグの最大数（メイン優先） */
    define('AP_SAFECACHE_PURGE_QUEUE_PRODUCT_CATEGORY_TAGS_MAX', 32);
}

if (!defined('AP_SAFECACHE_PURGE_QUEUE_IMPORT_CATEGORY_TAGS_MAX')) {
    /** インポート 1 バッチでまとめて取る `category-*` の DISTINCT 上限 */
    define('AP_SAFECACHE_PURGE_QUEUE_IMPORT_CATEGORY_TAGS_MAX', 64);
}

if (!defined('AP_SAFECACHE_PURGE_QUEUE_IMPORT_PRODUCT_IDS_FOR_CATS_MAX')) {
    /** インポート時にカテゴリ解決へ渡す product_id の最大件数 */
    define('AP_SAFECACHE_PURGE_QUEUE_IMPORT_PRODUCT_IDS_FOR_CATS_MAX', 500);
}

/**
 * キュー機能が有効か（**MULTIVENDOR かつ Pro**）。Free および ULTIMATE 上の Pro SS（pross 含む）は false。
 */
function fn_ap_safecache_purge_queue_is_enabled()
{
    if (!function_exists('fn_allowed_for') || !fn_allowed_for('MULTIVENDOR')) {
        return false;
    }

    return fn_ap_safecache_is_pro();
}

/**
 * @return int
 */
function fn_ap_safecache_purge_queue_runtime_company_id()
{
    if (function_exists('fn_get_runtime_company_id')) {
        return (int) fn_get_runtime_company_id();
    }

    return 0;
}

/**
 * 同一ベンダー内でタグを 1 行に畳むための dedupe キー（商品・カテゴリの随時更新用）。
 */
function fn_ap_safecache_purge_queue_dedupe_key_vendor_tags($company_id)
{
    return 'ap_sc_mv_q_vt_' . (int) $company_id;
}

/**
 * Exim `import_post`（商品）用: 同一ベンダーで連続インポート時にタグを 1 行へ畳む dedupe キー。
 */
function fn_ap_safecache_purge_queue_dedupe_key_vendor_import_tags($company_id)
{
    return 'ap_sc_mv_q_imp_' . (int) $company_id;
}

/**
 * `dedupe_key` 付きでタグをマージ enqueue（キュー無効時は何もしない）。
 *
 * @param list<string> $tags
 *
 * @return bool
 */
function fn_ap_safecache_purge_queue_merge_vendor_tags($company_id, array $tags, $source)
{
    $dk = fn_ap_safecache_purge_queue_dedupe_key_vendor_tags($company_id);

    return fn_ap_safecache_purge_queue_enqueue_tags($company_id, $tags, $source, $dk);
}

/**
 * 管理画面用: 直近ジョブ（メイン管理者 company_id=0 は全社、ベンダーは自社のみ）。
 *
 * @return list<array<string, int|string>>
 */
function fn_ap_safecache_purge_queue_get_recent_jobs_for_manage($limit = 10)
{
    if (!fn_ap_safecache_purge_queue_is_enabled()) {
        return [];
    }

    fn_ap_safecache_cf_purge_queue_ensure_table();

    $cid = fn_ap_safecache_purge_queue_runtime_company_id();
    $limit = max(1, min(40, (int) $limit));

    if ($cid > 0) {
        return db_get_array(
            'SELECT job_id, company_id, kind, status, batch_offset, attempts, next_run_at, source, dedupe_key,'
            . ' SUBSTRING(error_message, 1, 120) AS error_short, created_at, updated_at,'
            . ' CHAR_LENGTH(payload_json) AS payload_len'
            . ' FROM ?:ap_safecache_cf_purge_jobs WHERE company_id = ?i ORDER BY job_id DESC LIMIT ?i',
            $cid,
            $limit
        );
    }

    return db_get_array(
        'SELECT job_id, company_id, kind, status, batch_offset, attempts, next_run_at, source, dedupe_key,'
        . ' SUBSTRING(error_message, 1, 120) AS error_short, created_at, updated_at,'
        . ' CHAR_LENGTH(payload_json) AS payload_len'
        . ' FROM ?:ap_safecache_cf_purge_jobs ORDER BY job_id DESC LIMIT ?i',
        $limit
    );
}

/**
 * @return void
 */
function fn_ap_safecache_cf_purge_queue_ensure_table()
{
    db_query(
        'CREATE TABLE IF NOT EXISTS ?:ap_safecache_cf_purge_jobs ('
        . ' job_id int unsigned NOT NULL auto_increment,'
        . ' company_id int unsigned NOT NULL DEFAULT 0,'
        . ' kind varchar(32) NOT NULL DEFAULT \'tags\','
        . ' payload_json mediumtext NOT NULL,'
        . ' status varchar(16) NOT NULL DEFAULT \'pending\','
        . ' batch_offset int NOT NULL DEFAULT 0,'
        . ' attempts int unsigned NOT NULL DEFAULT 0,'
        . ' next_run_at int unsigned NOT NULL DEFAULT 0,'
        . ' priority int NOT NULL DEFAULT 0,'
        . ' source varchar(64) NOT NULL DEFAULT \'\','
        . ' dedupe_key varchar(191) DEFAULT NULL,'
        . ' error_message varchar(512) NOT NULL DEFAULT \'\','
        . ' created_at int unsigned NOT NULL DEFAULT 0,'
        . ' updated_at int unsigned NOT NULL DEFAULT 0,'
        . ' PRIMARY KEY (job_id),'
        . ' KEY ap_sc_pq_company_status_next (company_id, status, next_run_at),'
        . ' KEY ap_sc_pq_dedupe (dedupe_key)'
        . ') ENGINE=InnoDB DEFAULT CHARSET=utf8'
    );

    // MySQL 予約語 `cursor` は列名に使えない。開発途中で `cursor` 列のみ作成済みの環境向けにリネームする。
    $cols = db_get_array('SHOW COLUMNS FROM ?:ap_safecache_cf_purge_jobs');
    $has_cursor = false;
    $has_batch_offset = false;
    foreach ($cols as $c) {
        if (!isset($c['Field'])) {
            continue;
        }
        if ($c['Field'] === 'cursor') {
            $has_cursor = true;
        }
        if ($c['Field'] === 'batch_offset') {
            $has_batch_offset = true;
        }
    }
    if ($has_cursor && !$has_batch_offset) {
        db_query('ALTER TABLE ?:ap_safecache_cf_purge_jobs CHANGE COLUMN `cursor` batch_offset int NOT NULL DEFAULT 0');
    }
}

/**
 * 終端状態の古いジョブ行を削除（テーブル肥大防止）。`pending` / `running` は対象外。
 *
 * @param int|null $now Unix 時刻（省略時は現在）
 *
 * @return array{done: int, failed: int} 削除件数（各クエリの affected rows）
 */
function fn_ap_safecache_purge_queue_prune_old_jobs($now = null)
{
    if (!fn_ap_safecache_purge_queue_is_enabled()) {
        return ['done' => 0, 'failed' => 0];
    }

    fn_ap_safecache_cf_purge_queue_ensure_table();

    $now = $now !== null ? (int) $now : time();
    $lim = max(1, min(10000, (int) AP_SAFECACHE_PURGE_QUEUE_PRUNE_DELETE_LIMIT));

    $out = ['done' => 0, 'failed' => 0];

    $done_age = (int) AP_SAFECACHE_PURGE_QUEUE_PRUNE_DONE_AFTER_SEC;
    if ($done_age > 0) {
        $cut = $now - $done_age;
        $out['done'] = (int) db_query(
            'DELETE FROM ?:ap_safecache_cf_purge_jobs WHERE status = ?s AND updated_at < ?i LIMIT ?i',
            'done',
            $cut,
            $lim
        );
    }

    $failed_age = (int) AP_SAFECACHE_PURGE_QUEUE_PRUNE_FAILED_AFTER_SEC;
    if ($failed_age > 0) {
        $cut = $now - $failed_age;
        $out['failed'] = (int) db_query(
            'DELETE FROM ?:ap_safecache_cf_purge_jobs WHERE status = ?s AND updated_at < ?i LIMIT ?i',
            'failed',
            $cut,
            $lim
        );
    }

    return $out;
}

/**
 * @param array<int|string, mixed> $import_data
 *
 * @return list<int>
 */
function fn_ap_safecache_purge_queue_product_ids_from_import_data($import_data)
{
    if (!is_array($import_data)) {
        return [];
    }
    $seen = [];
    foreach ($import_data as $row) {
        if (!is_array($row)) {
            continue;
        }
        foreach ($row as $fields) {
            if (!is_array($fields)) {
                continue;
            }
            if (!isset($fields['product_id'])) {
                continue;
            }
            $pid = (int) $fields['product_id'];
            if ($pid > 0) {
                $seen[$pid] = true;
            }
        }
    }
    $ids = array_keys($seen);
    sort($ids);

    return $ids;
}

/**
 * @param array<int|string, mixed> $import_data
 *
 * @return list<string> Cache-Tag 名（product-{id}）
 */
function fn_ap_safecache_purge_queue_product_tags_from_import_data($import_data)
{
    $tags = [];
    foreach (fn_ap_safecache_purge_queue_product_ids_from_import_data($import_data) as $pid) {
        $tags[] = fn_ap_safecache_cf_purge_tag_product($pid);
    }

    return $tags;
}

/**
 * 1 商品に紐づくカテゴリから `category-*` タグ文字列一覧（件数上限・メイン `link_type=M` 優先）。
 *
 * @return list<string>
 */
function fn_ap_safecache_purge_queue_category_tags_for_product_id($product_id)
{
    $pid = (int) $product_id;
    if ($pid <= 0) {
        return [];
    }

    $max = max(1, min(128, (int) AP_SAFECACHE_PURGE_QUEUE_PRODUCT_CATEGORY_TAGS_MAX));
    $cids = db_get_fields(
        'SELECT category_id FROM ?:products_categories WHERE product_id = ?i'
        . ' ORDER BY (link_type = ?s) DESC, position ASC, category_id ASC LIMIT ?i',
        $pid,
        'M',
        $max
    );
    if (!is_array($cids) || $cids === []) {
        return [];
    }

    $out = [];
    foreach ($cids as $cid) {
        $cid = (int) $cid;
        if ($cid > 0) {
            $out[] = fn_ap_safecache_cf_purge_tag_category($cid);
        }
    }

    return $out;
}

/**
 * 複数商品にまたがる DISTINCT `category-*`（インポート用・件数上限）。
 *
 * @param list<int> $product_ids
 *
 * @return list<string>
 */
function fn_ap_safecache_purge_queue_distinct_category_tags_for_product_ids(array $product_ids)
{
    $ids = array_values(array_unique(array_filter(array_map('intval', $product_ids))));
    $lim_products = max(1, (int) AP_SAFECACHE_PURGE_QUEUE_IMPORT_PRODUCT_IDS_FOR_CATS_MAX);
    $ids = array_slice($ids, 0, $lim_products);
    if ($ids === []) {
        return [];
    }

    $max_cats = max(1, min(256, (int) AP_SAFECACHE_PURGE_QUEUE_IMPORT_CATEGORY_TAGS_MAX));
    $in = implode(',', $ids);
    $cids = db_get_fields(
        'SELECT DISTINCT category_id FROM ?:products_categories WHERE product_id IN (' . $in . ')'
        . ' AND category_id > 0 ORDER BY category_id ASC LIMIT ' . (int) $max_cats
    );
    if (!is_array($cids) || $cids === []) {
        return [];
    }

    $out = [];
    foreach ($cids as $cid) {
        $cid = (int) $cid;
        if ($cid > 0) {
            $out[] = fn_ap_safecache_cf_purge_tag_category($cid);
        }
    }

    return $out;
}

/**
 * @param list<string> $tags
 * @param string       $source
 * @param string|null  $dedupe_key
 *
 * @return bool 行を作成または更新したら true
 */
function fn_ap_safecache_purge_queue_enqueue_tags($company_id, array $tags, $source, $dedupe_key = null)
{
    if (!fn_ap_safecache_purge_queue_is_enabled()) {
        return false;
    }

    $tags = array_values(array_unique(array_filter(array_map('strval', $tags))));
    if ($tags === []) {
        return false;
    }

    fn_ap_safecache_cf_purge_queue_ensure_table();

    $company_id = (int) $company_id;
    $now = time();
    $source = substr(preg_replace('/[^a-z0-9_\\-]/i', '_', (string) $source), 0, 64);
    $dedupe_key = $dedupe_key !== null && $dedupe_key !== ''
        ? substr((string) $dedupe_key, 0, 191)
        : null;

    if ($dedupe_key !== null) {
        $row = db_get_row(
            'SELECT job_id, payload_json, batch_offset, status FROM ?:ap_safecache_cf_purge_jobs'
            . ' WHERE company_id = ?i AND dedupe_key = ?s AND status = ?s AND kind = ?s LIMIT 1',
            $company_id,
            $dedupe_key,
            'pending',
            'tags'
        );
        if (!empty($row['job_id'])) {
            $old = json_decode((string) $row['payload_json'], true);
            $merged = [];
            if (is_array($old) && isset($old['tags']) && is_array($old['tags'])) {
                $merged = $old['tags'];
            }
            $merged = array_values(array_unique(array_merge($merged, $tags)));
            sort($merged);
            db_query(
                'UPDATE ?:ap_safecache_cf_purge_jobs SET payload_json = ?s, batch_offset = 0, updated_at = ?i, next_run_at = ?i WHERE job_id = ?i',
                json_encode(['tags' => $merged], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $now,
                0,
                (int) $row['job_id']
            );

            return true;
        }
    }

    $payload = json_encode(['tags' => $tags], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    db_query(
        'INSERT INTO ?:ap_safecache_cf_purge_jobs ?e',
        [
            'company_id'    => $company_id,
            'kind'          => 'tags',
            'payload_json'  => (string) $payload,
            'status'        => 'pending',
            'batch_offset'  => 0,
            'attempts'      => 0,
            'next_run_at'   => 0,
            'priority'      => 0,
            'source'        => $source,
            'dedupe_key'    => $dedupe_key,
            'error_message' => '',
            'created_at'    => $now,
            'updated_at'    => $now,
        ]
    );

    return true;
}

/**
 * キュー用 URL 一覧の検証（`fn_ap_safecache_purge_cloudflare_cache_by_urls` と同条件）。
 *
 * @param list<string> $urls
 *
 * @return array{0: list<string>, 1: string} [有効 URL（重複除去済み）, 空で OK／非空なら最初のエラー用 __() キーに渡すメッセージ]
 */
function fn_ap_safecache_purge_queue_validate_urls_for_job(array $urls)
{
    $urls = array_values(array_unique(array_filter(array_map('strval', $urls))));
    if ($urls === []) {
        return [[], ''];
    }

    if (count($urls) > (int) AP_SAFECACHE_CF_PURGE_MAX_URLS_TOTAL) {
        return [[], __('ap_safecache.err_cf_purge_urls_too_many', ['[max]' => (string) AP_SAFECACHE_CF_PURGE_MAX_URLS_TOTAL])];
    }

    $out = [];
    foreach ($urls as $u) {
        if (!filter_var($u, FILTER_VALIDATE_URL)) {
            return [[], __('ap_safecache.err_cf_purge_url_invalid', ['[url]' => $u])];
        }
        $scheme = parse_url($u, PHP_URL_SCHEME);
        $scheme = is_string($scheme) ? strtolower($scheme) : '';
        if ($scheme !== 'http' && $scheme !== 'https') {
            return [[], __('ap_safecache.err_cf_purge_url_invalid', ['[url]' => $u])];
        }
        $out[] = $u;
    }

    return [$out, ''];
}

/**
 * `kind=urls` — Cloudflare `files` パージをキューに積む（consumer が `AP_SAFECACHE_CF_PURGE_MAX_FILES_PER_REQUEST` 件ずつ送信）。
 *
 * @param list<string> $urls
 * @param string       $source
 * @param string|null  $dedupe_key
 *
 * @return bool
 */
function fn_ap_safecache_purge_queue_enqueue_urls($company_id, array $urls, $source, $dedupe_key = null)
{
    if (!fn_ap_safecache_purge_queue_is_enabled()) {
        return false;
    }

    list($urls, $err) = fn_ap_safecache_purge_queue_validate_urls_for_job($urls);
    if ($err !== '') {
        return false;
    }
    if ($urls === []) {
        return false;
    }

    fn_ap_safecache_cf_purge_queue_ensure_table();

    $company_id = (int) $company_id;
    $now = time();
    $source = substr(preg_replace('/[^a-z0-9_\\-]/i', '_', (string) $source), 0, 64);
    $dedupe_key = $dedupe_key !== null && $dedupe_key !== ''
        ? substr((string) $dedupe_key, 0, 191)
        : null;

    if ($dedupe_key !== null) {
        $row = db_get_row(
            'SELECT job_id, payload_json, batch_offset, status FROM ?:ap_safecache_cf_purge_jobs'
            . ' WHERE company_id = ?i AND dedupe_key = ?s AND status = ?s AND kind = ?s LIMIT 1',
            $company_id,
            $dedupe_key,
            'pending',
            'urls'
        );
        if (!empty($row['job_id'])) {
            $old = json_decode((string) $row['payload_json'], true);
            $merged = [];
            if (is_array($old) && isset($old['urls']) && is_array($old['urls'])) {
                $merged = $old['urls'];
            }
            $merged = array_values(array_unique(array_merge($merged, $urls)));
            list($merged, $merge_err) = fn_ap_safecache_purge_queue_validate_urls_for_job($merged);
            if ($merge_err !== '' || $merged === []) {
                return false;
            }
            db_query(
                'UPDATE ?:ap_safecache_cf_purge_jobs SET payload_json = ?s, batch_offset = 0, updated_at = ?i, next_run_at = ?i WHERE job_id = ?i',
                json_encode(['urls' => $merged], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $now,
                0,
                (int) $row['job_id']
            );

            return true;
        }
    }

    $payload = json_encode(['urls' => $urls], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    db_query(
        'INSERT INTO ?:ap_safecache_cf_purge_jobs ?e',
        [
            'company_id'    => $company_id,
            'kind'          => 'urls',
            'payload_json'  => (string) $payload,
            'status'        => 'pending',
            'batch_offset'  => 0,
            'attempts'      => 0,
            'next_run_at'   => 0,
            'priority'      => 0,
            'source'        => $source,
            'dedupe_key'    => $dedupe_key,
            'error_message' => '',
            'created_at'    => $now,
            'updated_at'    => $now,
        ]
    );

    return true;
}

/**
 * @param array<string, mixed> $job
 * @param list<string>         $urls
 *
 * @return void
 */
function fn_ap_safecache_purge_queue_process_urls_job($job, array $urls)
{
    $job_id = (int) $job['job_id'];
    $offset = (int) (isset($job['batch_offset']) ? $job['batch_offset'] : 0);
    $company_id = (int) $job['company_id'];
    $per = defined('AP_SAFECACHE_CF_PURGE_MAX_FILES_PER_REQUEST')
        ? (int) AP_SAFECACHE_CF_PURGE_MAX_FILES_PER_REQUEST
        : 30;
    if ($per < 1) {
        $per = 30;
    }

    $slice = array_slice($urls, $offset, $per);
    if ($slice === []) {
        db_query(
            'UPDATE ?:ap_safecache_cf_purge_jobs SET status = ?s, updated_at = ?i, error_message = \'\' WHERE job_id = ?i',
            'done',
            time(),
            $job_id
        );

        return;
    }

    list($token, $zone_id) = fn_ap_safecache_purge_queue_resolve_token_zone($company_id);
    if ($token === '' || $zone_id === '') {
        fn_ap_safecache_purge_queue_mark_job_retry_or_fail($job, 503, __('ap_safecache.err_cf_zone_required_for_purge'));

        return;
    }

    list($ok, $err) = fn_ap_safecache_cloudflare_purge_post($token, $zone_id, ['files' => array_values($slice)]);
    $now = time();

    if ($ok) {
        $new_offset = $offset + count($slice);
        if ($new_offset >= count($urls)) {
            db_query(
                'UPDATE ?:ap_safecache_cf_purge_jobs SET status = ?s, batch_offset = ?i, error_message = \'\', updated_at = ?i WHERE job_id = ?i',
                'done',
                $new_offset,
                $now,
                $job_id
            );
        } else {
            db_query(
                'UPDATE ?:ap_safecache_cf_purge_jobs SET status = ?s, batch_offset = ?i, error_message = \'\', updated_at = ?i, attempts = 0, next_run_at = ?i WHERE job_id = ?i',
                'pending',
                $new_offset,
                $now,
                0,
                $job_id
            );
        }

        return;
    }

    $status = 500;
    if (class_exists(Http::class)) {
        $status = (int) Http::getStatus();
    }
    fn_ap_safecache_purge_queue_mark_job_retry_or_fail($job, $status, $err);
}

/**
 * @return array{0: string, 1: string} token, zone_id
 */
function fn_ap_safecache_purge_queue_resolve_token_zone($company_id)
{
    $company_id = (int) $company_id;
    $candidates = $company_id > 0 ? [$company_id, 0] : [0];

    foreach ($candidates as $cid) {
        if (!function_exists('fn_execute_as_company')) {
            break;
        }
        $pair = fn_execute_as_company(static function () {
            $t = Settings::instance()->getValue('cloudflare_api_token', 'ap_safecache', null, 0);
            $z = Settings::instance()->getValue('cloudflare_zone_id', 'ap_safecache', null, 0);

            return [is_string($t) ? trim($t) : '', is_string($z) ? trim($z) : ''];
        }, $cid);
        if ($pair[0] !== '' && $pair[1] !== '') {
            return $pair;
        }
    }

    $addon = Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];
    $t = isset($addon['cloudflare_api_token']) ? trim((string) $addon['cloudflare_api_token']) : '';
    $z = isset($addon['cloudflare_zone_id']) ? trim((string) $addon['cloudflare_zone_id']) : '';

    return [$t, $z];
}

/**
 * 直近の HTTP 応答ヘッダから数値 `Retry-After`（秒）のみ解釈（HTTP-date は未対応）。
 *
 * @return int|null
 */
function fn_ap_safecache_purge_queue_retry_after_seconds_hint()
{
    if (!class_exists(Http::class)) {
        return null;
    }
    $headers = Http::getHeaders();
    if (!is_string($headers) || $headers === '') {
        return null;
    }
    if (!preg_match('/^Retry-After:\s*(\d+)/mi', $headers, $m)) {
        return null;
    }

    return min(86400, max(1, (int) $m[1]));
}

/**
 * @param array<string, mixed> $job
 * @param int                  $http_status
 * @param string               $err
 *
 * @return void
 */
function fn_ap_safecache_purge_queue_mark_job_retry_or_fail($job, $http_status, $err)
{
    $job_id = (int) $job['job_id'];
    $attempts = (int) $job['attempts'] + 1;
    $now = time();
    $backoff = min(3600, (int) pow(2, min(10, $attempts)));
    if ($http_status === 429) {
        $ra = fn_ap_safecache_purge_queue_retry_after_seconds_hint();
        if ($ra !== null) {
            $backoff = max($backoff, $ra);
        } else {
            $backoff = max($backoff, 120);
        }
    }

    $msg = substr(trim($err), 0, 500);

    if ($attempts >= (int) AP_SAFECACHE_PURGE_QUEUE_MAX_ATTEMPTS) {
        db_query(
            'UPDATE ?:ap_safecache_cf_purge_jobs SET status = ?s, attempts = ?i, error_message = ?s, updated_at = ?i WHERE job_id = ?i',
            'failed',
            $attempts,
            $msg,
            $now,
            $job_id
        );

        return;
    }

    db_query(
        'UPDATE ?:ap_safecache_cf_purge_jobs SET status = ?s, attempts = ?i, next_run_at = ?i, error_message = ?s, updated_at = ?i WHERE job_id = ?i',
        'pending',
        $attempts,
        $now + $backoff,
        $msg,
        $now,
        $job_id
    );
}

/**
 * @param array<string, mixed> $job
 * @param list<string>         $tags
 *
 * @return void
 */
function fn_ap_safecache_purge_queue_process_tags_job($job, array $tags)
{
    $job_id = (int) $job['job_id'];
    $offset = (int) (isset($job['batch_offset']) ? $job['batch_offset'] : 0);
    $company_id = (int) $job['company_id'];
    $slice = array_slice($tags, $offset, (int) AP_SAFECACHE_PURGE_QUEUE_TAGS_PER_REQUEST);
    if ($slice === []) {
        db_query(
            'UPDATE ?:ap_safecache_cf_purge_jobs SET status = ?s, updated_at = ?i, error_message = \'\' WHERE job_id = ?i',
            'done',
            time(),
            $job_id
        );

        return;
    }

    list($token, $zone_id) = fn_ap_safecache_purge_queue_resolve_token_zone($company_id);
    if ($token === '' || $zone_id === '') {
        fn_ap_safecache_purge_queue_mark_job_retry_or_fail($job, 503, __('ap_safecache.err_cf_zone_required_for_purge'));

        return;
    }

    list($ok, $err) = fn_ap_safecache_cloudflare_purge_post($token, $zone_id, ['tags' => $slice]);
    $now = time();

    if ($ok) {
        $new_offset = $offset + count($slice);
        if ($new_offset >= count($tags)) {
            db_query(
                'UPDATE ?:ap_safecache_cf_purge_jobs SET status = ?s, batch_offset = ?i, error_message = \'\', updated_at = ?i WHERE job_id = ?i',
                'done',
                $new_offset,
                $now,
                $job_id
            );
        } else {
            db_query(
                'UPDATE ?:ap_safecache_cf_purge_jobs SET status = ?s, batch_offset = ?i, error_message = \'\', updated_at = ?i, attempts = 0, next_run_at = ?i WHERE job_id = ?i',
                'pending',
                $new_offset,
                $now,
                0,
                $job_id
            );
        }

        return;
    }

    $status = 500;
    if (class_exists(Http::class)) {
        $status = (int) Http::getStatus();
    }
    fn_ap_safecache_purge_queue_mark_job_retry_or_fail($job, $status, $err);
}

/**
 * GET dispatch=ap_safecache.cron_purge_queue（`cron_cf_poll` と同一の cron 認可）。
 *
 * @return void
 */
function fn_ap_safecache_purge_queue_cron_http_response()
{
    if (!defined('AREA') || AREA !== 'A') {
        http_response_code(403);
        header('Content-Type: text/plain; charset=UTF-8');
        echo 'ERROR: ' . __('access_denied');

        return;
    }

    header('Content-Type: text/plain; charset=UTF-8');

    $addon = Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];

    if (!fn_ap_safecache_setting_value_is_yes($addon['cf_poll_cron_enable'] ?? 'N')) {
        http_response_code(403);
        echo 'ERROR: ' . __('ap_safecache.cf_poll_cron_err_disabled');

        return;
    }

    if (!fn_ap_safecache_purge_queue_is_enabled()) {
        http_response_code(403);
        echo 'ERROR: ' . __('ap_safecache.purge_queue_cron_err_mv_pro_only');

        return;
    }

    $stored = isset($addon['cf_poll_cron_password']) ? trim((string) $addon['cf_poll_cron_password']) : '';
    if ($stored === '') {
        http_response_code(503);
        echo 'ERROR: ' . __('ap_safecache.cf_poll_cron_err_password_not_set');

        return;
    }

    $req = isset($_REQUEST['cron_password']) ? (string) $_REQUEST['cron_password'] : '';
    if (!hash_equals($stored, $req)) {
        http_response_code(403);
        echo 'ERROR: ' . __('access_denied');

        return;
    }

    fn_ap_safecache_cf_purge_queue_ensure_table();

    list($lat_ok, $lat_msg) = fn_ap_safecache_license_action_token_ensure_for_pro_write();
    if (!$lat_ok) {
        http_response_code(500);
        echo 'ERROR: ' . $lat_msg;

        return;
    }

    $lock_key = 'ap_sc_cf_purge_queue_cron';
    $locked = (int) db_get_field('SELECT GET_LOCK(?s, 10)', $lock_key) === 1;
    if (!$locked) {
        http_response_code(503);
        echo 'ERROR: ' . __('ap_safecache.purge_queue_cron_err_lock');

        return;
    }

    try {
        $now = time();
        db_query(
            'UPDATE ?:ap_safecache_cf_purge_jobs SET status = ?s, next_run_at = 0, updated_at = ?i WHERE status = ?s AND updated_at < ?i',
            'pending',
            $now,
            'running',
            $now - 900
        );

        $max = (int) AP_SAFECACHE_PURGE_QUEUE_CRON_MAX_CHUNKS;
        if ($max < 1) {
            $max = 1;
        }

        $processed = 0;
        for ($i = 0; $i < $max; $i++) {
            $job_id = (int) db_get_field(
                'SELECT job_id FROM ?:ap_safecache_cf_purge_jobs WHERE status = ?s AND next_run_at <= ?i ORDER BY job_id ASC LIMIT 1',
                'pending',
                $now
            );
            if ($job_id <= 0) {
                break;
            }

            db_query(
                'UPDATE ?:ap_safecache_cf_purge_jobs SET status = ?s, updated_at = ?i WHERE job_id = ?i AND status = ?s',
                'running',
                $now,
                $job_id,
                'pending'
            );

            $job = db_get_row('SELECT * FROM ?:ap_safecache_cf_purge_jobs WHERE job_id = ?i', $job_id);
            if (empty($job['job_id']) || (isset($job['status']) && (string) $job['status'] !== 'running')) {
                continue;
            }

            $kind = isset($job['kind']) ? (string) $job['kind'] : 'tags';
            $payload = json_decode((string) $job['payload_json'], true);

            if ($kind === 'tags' && is_array($payload) && isset($payload['tags']) && is_array($payload['tags'])) {
                $tags = array_values(array_filter(array_map('strval', $payload['tags'])));
                fn_ap_safecache_purge_queue_process_tags_job($job, $tags);
                $processed++;
            } elseif ($kind === 'urls' && is_array($payload) && isset($payload['urls']) && is_array($payload['urls'])) {
                $urls = array_values(array_filter(array_map('strval', $payload['urls'])));
                list($urls, $v_err) = fn_ap_safecache_purge_queue_validate_urls_for_job($urls);
                if ($v_err !== '' || $urls === []) {
                    db_query(
                        'UPDATE ?:ap_safecache_cf_purge_jobs SET status = ?s, error_message = ?s, updated_at = ?i WHERE job_id = ?i',
                        'failed',
                        substr((string) $v_err, 0, 500),
                        time(),
                        $job_id
                    );
                } else {
                    fn_ap_safecache_purge_queue_process_urls_job($job, $urls);
                    $processed++;
                }
            } else {
                db_query(
                    'UPDATE ?:ap_safecache_cf_purge_jobs SET status = ?s, error_message = ?s, updated_at = ?i WHERE job_id = ?i',
                    'failed',
                    substr('unsupported kind or payload', 0, 500),
                    time(),
                    $job_id
                );
            }
        }

        $pruned = fn_ap_safecache_purge_queue_prune_old_jobs($now);
        $prune_suffix = '';
        if ($pruned['done'] > 0 || $pruned['failed'] > 0) {
            $prune_suffix = ' ' . __('ap_safecache.purge_queue_cron_pruned_suffix', [
                '[done]'   => (string) $pruned['done'],
                '[failed]' => (string) $pruned['failed'],
            ]);
        }

        if ($processed === 0) {
            echo 'OK: ' . __('ap_safecache.purge_queue_cron_noop') . $prune_suffix;

            return;
        }

        echo 'OK: ' . __('ap_safecache.purge_queue_cron_processed', ['[n]' => (string) $processed]) . $prune_suffix;
    } finally {
        db_get_field('SELECT RELEASE_LOCK(?s)', $lock_key);
    }
}
