<?php

if ( !defined('BOOTSTRAP') ) { die('Access denied'); }

fn_register_hooks(
    'dispatch_before_display',
    'get_route',
    'before_dispatch',
    'update_addon_post',
    'import_post',
    'update_product_post',
    'delete_product_pre',
    'delete_product_post',
    'update_category_post',
    'delete_category_post',
    'clear_cache_post'
);