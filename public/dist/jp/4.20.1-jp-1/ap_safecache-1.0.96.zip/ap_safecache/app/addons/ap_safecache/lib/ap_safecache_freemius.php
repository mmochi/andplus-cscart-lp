<?php

/**
 * Freemius REST API（ライセンス有効化）— CS-Cart 管理画面からの同期用。
 *
 * @see https://docs.freemius.com/api/licenses — POST /products/{id}/licenses/activate.json （Authorization 不要）
 */

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}

require_once __DIR__ . '/ap_safecache_freemius_config.php';

use Tygh\Http;
use Tygh\Registry;
use Tygh\Settings;

if (!defined('AP_SAFECACHE_FREEMIUS_API')) {
    define('AP_SAFECACHE_FREEMIUS_API', 'https://api.freemius.com/v1');
}

/**
 * 定数または旧 DB 値から Freemius プロダクト ID（数字のみ）を得る。
 *
 * @return string 空 = 未設定
 */
function fn_ap_safecache_freemius_get_product_id()
{
    $c = defined('AP_SAFECACHE_FREEMIUS_PRODUCT_ID') ? trim((string) AP_SAFECACHE_FREEMIUS_PRODUCT_ID) : '';
    if ($c !== '' && ctype_digit($c)) {
        return $c;
    }
    $a = fn_ap_safecache_freemius_get_addon_row();
    $db = isset($a['freemius_product_id']) ? trim((string) $a['freemius_product_id']) : '';

    return ($db !== '' && ctype_digit($db)) ? $db : '';
}

/**
 * チェックアウト／料金ページ URL（定数優先、なければ旧 DB）。
 */
function fn_ap_safecache_freemius_get_checkout_url()
{
    $c = defined('AP_SAFECACHE_FREEMIUS_CHECKOUT_URL') ? trim((string) AP_SAFECACHE_FREEMIUS_CHECKOUT_URL) : '';
    if ($c !== '') {
        return fn_ap_safecache_freemius_normalize_http_url($c);
    }
    $a = fn_ap_safecache_freemius_get_addon_row();
    $db = isset($a['freemius_checkout_url']) ? trim((string) $a['freemius_checkout_url']) : '';

    return fn_ap_safecache_freemius_normalize_http_url($db);
}

/**
 * Pro Single Store 向けチェックアウト URL（`ap_safecache_freemius_config.php` の定数 → 従来の単一 CHECKOUT_URL）。
 *
 * @return string
 */
function fn_ap_safecache_freemius_get_checkout_url_pro_single_store()
{
    $c = defined('AP_SAFECACHE_FREEMIUS_CHECKOUT_URL_PRO_SINGLE_STORE')
        ? trim((string) AP_SAFECACHE_FREEMIUS_CHECKOUT_URL_PRO_SINGLE_STORE)
        : '';
    if ($c !== '') {
        return fn_ap_safecache_freemius_normalize_http_url($c);
    }

    return fn_ap_safecache_freemius_get_checkout_url();
}

/**
 * Pro Multi Vendor 向けチェックアウト URL（定数 → Single Store と同順でフォールバック）。
 *
 * @return string
 */
function fn_ap_safecache_freemius_get_checkout_url_pro_multi_vendor()
{
    $c = defined('AP_SAFECACHE_FREEMIUS_CHECKOUT_URL_PRO_MULTI_VENDOR')
        ? trim((string) AP_SAFECACHE_FREEMIUS_CHECKOUT_URL_PRO_MULTI_VENDOR)
        : '';
    if ($c !== '') {
        return fn_ap_safecache_freemius_normalize_http_url($c);
    }

    return fn_ap_safecache_freemius_get_checkout_url_pro_single_store();
}

/**
 * 管理画面「現在のエディション」用ラベル（Free / Pro Single Store / Pro Multi Vendor）。
 *
 * @return string
 */
function fn_ap_safecache_freemius_license_edition_label_for_manage()
{
    if (fn_ap_safecache_freemius_is_enabled()
        && fn_ap_safecache_freemius_get_license_key_trimmed() !== ''
        && fn_ap_safecache_freemius_should_show_multivendor_plan_mismatch_notice()
    ) {
        $slug = fn_ap_safecache_freemius_last_plan_slug();

        return (string) __('ap_safecache.freemius_edition_label_mv_license_required', [
            '[plan]' => fn_ap_safecache_freemius_plan_display_name_for_ui($slug),
        ]);
    }

    $tier = fn_ap_safecache_get_license_tier();
    if ($tier === 'free') {
        return (string) __('ap_safecache.edition_label_free');
    }

    if ($tier !== 'pro') {
        return (string) __('ap_safecache.edition_label_free');
    }

    if (!fn_ap_safecache_freemius_is_enabled()) {
        return (string) __('ap_safecache.freemius_plan_name_pro');
    }

    $slug = fn_ap_safecache_freemius_last_plan_slug();

    return fn_ap_safecache_freemius_plan_display_name_for_ui($slug);
}

/**
 * Freemius 利用時、**Free（未購入・キー未入力）** のときだけ 2 本のチェックアウト導線を出す。
 * Pro Single / Pro Multi 同期済み（is_pro）は出さない。キーあり・未アクティベートも購入導線は出さない。
 *
 * @return bool
 */
function fn_ap_safecache_freemius_should_show_free_purchase_links()
{
    if (!fn_ap_safecache_freemius_is_enabled()) {
        return false;
    }

    if (fn_ap_safecache_is_pro()) {
        return false;
    }

    if (fn_ap_safecache_freemius_get_license_key_trimmed() !== '') {
        return false;
    }

    return fn_ap_safecache_get_license_tier() === 'free';
}

/**
 * 管理画面に Freemius アクティベート（POST）ボタンを出すか。キーあり・未 Pro のときのみ。
 *
 * @return bool
 */
function fn_ap_safecache_freemius_should_show_activate_button()
{
    if (!fn_ap_safecache_freemius_is_enabled()) {
        return false;
    }
    if (fn_ap_safecache_freemius_get_license_key_trimmed() === '') {
        return false;
    }

    return !fn_ap_safecache_is_pro();
}

/**
 * カスタマーポータル URL（定数優先、なければ旧 DB）。
 */
function fn_ap_safecache_freemius_get_customer_portal_url()
{
    $c = defined('AP_SAFECACHE_FREEMIUS_CUSTOMER_PORTAL_URL') ? trim((string) AP_SAFECACHE_FREEMIUS_CUSTOMER_PORTAL_URL) : '';
    if ($c !== '') {
        return fn_ap_safecache_freemius_normalize_http_url($c);
    }
    $a = fn_ap_safecache_freemius_get_addon_row();
    $db = isset($a['freemius_customer_portal_url']) ? trim((string) $a['freemius_customer_portal_url']) : '';

    return fn_ap_safecache_freemius_normalize_http_url($db);
}

/**
 * 外部リンク用。スキーム省略時は https を補う。
 *
 * @param string $url
 *
 * @return string
 */
function fn_ap_safecache_freemius_normalize_http_url($url)
{
    $url = trim((string) $url);
    if ($url === '') {
        return '';
    }
    if (!preg_match('#^https?://#i', $url)) {
        $url = 'https://' . ltrim($url, '/');
    }

    return $url;
}

/**
 * 定数でプロダクト ID が埋まっている = 販売ビルド（設定画面のトグルに依存しない）。
 */
function fn_ap_safecache_freemius_is_locked_by_constant()
{
    $c = defined('AP_SAFECACHE_FREEMIUS_PRODUCT_ID') ? trim((string) AP_SAFECACHE_FREEMIUS_PRODUCT_ID) : '';

    return $c !== '' && ctype_digit($c);
}

/**
 * @return array<string, mixed>
 */
function fn_ap_safecache_freemius_get_addon_row()
{
    $addon = Registry::get('addons.ap_safecache');

    return is_array($addon) ? $addon : [];
}

/**
 * Registry が保存直後に未更新のとき用。DB（Settings）の値をフォールバックする。
 *
 * @return string
 */
function fn_ap_safecache_freemius_get_license_key_trimmed()
{
    $a = fn_ap_safecache_freemius_get_addon_row();
    $key = isset($a['freemius_license_key']) ? trim((string) $a['freemius_license_key']) : '';
    if ($key !== '') {
        return $key;
    }

    return trim((string) Settings::instance()->getValue('freemius_license_key', 'ap_safecache'));
}

/**
 * activate.json 応答からプラン slug らしき文字列を取り出す（キー名の揺れ対策）。
 *
 * @param array<string, mixed> $data
 *
 * @return string 小文字・trim 済み、無ければ空
 */
function fn_ap_safecache_freemius_activate_response_extract_plan_slug(array $data)
{
    $paths = [
        ['license_plan_name'],
        ['plan', 'name'],
        ['plan', 'title'],
        ['license', 'plan', 'name'],
        ['license', 'plan_name'],
    ];
    foreach ($paths as $p) {
        $v = $data;
        foreach ($p as $seg) {
            if (!is_array($v) || !isset($v[$seg])) {
                $v = null;
                break;
            }
            $v = $v[$seg];
        }
        if (is_string($v) && trim($v) !== '') {
            return strtolower(trim($v));
        }
    }

    return '';
}

/**
 * 応答文字列が pro_slugs のいずれかを含むならその slug に寄せる（Freemius の表記ゆれ緩和）。
 *
 * @param string $plan_raw
 *
 * @return string マッチ時は pro_slugs の要素、否则空
 */
function fn_ap_safecache_freemius_match_plan_slug_to_pro_list($plan_raw)
{
    $s = strtolower(trim((string) $plan_raw));
    if ($s === '') {
        return '';
    }
    $list = fn_ap_safecache_freemius_pro_slugs();
    usort($list, function ($a, $b) {
        return strlen((string) $b) <=> strlen((string) $a);
    });
    $s_c = fn_ap_safecache_freemius_compact_plan_slug($s);
    foreach ($list as $ps) {
        $ps = (string) $ps;
        if ($ps === '') {
            continue;
        }
        if ($s === $ps) {
            return $ps;
        }
        if ($s_c !== '' && fn_ap_safecache_freemius_compact_plan_slug($ps) === $s_c) {
            return $ps;
        }
        // 「pro」だけは部分一致にしない（promv / professional 等を誤認しない）
        if ($ps === 'pro') {
            continue;
        }
        if (strpos($s, $ps) !== false) {
            return $ps;
        }
    }

    return '';
}

/**
 * @return bool
 */
function fn_ap_safecache_freemius_is_enabled()
{
    if (fn_ap_safecache_freemius_is_locked_by_constant()) {
        return true;
    }
    $a = fn_ap_safecache_freemius_get_addon_row();

    return !empty($a['freemius_use']) && $a['freemius_use'] === 'Y';
}

/**
 * @return array<string, string|int>
 */
function fn_ap_safecache_freemius_decode_state($raw)
{
    $raw = is_string($raw) ? trim($raw) : '';
    if ($raw === '') {
        return [];
    }
    $j = json_decode($raw, true);

    return is_array($j) ? $j : [];
}

/**
 * @param array<string, string|int> $state
 */
function fn_ap_safecache_freemius_save_state(array $state)
{
    $json = json_encode($state, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        return;
    }
    Settings::instance()->updateValue('freemius_state_json', $json, 'ap_safecache', true, null, true, 0);
    Registry::set('addons.ap_safecache.freemius_state_json', $json);
}

/**
 * @return string[]
 */
function fn_ap_safecache_freemius_pro_slugs()
{
    $a = fn_ap_safecache_freemius_get_addon_row();
    $raw = isset($a['freemius_plan_slugs_pro']) ? trim((string) $a['freemius_plan_slugs_pro']) : 'pross,promv,pro,pro-ss,pro-mv';
    if ($raw === '') {
        $raw = 'pross,promv,pro,pro-ss,pro-mv';
    }
    $parts = preg_split('/[\s,]+/', $raw, -1, PREG_SPLIT_NO_EMPTY);
    $out = [];
    foreach ($parts as $p) {
        $out[] = strtolower($p);
    }

    return array_values(array_unique($out));
}

/**
 * プラン slug の比較用に正規化（Freemius は pro-ss、当方は pross など表記ゆれあり）。
 *
 * @param string $s
 *
 * @return string 小文字・ハイフン・アンダースコア・空白除去
 */
function fn_ap_safecache_freemius_compact_plan_slug($s)
{
    $s = strtolower(trim((string) $s));

    return (string) preg_replace('/[-_\s]+/', '', $s);
}

/**
 * 同期済み slug が有料プラン一覧に含まれるか（文字列完全一致に加え compact 一致）。
 *
 * @param string   $slug
 * @param string[] $pro_slugs
 *
 * @return bool
 */
function fn_ap_safecache_freemius_slug_matches_any_pro_slug($slug, array $pro_slugs)
{
    $slug = strtolower(trim((string) $slug));
    if ($slug === '') {
        return false;
    }
    $slug_c = fn_ap_safecache_freemius_compact_plan_slug($slug);
    foreach ($pro_slugs as $ps) {
        $ps = strtolower(trim((string) $ps));
        if ($ps === '') {
            continue;
        }
        if ($slug === $ps) {
            return true;
        }
        if ($slug_c !== '' && fn_ap_safecache_freemius_compact_plan_slug($ps) === $slug_c) {
            return true;
        }
    }

    return false;
}

/**
 * CS-Cart 本体が Multi-Vendor エディションか。
 *
 * @return bool
 */
function fn_ap_safecache_freemius_is_cs_cart_multivendor_edition()
{
    return defined('PRODUCT_EDITION') && strtoupper((string) PRODUCT_EDITION) === 'MULTIVENDOR';
}

/**
 * Freemius が返したプラン slug が Pro リストに含まれたうえで、このサイトの PRODUCT_EDITION 上で Pro とみなせるか。
 * MULTIVENDOR では **promv のみ**。ULTIMATE 等では pross / promv / pro（いずれもリスト一致時）は Pro。
 *
 * @param string $slug last_plan_slug 生値
 *
 * @return string 'pro'|'free'
 */
function fn_ap_safecache_freemius_pro_tier_for_slug_and_product_edition($slug)
{
    $c = fn_ap_safecache_freemius_compact_plan_slug($slug);

    if (!defined('PRODUCT_EDITION') || PRODUCT_EDITION === '') {
        return 'pro';
    }

    if (strtoupper((string) PRODUCT_EDITION) === 'MULTIVENDOR') {
        return $c === 'promv' ? 'pro' : 'free';
    }

    return 'pro';
}

/**
 * MV 本体で、キーあり・同期済みプランが Freemius 上は Pro 系だがエディションにより Pro として無効なときに警告を出す。
 *
 * @return bool
 */
function fn_ap_safecache_freemius_should_show_multivendor_plan_mismatch_notice()
{
    if (!fn_ap_safecache_freemius_is_enabled()) {
        return false;
    }
    if (!fn_ap_safecache_freemius_is_cs_cart_multivendor_edition()) {
        return false;
    }
    if (fn_ap_safecache_freemius_get_license_key_trimmed() === '') {
        return false;
    }

    $slug = fn_ap_safecache_freemius_last_plan_slug();
    if ($slug === '') {
        return false;
    }

    $pro_slugs = fn_ap_safecache_freemius_pro_slugs();
    if (!fn_ap_safecache_freemius_slug_matches_any_pro_slug($slug, $pro_slugs)) {
        return false;
    }

    return fn_ap_safecache_freemius_pro_tier_for_slug_and_product_edition($slug) === 'free';
}

/**
 * 管理画面向けプラン表示名（内部 slug はユーザーに見せない）。
 *
 * @param string $slug_raw `last_plan_slug` 生値
 *
 * @return string
 */
function fn_ap_safecache_freemius_plan_display_name_for_ui($slug_raw)
{
    $slug = strtolower(trim((string) $slug_raw));
    if ($slug === '' || $slug === '-') {
        return (string) __('ap_safecache.freemius_plan_name_none');
    }

    $c = fn_ap_safecache_freemius_compact_plan_slug($slug);
    if ($c === 'pross') {
        return (string) __('ap_safecache.freemius_plan_name_pro_single_store');
    }
    if ($c === 'promv') {
        return (string) __('ap_safecache.freemius_plan_name_pro_multi_vendor');
    }
    if ($c === 'pro') {
        return (string) __('ap_safecache.freemius_plan_name_pro');
    }

    $pretty = preg_replace('/[-_]+/', ' ', (string) $slug_raw);
    $pretty = trim((string) preg_replace('/\s+/', ' ', $pretty));

    return $pretty !== '' ? $pretty : (string) $slug_raw;
}

/**
 * 推奨 Cache Rules に vendor パネル用パス（例: /ap_vendor.php）を含めるか。
 * Freemius・Pro のときは **Pro Multi Vendor（promv）のみ** true（Single Store では vendor 行を出さない）。
 * Freemius 未使用、または Free のときは従来どおり vendor_index があれば含める。
 *
 * @return bool
 */
function fn_ap_safecache_freemius_should_include_vendor_paths_in_cf_recommendations()
{
    $conf = Registry::get('config');
    $conf = is_array($conf) ? $conf : [];
    $vendor_index = isset($conf['vendor_index']) ? trim((string) $conf['vendor_index']) : '';
    if ($vendor_index === '') {
        return false;
    }

    if (!fn_ap_safecache_freemius_is_enabled()) {
        return true;
    }

    if (!function_exists('fn_ap_safecache_freemius_resolve_tier_or_null')) {
        return true;
    }

    $tier = fn_ap_safecache_freemius_resolve_tier_or_null();
    if ($tier === null) {
        return true;
    }

    if ($tier === 'free') {
        return true;
    }

    $a = fn_ap_safecache_freemius_get_addon_row();
    $state = fn_ap_safecache_freemius_decode_state(isset($a['freemius_state_json']) ? (string) $a['freemius_state_json'] : '');
    $slug = isset($state['last_plan_slug']) ? strtolower(trim((string) $state['last_plan_slug'])) : '';

    return fn_ap_safecache_freemius_compact_plan_slug($slug) === 'promv';
}

/**
 * 同期済み Freemius プラン識別子（activate 応答の plan 名を小文字化して `last_plan_slug` に保持）。
 *
 * @return string 空 = 未同期
 */
function fn_ap_safecache_freemius_last_plan_slug()
{
    $a = fn_ap_safecache_freemius_get_addon_row();
    $state = fn_ap_safecache_freemius_decode_state(isset($a['freemius_state_json']) ? (string) $a['freemius_state_json'] : '');
    $slug = isset($state['last_plan_slug']) ? strtolower(trim((string) $state['last_plan_slug'])) : '';

    return $slug;
}

/**
 * インストール固有 UID（32 文字）— Freemius API 必須。
 */
function fn_ap_safecache_freemius_ensure_uid()
{
    $a = fn_ap_safecache_freemius_get_addon_row();
    $existing = isset($a['freemius_install_uid']) ? trim((string) $a['freemius_install_uid']) : '';
    if ($existing === '' || strlen($existing) !== 32 || !ctype_alnum($existing)) {
        // Registry が保存直後に未更新のときや、ブートストラップで addon 行に載らないことがある。
        // freemius_license_key と同様に Settings を見ないと、リクエストごとに新 UID が発行され、
        // Freemius 上で同一 URL に複数 install が増え license_utilized になる。
        $existing = trim((string) Settings::instance()->getValue('freemius_install_uid', 'ap_safecache'));
    }
    if (strlen($existing) === 32 && ctype_alnum($existing)) {
        $addon = Registry::get('addons.ap_safecache');
        if (is_array($addon) && (!isset($addon['freemius_install_uid']) || (string) $addon['freemius_install_uid'] !== $existing)) {
            $addon['freemius_install_uid'] = $existing;
            Registry::set('addons.ap_safecache', $addon);
        }

        return $existing;
    }
    $seed = (string) microtime(true) . (string) mt_rand() . (defined('INSTALLATION_HASH') ? INSTALLATION_HASH : '');
    $uid = strtolower(substr(hash('sha256', $seed), 0, 32));
    Settings::instance()->updateValue('freemius_install_uid', $uid, 'ap_safecache', true, null, true, 0);
    Registry::set('addons.ap_safecache.freemius_install_uid', $uid);

    return $uid;
}

/**
 * Freemius 有効時の tier。手動 license_tier は無視される（addon 設定で明示）。
 *
 * @return string|null null = Freemius を使わない／未構成でフォールバック
 */
function fn_ap_safecache_freemius_resolve_tier_or_null()
{
    if (!fn_ap_safecache_freemius_is_enabled()) {
        return null;
    }
    $a = fn_ap_safecache_freemius_get_addon_row();
    $pid = fn_ap_safecache_freemius_get_product_id();
    if ($pid === '' || !ctype_digit($pid)) {
        // Freemius を有効化したのに Product ID が無い/不正な場合は free 扱い。
        // 手動 license_tier へのフォールバックで意図せず Pro にならないようにする。
        return 'free';
    }
    $key = fn_ap_safecache_freemius_get_license_key_trimmed();
    if ($key === '') {
        return 'free';
    }
    $state = fn_ap_safecache_freemius_decode_state(isset($a['freemius_state_json']) ? (string) $a['freemius_state_json'] : '');
    $slug = isset($state['last_plan_slug']) ? strtolower(trim((string) $state['last_plan_slug'])) : '';
    if ($slug === '') {
        return 'free';
    }
    $pro_slugs = fn_ap_safecache_freemius_pro_slugs();

    if (!fn_ap_safecache_freemius_slug_matches_any_pro_slug($slug, $pro_slugs)) {
        return 'free';
    }

    return fn_ap_safecache_freemius_pro_tier_for_slug_and_product_edition($slug);
}

/**
 * `ap_safecache.manage` を GET で開いたとき、Freemius 自動再検証（12 時間に 1 回まで）。
 * 通知は出さない。HTTP／レスポンス JSON 不正時は `last_plan_slug` を変更しない（手動同期と同じ）。
 *
 * @return void
 */
function fn_ap_safecache_freemius_auto_sync_on_manage_get()
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
        return;
    }
    if (!fn_ap_safecache_freemius_is_enabled()) {
        return;
    }
    $a = fn_ap_safecache_freemius_get_addon_row();
    $pid = fn_ap_safecache_freemius_get_product_id();
    if ($pid === '' || !ctype_digit($pid)) {
        return;
    }
    $key = fn_ap_safecache_freemius_get_license_key_trimmed();
    if ($key === '') {
        return;
    }
    // 既に Pro 同期済みなら activate を再実行しない（応答表記ゆれで last_plan_slug が消えるのを防ぐ）
    if (fn_ap_safecache_is_pro()) {
        return;
    }
    $state = fn_ap_safecache_freemius_decode_state(isset($a['freemius_state_json']) ? (string) $a['freemius_state_json'] : '');
    $last_auto = isset($state['last_auto_sync_at']) ? (int) $state['last_auto_sync_at'] : 0;
    if ($last_auto > 0 && (time() - $last_auto) < (int) AP_SAFECACHE_FREEMIUS_AUTO_SYNC_COOLDOWN_SEC) {
        return;
    }

    fn_ap_safecache_freemius_sync_license(['auto' => true]);
}

/**
 * Freemius REST `POST .../licenses/activate.json` でライセンスを検証し、本サイトをアクティベートする（読み取り専用の「同期」ではない）。
 *
 * @param array{auto?: bool, force?: bool} $options
 *   `auto`  — 管理画面 GET からの自動再検証（通知なし・クールダウン用 `last_auto_sync_at` を更新）。
 *   `force` — 既に Pro 同期済みでも短絡せず、必ず activate を実行して状態を更新する（cron 用）。
 *
 * @return array{0: bool, 1: string} [ok, message]
 */
function fn_ap_safecache_freemius_sync_license(array $options = [])
{
    $is_auto = !empty($options['auto']);
    $is_force = !empty($options['force']);

    if (!fn_ap_safecache_freemius_is_enabled()) {
        return [false, __('ap_safecache.freemius_err_not_enabled')];
    }
    $a = fn_ap_safecache_freemius_get_addon_row();
    $pid = fn_ap_safecache_freemius_get_product_id();
    if ($pid === '' || !ctype_digit($pid)) {
        return [false, __('ap_safecache.freemius_err_product_id')];
    }
    $key = fn_ap_safecache_freemius_get_license_key_trimmed();
    if ($key === '') {
        return [false, __('ap_safecache.freemius_err_license_empty')];
    }

    $state_pre = fn_ap_safecache_freemius_decode_state(isset($a['freemius_state_json']) ? (string) $a['freemius_state_json'] : '');
    $prev_plan_slug = isset($state_pre['last_plan_slug']) ? strtolower(trim((string) $state_pre['last_plan_slug'])) : '';

    if ($is_auto && !$is_force && fn_ap_safecache_is_pro()) {
        return [true, ''];
    }
    if (!$is_auto && !$is_force && fn_ap_safecache_is_pro()) {
        $lab = fn_ap_safecache_freemius_plan_display_name_for_ui(fn_ap_safecache_freemius_last_plan_slug());

        return [
            true,
            __('ap_safecache.freemius_ok_already_active', ['[plan]' => $lab !== '' ? $lab : '-']),
        ];
    }

    $uid = fn_ap_safecache_freemius_ensure_uid();
    $url = function_exists('fn_get_storefront_url') ? fn_get_storefront_url('http', 0) : '';
    if ($url === '') {
        $url = Registry::get('config.http_location');
    }
    $url = is_string($url) ? rtrim($url, '/') : '';
    if ($url === '') {
        $url = 'https://example.invalid';
    }

    $title = Registry::get('settings.Company.company_name');
    $title = is_string($title) && $title !== '' ? $title : 'CS-Cart';
    $ver = fn_ap_safecache_get_addon_version();

    $body = [
        'uid'         => $uid,
        'license_key' => $key,
        'url'         => $url,
        'title'       => $title,
        'version'     => $ver,
    ];

    $endpoint = AP_SAFECACHE_FREEMIUS_API . '/products/' . $pid . '/licenses/activate.json';
    $extra = [
        'timeout' => 45,
        'headers' => [
            'Content-Type: application/json',
        ],
    ];
    $payload = json_encode($body, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $response = Http::post($endpoint, $payload, $extra);
    $status = (int) Http::getStatus();

    $state = fn_ap_safecache_freemius_decode_state(isset($a['freemius_state_json']) ? (string) $a['freemius_state_json'] : '');
    $state['uid'] = $uid;

    if ($response === false) {
        $state['last_error'] = 'http';
        if ($is_auto) {
            $state['last_auto_sync_at'] = time();
        }
        fn_ap_safecache_freemius_save_state($state);

        return [false, __('ap_safecache.freemius_err_http')];
    }

    $data = json_decode($response, true);
    if (!is_array($data)) {
        $state['last_error'] = 'json';
        if ($is_auto) {
            $state['last_auto_sync_at'] = time();
        }
        fn_ap_safecache_freemius_save_state($state);

        return [false, __('ap_safecache.freemius_err_bad_response')];
    }

    $state['last_sync_at'] = time();
    $state['last_auto_sync_at'] = time();

    $err_code = '';
    if (!empty($data['error']) && is_array($data['error'])) {
        $err_code = isset($data['error']['code']) ? strtolower(trim((string) $data['error']['code'])) : '';
        if ($err_code === '' && !empty($data['error']['type'])) {
            $err_code = strtolower(trim((string) $data['error']['type']));
        }
    }

    $plan = fn_ap_safecache_freemius_activate_response_extract_plan_slug($data);
    $matched = fn_ap_safecache_freemius_match_plan_slug_to_pro_list($plan);
    if ($matched !== '') {
        $plan = $matched;
    }

    if ($err_code !== '' && $err_code !== 'license_activated') {
        $msg = '';
        if (!empty($data['error']['message'])) {
            $msg = (string) $data['error']['message'];
        }
        $state['last_error'] = $err_code;
        // 期限切れ・無効化など「ライセンスとして Pro を継続できない」コードは last_plan_slug を落とす。
        // それ以外（一時的な API 失敗・license_utilized 等）は従来どおり前回同期の slug を残す。
        $clear_plan_slug = in_array(
            $err_code,
            [
                'license_expired',
                'license_disabled',
                'license_invalid',
                'license_cancelled',
                'license_abandoned',
                'license_revoked',
            ],
            true
        );
        if ($clear_plan_slug) {
            $state['last_plan_slug'] = '';
        } elseif ($prev_plan_slug !== '') {
            $state['last_plan_slug'] = $prev_plan_slug;
        } else {
            $state['last_plan_slug'] = '';
        }
        fn_ap_safecache_freemius_save_state($state);

        if ($err_code === 'license_utilized') {
            $portal = fn_ap_safecache_freemius_get_customer_portal_url();

            return [false, __('ap_safecache.freemius_err_license_utilized', [
                '[portal_url]' => $portal !== '' ? $portal : 'https://customers.freemius.com/',
                '[detail]'      => $msg,
            ])];
        }

        return [false, __('ap_safecache.freemius_err_api', ['[code]' => $err_code, '[message]' => $msg])];
    }

    if ($err_code === 'license_activated' && $plan === '' && isset($state['last_plan_slug'])) {
        $plan = strtolower(trim((string) $state['last_plan_slug']));
    }
    // 既に当該 UID でアクティブなだけで plan 名が返らないことがある（初回同期で last_plan_slug が空のとき）
    if ($err_code === 'license_activated' && $plan === '') {
        $plan = 'pro';
    }
    if ($plan === '' && $prev_plan_slug !== '') {
        $plan = $prev_plan_slug;
    }
    if ($plan === '' && ($err_code === '' || $err_code === 'license_activated') && $status >= 200 && $status < 300) {
        $plan = 'pro';
    }

    $state['last_plan_slug'] = $plan;
    $state['last_error'] = '';
    if (!empty($data['install_id'])) {
        $state['install_id'] = (string) $data['install_id'];
    }
    if (!empty($data['install_api_token'])) {
        $state['install_api_token'] = (string) $data['install_api_token'];
    }
    fn_ap_safecache_freemius_save_state($state);

    $http_ok = $status >= 200 && $status < 300;
    if (!$http_ok && $err_code !== 'license_activated') {
        return [false, __('ap_safecache.freemius_err_http_status', ['[code]' => (string) $status])];
    }

    $plan_label = fn_ap_safecache_freemius_plan_display_name_for_ui($plan);

    return [true, __('ap_safecache.freemius_ok_sync', ['[plan]' => $plan !== '' ? $plan_label : '-'])];
}

/**
 * 管理画面用: Freemius 状態の表示・導線。
 *
 * @return array<string, mixed>
 */
function fn_ap_safecache_freemius_get_manage_assignments()
{
    $a = fn_ap_safecache_freemius_get_addon_row();
    $enabled = fn_ap_safecache_freemius_is_enabled();
    $state = fn_ap_safecache_freemius_decode_state(isset($a['freemius_state_json']) ? (string) $a['freemius_state_json'] : '');
    $checkout = fn_ap_safecache_freemius_get_checkout_url();
    $checkout_ss = fn_ap_safecache_freemius_get_checkout_url_pro_single_store();
    $checkout_mv = fn_ap_safecache_freemius_get_checkout_url_pro_multi_vendor();
    $portal = fn_ap_safecache_freemius_get_customer_portal_url();
    $slug = isset($state['last_plan_slug']) ? (string) $state['last_plan_slug'] : '';
    $last_sync = isset($state['last_sync_at']) ? (int) $state['last_sync_at'] : 0;

    $is_mv = fn_ap_safecache_freemius_is_cs_cart_multivendor_edition();

    return [
        'ap_safecache_freemius_enabled'                    => $enabled,
        'ap_safecache_freemius_checkout_url'               => $checkout,
        'ap_safecache_freemius_checkout_url_pro_ss'        => $checkout_ss,
        'ap_safecache_freemius_checkout_url_pro_mv'        => $checkout_mv,
        'ap_safecache_freemius_show_free_purchase_links'   => fn_ap_safecache_freemius_should_show_free_purchase_links(),
        'ap_safecache_freemius_show_activate_button'       => fn_ap_safecache_freemius_should_show_activate_button(),
        'ap_safecache_freemius_show_checkout_pro_single_store' => !$is_mv,
        'ap_safecache_freemius_show_checkout_pro_multi_vendor' => $is_mv,
        'ap_safecache_freemius_show_mv_plan_mismatch_notice' => fn_ap_safecache_freemius_should_show_multivendor_plan_mismatch_notice(),
        'ap_safecache_license_edition_label'               => fn_ap_safecache_freemius_license_edition_label_for_manage(),
        'ap_safecache_freemius_customer_portal_url'        => $portal,
        'ap_safecache_freemius_last_plan_slug'             => $slug,
        'ap_safecache_freemius_last_plan_label'            => fn_ap_safecache_freemius_plan_display_name_for_ui($slug),
        'ap_safecache_freemius_last_sync_at'               => $last_sync,
        'ap_safecache_freemius_addon_settings_url'         => fn_url('addons.update?addon=ap_safecache', 'A'),
    ];
}
