<?php

/**
 * Cloudflare 経由アクセス時の REMOTE_ADDR 補正（クライアント実 IP への置換）。
 *
 * 【目的】
 * プロキシ背後では PHP の REMOTE_ADDR がエッジ IP になり、コア同梱の app/payments/pay_read.php など
 * REMOTE_ADDR 依存の処理が誤った値を参照する場合がある。本モジュールは HTTP_CF_CONNECTING_IP を
 * REMOTE_ADDR に反映する（条件付き）。
 *
 * 【無効化・巻き戻し】
 * (1) 管理画面 → アドオン → ap_safecache → 「client IP」セクションのチェックをオフにする（既定はオフ）。
 * (2) または app/addons/ap_safecache/init.php から get_route の登録を外す。
 * (3) 置換が走ったリクエストでは $_SERVER['AP_SAFECACHE_ORIGINAL_REMOTE_ADDR'] に元の REMOTE_ADDR を残す。
 *
 * 【信頼条件（必ずすべて満たすこと）】
 * - 現在の REMOTE_ADDR が Cloudflare 公開エッジの IPv4/IPv6 レンジに含まれる（偽ヘッダ対策）。
 * - CF-Connecting-IP（なければ True-Client-IP）が単一の有効なグローバル IP として解釈できる。
 * - 置換先が REMOTE_ADDR と異なる。
 *
 * 【レンジの更新】
 * 下記 CIDR は https://www.cloudflare.com/ips-v4 / ips-v6 の公開リストに基づく。
 * Cloudflare がレンジを変更した場合は同 URL を確認し、本ファイルの定数を更新すること。
 *
 * @package AP_SafeCache
 */

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}

/** @var list<string> Cloudflare IPv4 CIDR（エッジ。REMOTE_ADDR がここに含まれるときのみ CF ヘッダを信頼） */
const AP_SAFECACHE_CF_IPV4_CIDRS = [
    '173.245.48.0/20',
    '103.21.244.0/22',
    '103.22.200.0/22',
    '103.31.4.0/22',
    '141.101.64.0/18',
    '108.162.192.0/18',
    '190.93.240.0/20',
    '188.114.96.0/20',
    '197.234.240.0/22',
    '198.41.128.0/17',
    '162.158.0.0/15',
    '104.16.0.0/13',
    '104.24.0.0/14',
    '172.64.0.0/13',
    '131.0.72.0/22',
];

/** @var list<string> Cloudflare IPv6 CIDR */
const AP_SAFECACHE_CF_IPV6_CIDRS = [
    '2400:cb00::/32',
    '2606:4700::/32',
    '2803:f800::/32',
    '2405:b500::/32',
    '2405:8100::/32',
    '2a06:98c0::/29',
    '2c0f:f248::/32',
];

/**
 * REMOTE_ADDR を CF 経由のクライアント IP に置換する（条件を満たす場合のみ）。
 *
 * @return void
 */
function fn_ap_safecache_apply_remote_addr_from_cloudflare()
{
    if (!empty($_SERVER['AP_SAFECACHE_REMOTE_ADDR_RESTORED'])) {
        return;
    }

    $remote = isset($_SERVER['REMOTE_ADDR']) ? trim((string) $_SERVER['REMOTE_ADDR']) : '';
    if ($remote === '' || !fn_ap_safecache_remote_addr_is_cloudflare_edge($remote)) {
        return;
    }

    $client = fn_ap_safecache_remote_addr_pick_client_ip_from_cf_headers();
    if ($client === '' || $client === $remote) {
        return;
    }

    if (filter_var($client, FILTER_VALIDATE_IP) === false) {
        return;
    }

    $_SERVER['AP_SAFECACHE_ORIGINAL_REMOTE_ADDR'] = $remote;
    $_SERVER['REMOTE_ADDR'] = $client;
    $_SERVER['AP_SAFECACHE_REMOTE_ADDR_RESTORED'] = '1';
}

/**
 * @param string $ip
 *
 * @return bool
 */
function fn_ap_safecache_remote_addr_is_cloudflare_edge($ip)
{
    if (strpos($ip, ':') !== false) {
        foreach (AP_SAFECACHE_CF_IPV6_CIDRS as $cidr) {
            if (fn_ap_safecache_ipv6_in_cidr($ip, $cidr)) {
                return true;
            }
        }

        return false;
    }

    foreach (AP_SAFECACHE_CF_IPV4_CIDRS as $cidr) {
        if (fn_ap_safecache_ipv4_in_cidr($ip, $cidr)) {
            return true;
        }
    }

    return false;
}

/**
 * @return string 先頭の有効な IP、なければ空
 */
function fn_ap_safecache_remote_addr_pick_client_ip_from_cf_headers()
{
    $raw = '';
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $raw = (string) $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (!empty($_SERVER['HTTP_TRUE_CLIENT_IP'])) {
        $raw = (string) $_SERVER['HTTP_TRUE_CLIENT_IP'];
    }

    $raw = trim($raw);
    if ($raw === '') {
        return '';
    }

    $parts = preg_split('/[\s,]+/', $raw, -1, PREG_SPLIT_NO_EMPTY);
    foreach ($parts as $p) {
        $p = trim($p);
        if ($p !== '' && filter_var($p, FILTER_VALIDATE_IP) !== false) {
            return $p;
        }
    }

    return '';
}

/**
 * @param string $ip   IPv4
 * @param string $cidr x.x.x.x/nn
 *
 * @return bool
 */
function fn_ap_safecache_ipv4_in_cidr($ip, $cidr)
{
    $parts = explode('/', $cidr, 2);
    if (count($parts) !== 2) {
        return false;
    }

    $bits = (int) $parts[1];
    if ($bits < 0 || $bits > 32) {
        return false;
    }

    $ip_long = ip2long($ip);
    $subnet_long = ip2long($parts[0]);
    if ($ip_long === false || $subnet_long === false) {
        return false;
    }

    if ($bits === 0) {
        return true;
    }

    $mask = $bits === 32 ? 0xFFFFFFFF : ((-1 << (32 - $bits)) & 0xFFFFFFFF);
    $subnet_long &= $mask;

    return (($ip_long & $mask) & 0xFFFFFFFF) === ($subnet_long & 0xFFFFFFFF);
}

/**
 * @param string $ip   IPv6
 * @param string $cidr addr/nn
 *
 * @return bool
 */
function fn_ap_safecache_ipv6_in_cidr($ip, $cidr)
{
    $parts = explode('/', $cidr, 2);
    if (count($parts) !== 2) {
        return false;
    }

    $bits = (int) $parts[1];
    if ($bits < 0 || $bits > 128) {
        return false;
    }

    $network = @inet_pton($parts[0]);
    $addr = @inet_pton($ip);
    if ($network === false || $addr === false || strlen($network) !== 16 || strlen($addr) !== 16) {
        return false;
    }

    $full_bytes = intdiv($bits, 8);
    for ($i = 0; $i < $full_bytes; $i++) {
        if ($addr[$i] !== $network[$i]) {
            return false;
        }
    }

    $remainder = $bits % 8;
    if ($remainder > 0) {
        $mask = (0xFF << (8 - $remainder)) & 0xFF;
        if ((ord($addr[$full_bytes]) & $mask) !== (ord($network[$full_bytes]) & $mask)) {
            return false;
        }
    }

    return true;
}
