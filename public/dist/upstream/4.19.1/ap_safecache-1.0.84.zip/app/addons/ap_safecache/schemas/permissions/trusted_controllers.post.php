<?php

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}

$schema['ap_safecache']['allow']['cron_cf_poll'] = true;
$schema['ap_safecache']['allow']['cron_freemius_sync'] = true;

return $schema;
