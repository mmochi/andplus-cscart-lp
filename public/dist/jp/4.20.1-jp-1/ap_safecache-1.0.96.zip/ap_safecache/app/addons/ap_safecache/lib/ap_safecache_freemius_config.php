<?php

/**
 * Freemius 販売側固定値（ZIP ビルド時に埋める／空なら従来どおり DB の旧値を参照）。
 * 同ディレクトリの ap_safecache_freemius_config.local.php があれば先に読み込み（if (!defined(...)) define で上書き可）。
 *
 * --- Freemius 側の「どの値か」（対応表）---
 *
 * AP_SAFECACHE_FREEMIUS_PRODUCT_ID
 *   Developer Dashboard → 対象製品を開いたときの製品 ID（数値）。REST API のパス
 *   `/v1/products/{product_id}/...`（例: licenses/activate.json）と同一。
 *
 * AP_SAFECACHE_FREEMIUS_CHECKOUT_URL
 *   後方互換用の単一チェックアウト URL。優先は下記 Pro Single / Pro Multi の各定数。
 *
 * AP_SAFECACHE_FREEMIUS_CHECKOUT_URL_PRO_SINGLE_STORE / AP_SAFECACHE_FREEMIUS_CHECKOUT_URL_PRO_MULTI_VENDOR
 *   Dashboard → Plans →「Get Checkout」の `.../plan/{plan_id}/` をプランごとに定数へ設定（アドオン設定では上書きしない）。
 *
 * AP_SAFECACHE_FREEMIUS_CUSTOMER_PORTAL_URL
 *   顧客用 Customer Portal（例: `https://customers.freemius.com/store/{store_id}/...`）。
 *   store_id は開発者アカウント／ストアにより異なる。ライセンス管理・ダウンロードの導線。
 *
 * AP_SAFECACHE_LICENSE_ACTION_TOKEN_* （URL / API_KEY / DEFAULT_TTL）
 *   Freemius ダッシュボードの項目ではない。Pro 限定操作のトークン発行に自前 HTTP ゲートを使う場合の接続先
 *   （空なら当機能は無効。lib/ap_safecache_license_action_token.php 参照）。
 *   API_KEY: 配布アドオンと認証サーバーで一致させる共有秘密。既定の hex は md5('andplus_ap_safecache') に相当（リテラルで保持）。
 *
 * AP_SAFECACHE_UPDATE_CHECK_URL
 *   本体アップデート互換判定 API（通知用）。空のときは AP_SAFECACHE_LICENSE_ACTION_TOKEN_URL から
 *   `/token` / `/downloads` を `/update-compat` に置換して推測する。
 *
 * AP_SAFECACHE_FREEMIUS_AUTO_SYNC_COOLDOWN_SEC
 *   Freemius の設定ではない。管理画面 `ap_safecache.manage` を GET したときの activate 再検証の最短間隔。
 */

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}

$__ap_safecache_fs_local = __DIR__ . '/ap_safecache_freemius_config.local.php';
if (is_readable($__ap_safecache_fs_local)) {
    require_once $__ap_safecache_fs_local;
}
unset($__ap_safecache_fs_local);

// → Freemius: 製品の Product ID（API `products/{id}` と同じ数値）
if (!defined('AP_SAFECACHE_FREEMIUS_PRODUCT_ID')) {
    define('AP_SAFECACHE_FREEMIUS_PRODUCT_ID', '27895');
}

// → Freemius: Plans の Get Checkout（後方互換・単一）
if (!defined('AP_SAFECACHE_FREEMIUS_CHECKOUT_URL')) {
    define('AP_SAFECACHE_FREEMIUS_CHECKOUT_URL', 'https://checkout.freemius.com/app/27895/plan/46093/');
}

// → Freemius: Pro Single Store / Pro Multi Vendor それぞれのチェックアウト（未設定時は上記 CHECKOUT_URL にフォールバック）
if (!defined('AP_SAFECACHE_FREEMIUS_CHECKOUT_URL_PRO_SINGLE_STORE')) {
    define(
        'AP_SAFECACHE_FREEMIUS_CHECKOUT_URL_PRO_SINGLE_STORE',
        'https://checkout.freemius.com/app/27895/plan/46093/?trial=paid'
    );
}
if (!defined('AP_SAFECACHE_FREEMIUS_CHECKOUT_URL_PRO_MULTI_VENDOR')) {
    define(
        'AP_SAFECACHE_FREEMIUS_CHECKOUT_URL_PRO_MULTI_VENDOR',
        'https://checkout.freemius.com/app/27895/plan/46134/?trial=paid'
    );
}

// → Freemius: Customer Portal（customers.freemius.com のストア URL）
if (!defined('AP_SAFECACHE_FREEMIUS_CUSTOMER_PORTAL_URL')) {
    define('AP_SAFECACHE_FREEMIUS_CUSTOMER_PORTAL_URL', 'https://customers.freemius.com/store/12895/');
}

// → 自前ゲートのみ（Freemius 項目ではない）— Pro 操作トークン発行 URL（POST JSON）。空なら無効。
//    Node サービスは `/token` または `/downloads` に POST を受け付ける（cscart-ap-safecache）。
if (!defined('AP_SAFECACHE_LICENSE_ACTION_TOKEN_URL')) {
    define(
        'AP_SAFECACHE_LICENSE_ACTION_TOKEN_URL',
        'https://apps.andplus.tech/andplus-apps/cscart-ap-safecache/token'
    );
}

// → 自前ゲートのみ — Bearer 用（リテラル）。不要なら空
if (!defined('AP_SAFECACHE_LICENSE_ACTION_TOKEN_API_KEY')) {
    define('AP_SAFECACHE_LICENSE_ACTION_TOKEN_API_KEY', '9a00e776c4ff72948abb7fd4a582fa69');
}

// → 自前ゲートのみ — トークン既定 TTL 秒（応答に期限が無いとき）
if (!defined('AP_SAFECACHE_LICENSE_ACTION_TOKEN_DEFAULT_TTL')) {
    define('AP_SAFECACHE_LICENSE_ACTION_TOKEN_DEFAULT_TTL', 900);
}

// → 自前ゲートのみ — 本体アップデート互換判定 API（空なら token URL から推測）
if (!defined('AP_SAFECACHE_UPDATE_CHECK_URL')) {
    define('AP_SAFECACHE_UPDATE_CHECK_URL', '');
}

// → アドオン挙動 — manage GET 時の activate 再呼び出し最短間隔（Freemius ダッシュボード設定ではない）
if (!defined('AP_SAFECACHE_FREEMIUS_AUTO_SYNC_COOLDOWN_SEC')) {
    define('AP_SAFECACHE_FREEMIUS_AUTO_SYNC_COOLDOWN_SEC', 12 * 3600);
}
