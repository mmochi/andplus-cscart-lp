<?php
/***************************************************************************
 * ap_safecache — block_manager.render を CSRF 検証対象にする（POST のみ。
 * ストアフロントのブロック再取得は js の block_manager.render を GET で送る
 * （コア block_loader と同様）。POST で呼ぶクライアントは security_hash が必須。
 ***************************************************************************/

defined('BOOTSTRAP') or die('Access denied');

$schema['C']['controllers']['block_manager'] = [
    'validate' => false,
    'modes'    => [
        'render' => [
            'validate' => true,
        ],
    ],
];

return $schema;
