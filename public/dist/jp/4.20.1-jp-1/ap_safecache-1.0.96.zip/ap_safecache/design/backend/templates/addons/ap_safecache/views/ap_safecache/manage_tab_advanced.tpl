<div class="dashboard-row">
    <div>
        <div class="alert alert-warning" style="margin-bottom:16px;border:1px solid #e8d9a3;border-radius:4px;">
            <p><strong>{__("ap_safecache.alert_payment_ip_title")}</strong></p>
            <p>{__("ap_safecache.alert_payment_ip_body")}</p>
            <p class="muted">{__("ap_safecache.alert_payment_ip_core_note")}</p>
            <p class="muted">{__("ap_safecache.alert_payment_ip_footer")}</p>
            <p style="margin-top:10px;"><strong>{__("ap_safecache.alert_payment_ip_this_request")}</strong></p>
            <div class="table-responsive-wrapper">
                <table class="table table-middle table-condensed" style="max-width:720px;">
                    <tbody>
                        <tr>
                            <td width="28%" class="muted">REMOTE_ADDR</td>
                            <td><code>{$ap_safecache_payment_ip.remote_addr|escape}</code></td>
                        </tr>
                        {if $ap_safecache_payment_ip.cf_connecting_ip}
                            <tr>
                                <td class="muted">CF-Connecting-IP</td>
                                <td><code>{$ap_safecache_payment_ip.cf_connecting_ip|escape}</code></td>
                            </tr>
                        {/if}
                        {if $ap_safecache_payment_ip.true_client_ip}
                            <tr>
                                <td class="muted">True-Client-IP</td>
                                <td><code>{$ap_safecache_payment_ip.true_client_ip|escape}</code></td>
                            </tr>
                        {/if}
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="dashboard-row" id="ap-safecache-site" style="scroll-margin-top:72px;">
    <div>
        <div class="well" style="border:1px solid #dcdcdc;border-radius:4px;background:#fff;">
            <div style="padding:4px 16px 16px 16px;">
        {include file="common/subheader.tpl" title=__("ap_safecache.ui_group_site")}
        <p class="muted">{__("ap_safecache.ui_group_site_hint")}</p>

        {include file="common/subheader.tpl" title=__("ap_safecache.environment")}
        <div class="table-responsive-wrapper">
            <table class="table table-middle table--relative">
                <tbody>
                    <tr>
                        <td width="35%" class="muted">{__("ap_safecache.product_version")}</td>
                        <td>{$ap_safecache_env.product_version|escape}</td>
                    </tr>
                    <tr>
                        <td class="muted">{__("ap_safecache.product_edition")}</td>
                        <td>{$ap_safecache_env.product_edition|escape}</td>
                    </tr>
                    <tr>
                        <td class="muted">{__("ap_safecache.product_build")}</td>
                        <td>{$ap_safecache_env.product_build|escape}</td>
                    </tr>
                    <tr>
                        <td class="muted">{__("ap_safecache.storefront_count")}</td>
                        <td>{$ap_safecache_env.storefront_count|escape}</td>
                    </tr>
                    <tr>
                        <td class="muted">{__("ap_safecache.addon_version")}</td>
                        <td>
                            {if $ap_safecache_addon_version}
                                {$ap_safecache_addon_version|escape}
                            {else}
                                <span class="muted">—</span>
                            {/if}
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        {if $ap_safecache_env.storefront_count > 1}
            <div class="alert alert-warning">
                <p>{__("ap_safecache.multi_storefront_notice")}</p>
            </div>
        {/if}

        {include file="common/subheader.tpl" title=__("ap_safecache.ajax_reload_blocks")}
        <p class="muted">{__("ap_safecache.ajax_reload_blocks_intro")}</p>

        {if $ap_safecache_storefronts|@count > 1}
            <form action="{"ap_safecache.manage"|fn_url}" method="get" class="form-inline" style="margin-bottom: 10px;">
                <input type="hidden" name="safecache_tab" value="advanced" />
                <label class="muted" for="safecache_sf">{__("ap_safecache.storefront_for_picker")}</label>
                <select id="safecache_sf" name="safecache_sf" onchange="this.form.submit();">
                    {foreach from=$ap_safecache_storefronts item=sf}
                        <option value="{$sf.storefront_id}" {if $sf.storefront_id == $ap_safecache_picker_storefront_id}selected="selected"{/if}>{$sf.label|escape}</option>
                    {/foreach}
                </select>
            </form>
        {/if}

        <form action="{""|fn_url}" method="post" name="ap_safecache_ajax_blocks_form">
            <div class="ap-safecache-ajax-blocks-picker" style="max-height: 280px; overflow-y: auto; width: 100%; max-width: 48rem; border: 1px solid #dcdcdc; border-radius: 4px; padding: 8px 12px; background-color: #fafafa;">
                {foreach from=$ap_safecache_blocks_picker item=b}
                    <div class="checkbox" style="margin-top: 4px; margin-bottom: 4px;">
                        <label>
                            <input type="checkbox" name="ap_safecache_ajax_block_ids[]" value="{$b.block_id}"{if $b.ap_checked} checked="checked"{/if} />
                            {$b.label|escape}
                        </label>
                    </div>
                {/foreach}
            </div>
            <p class="muted" style="margin-top: 8px;">{__("ap_safecache.ajax_reload_blocks_hint")}</p>

            <p class="muted" style="margin-top: 16px;"><strong>{__("ap_safecache.ajax_reload_dom_ids_manage_site")}</strong></p>
            <p class="muted">{__("ap_safecache.ajax_reload_dom_ids_manage_intro")}</p>
            <textarea
                name="ap_safecache_ajax_reload_dom_ids"
                rows="5"
                class="input-large"
                style="width: 100%; max-width: 48rem; font-family: Consolas, Menlo, Monaco, monospace; font-size: 12px;"
            >{$ap_safecache_ajax_reload_dom_ids_text|escape}</textarea>
            <p class="muted" style="margin-top: 6px;">{__("ap_safecache.ajax_reload_dom_ids_manage_hint")}</p>

            <div style="margin-top: 8px;">
                {include file="buttons/button.tpl"
                    but_role="submit"
                    but_meta="btn btn-primary"
                    but_name="dispatch[ap_safecache.save_ajax_reload_blocks]"
                    but_text=__("ap_safecache.btn_save_ajax_reload_blocks")
                }
            </div>
        </form>
            </div>
        </div>
    </div>
</div>
