# ap_safecache — 開発メモ（実装状況・保留）

基準: `addon.xml` の `<version>`（コード上の正）。**現行の挙動・設定・フックの詳細**は `実装仕様_現行.md` を参照。本ファイルは保留事項・設計メモ・運用注意が中心。

---

## 1. 実装済み（概要）

### アドオン設定

- 推奨ルール API ベース URL、Cloudflare Zone ID / API トークン
- Ajax 再読み込み対象ブロック ID（textarea）、ブロック再取得ログ（checkbox）
- Client IP（Cloudflare）: `REMOTE_ADDR` を CF ヘッダに合わせる（checkbox、§5）

### ストアフロント

- `dispatch_before_display` で `block_manager.render` 用の JSON を注入（`hooks/index/scripts.post.tpl`）
- `js/addons/ap_safecache/func.js`: 指定ブロックの DOM 差し替え。**初回**は設定により **Lazy（IntersectionObserver）** または従来のデバウンス一括（`scheduleReloadBlocks`）。**`cm-ajax` 完了後**は従来どおり全ブロックをデバウンス後一括。**1.0.34** で `products.options` による一覧向け `cm-reload` 一括は削除済み（§10）；商品詳細の `products.options` は継続（§11）
- `block_manager.render` を **POST** + `security_hash`（`schemas/security/csrf_validation.post.php`）
- 外部/インライン script 周りの補強（`always`、キャッシュバスト、`globalEval` 等）
- オプションで `var/log/ap_safecache_ajax_block_reload.log` へ JSON 1 行ログ（JST タイムスタンプ）、フロント `block_manager.pre.php` で render 追跡

### 管理画面（`ap_safecache.manage`）

- Cloudflare / 推奨 API の接続確認
- Page Rules / Cache Rules（Rulesets）の取得・編集・反映・バックアップ（**WAF 系は非対象** — `cloudflare_rules.php` コメント参照）
- 推奨 Cache Rules 生成（`cf_cache_recommendations.php`）
- キャッシュパージ、Ajax ブロックピッカー、レイアウトからブロック登録導線
- 決済 IP 登録 × Cloudflare の注意（`REMOTE_ADDR` / CF ヘッダ表示）。**オプションで `REMOTE_ADDR` 補正**（§5）。**コア同梱の決済 PHP は注意書きのみ**（個別対応は利用者側）

### フック

- `init.php`: `dispatch_before_display`、`get_route`（`REMOTE_ADDR` の CF 補正オプション。§5 参照）、`before_dispatch`（店頭 `block_manager.render` で XHR でない GET をリダイレクト、`Tygh::$app['ajax']` 未登録時の補完。コア `block_manager.pre.php` は変更しない）。`fn_ap_safecache_get_route_runtime` は空実装のまま（旧フックキャッシュ用）。現行 `init` では `get_route_runtime` は未登録。

---

## 2. 未実装・対象外

| 項目 | 内容 |
|------|------|
| **本アドオンのライセンス認証** | **`license_tier`**（`free` / `pro`）と **`lib/ap_safecache_freemius.php`** による同期（`activate.json`）が実装済み。`fn_ap_safecache_is_extension_licensed()` は **`fn_ap_safecache_is_pro()` と同義**（常に true ではない）。**Webhook／定期ポール** 等の自動失効は **任意・未**（`実装仕様_現行.md` §14.4・§15）。**製品方針**は **`Freemius_製品構成.md`**。 |
| **WAF** | Cloudflare WAF の設定・API は扱わない。 |
| **REMOTE_ADDR の自動書き換え** | **オプションで実装あり**（`get_route`＋`lib/ap_safecache_remote_addr.php`、設定で OFF 可）。**信頼境界は Cloudflare 公開エッジ CIDR 埋め込み**のため、**公式レンジは時折確認**（下記 §5「レンジのメンテナンス」）。 |
| **コア同梱の決済スクリプト**（例: `app/payments/pay_read.php` の着信 IP 検証） | **本アドオンではコアを書き換えない**。ドキュメント／画面の**注意書き**で伝え、**利用者側でインフラ or 個別改修**に委ねる（§5「コア同梱」参照）。 |

---

## 3. 保留（旧メモの整理）

### 「初回ブロック更新を設定で ON/OFF」（保留）

- **案**: 初回一括再取得を設定で無効化するモード。
- **状況**: **未着手**。現状は初回から `scheduleReloadBlocks()` が走るため、「OFF にしたい」要件が出たら設計する。

※ 以前のメモに「初回再取得はしていない」とあったが、**現行 `func.js` では初回も実行済み**。古い記述は無効。

---

## 10. エッジ HTML キャッシュ × 価格・セッション（設計メモ・2026）

### 課題の整理

- Cloudflare 等で **店頭 HTML をキャッシュ**すると、**別セッションで生成された `security_hash`・価格・ヘッダ・ミニカート**が混ざる。
- **ブロック単位の再取得**（`block_manager.render`）だけでは、**商品ブロック内の `cm-reload-{obj}`**（価格・在庫・ラベル）がレイアウトブロックに含まれない／一覧は商品数が多い、などで **不足しうる**。

### 採用方針（実装の意図）

1. **`AP_SAFECACHE_AJAX_RELOAD_BLOCKS` のみ** — `block_manager.render` で **レイアウトブロック**を再取得（ヘッダ・カート・会員メニュー等）。`hidden: true` の Ajax のため Tygh の全画面ローディングは出さない。
2. **~~`cm-reload-*` を `products.options` で一括再取得~~（撤去）** — **1.0.34** で削除。一覧の **商品数 × Ajax** が重く、ユーザー操作とも干渉しやすかったため。商品ブロック内の `cm-reload` がレイアウトブロックに含まれない場合の整合は、**エッジで HTML を載せない**・**パージ設計**・**コアのオプション変更時の既存 Ajax** など別経路で検討する。

### CDN 全バイパスとの関係

- **HTML をエッジに載せない**運用は**別解**。本節は **「キャッシュした殻 ＋ セッション付き断片」** で整合させる線。

### 関連ファイル（履歴）

- ~~`ajax_reload_product_options` 設定~~ — 1.0.34 で `addon.xml` から削除
- `js/tygh/exceptions.js`（コア）— オプション変更時の `fn_change_options` は従来どおり（本アドオンからの自動呼び出しはしない）

---

## 11. エッジ共用キャッシュ × 動的更新 — 採用方針（試行順・2026）

### 合意した試行順序

1. **既存の `ajax_reload_block_ids` → `block_manager.render`** によるレイアウトブロック再生成は**そのまま活かす**。
2. **メインコンテンツ**もカバーするなら、同設定に **メイン領域のブロック ID を追加**する（ブロック内の `cm-reload` 含む HTML は、当該ブロック再レンダでまとめて更新される）。
3. **初回の同時再取得が重い**場合は **Lazy** とする。**Intersection Observer** で **viewport ＋ 上下マージン（`func.js` 定数 `AP_SAFECACHE_LAZY_LAYOUT_ROOT_MARGIN`、既定 `200px 0px 200px 0px`）** に入るまで `block_manager.render` を遅延。**管理画面** `lazy_reload_layout_blocks`（既定 ON）／**店頭** `window.AP_SAFECACHE_LAZY_RELOAD_LAYOUT_BLOCKS`。**`ce.ajaxdone` 後**の再読み込みは従来どおり **デバウンス後に全対象ブロック一括**（カート・ヘッダの即時性）。ローディング画像は `hidden: true` のまま。
4. **Cloudflare の「ログイン時 DYNAMIC / 非ログイン HIT」**の細かい Cache Rules は**一旦棚上げ**（専用 Cookie や URL ルールは後追いで可）。

### 将来メモ（未実装）

- 一覧などで **`block_manager.render` × N** がまだ重い場合は **商品 ID 一括 JSON** で価格・ラベルだけ差し替えする余地あり（別 dispatch／アドオン拡張）。
- **ブロックに含まれない `cm-reload` だけ**を列挙再取得する必要が出たらテーマ依存が強いため、設計を分ける。

### 1.0.37 で入ったもの

- `func.php`: `fn_ap_safecache_lazy_reload_layout_blocks_enabled`
- `hooks/index/scripts.post.tpl`: `AP_SAFECACHE_LAZY_RELOAD_LAYOUT_BLOCKS`
- `func.js`: `reloadLayoutBlockWhenVisible` / `scheduleInitialLayoutBlocks`

### 1.0.38 / 1.0.39（func.js）

- **1.0.38**: `AP_SAFECACHE_LAZY_RELOAD_LAYOUT_BLOCKS` が `undefined` のとき Lazy 相当（`!== false`）。
- **1.0.39**: `ce.ajaxdone` でのブロック再取得条件に **`isAuthSessionAjaxForm` を追加**（ヘッダログインが `cm-ajax` 無しでも一覧ブロックを再取得しうる）。**検索・一覧の商品グリッドを含むブロック ID は `ajax_reload_block_ids` に登録が前提**。

---

## 4. CS-Cart 本体のライセンス認証（調査メモ）

**本アドオンとは別**。コアは **CS-Cart 社の更新サーバ**と XML 連携する。

- 中核クラス: `app/Tygh/Helpdesk.php`
- `Helpdesk::getLicenseInformation()` が `Upgrade_center.license_number` 等を載せた XML を組み立て、`Request@action=check_license@api=3` として **`Registry::get('config.resources.updates_server')`**（設定の更新サーバ URL）へ `product_updates.check_available` 経由で送信する。
- 応答を `Helpdesk::parseLicenseInformation()` が XML パースし、`store_mode` / `plan` / ストア数制限 / `restrictions` 等を **ストレージ**（`fn_set_storage_data`）や設定に反映する。
- 管理画面初期化では `license_errors` 等がテンプレートに渡る（`app/controllers/backend/init.php` 付近）。

つまり **製品ライセンスは「ローカルにキーを保存 + 更新サーバへのチェック」**で運用され、**サードパーティアドオン（ap_safecache）のライセンスとは機構が別**。

---

## 5. 実 IP 自動復元（考え方メモ）

Cloudflare などのプロキシの直後では、`$_SERVER['REMOTE_ADDR']` が **クライアント実 IP ではなくエッジ IP** になる。`jp_extras` 配下の決済コールバック（SBPS の `result.php` 型）や、`preg_match(..., $_SERVER['REMOTE_ADDR'])` で **事業者側 IP を許可リスト照合**している実装は、**未補正のままだと照合失敗**しうる。

### 目的

- **`REMOTE_ADDR` を「接続元として期待される IP」に揃える**（典型: 決済ゲートウェイからのコールバック IP）。
- **`jp_extras` 内のサンプル PHP を個別改修しなくても**済むようにする（共通処理に寄せる）。

### 代表的な手段（優先度は運用に合わせて選択）

1. **Web サーバ / リバースプロキシ（推奨しやすい）**  
   Nginx: `set_real_ip_from`（Cloudflare 公式 IP レンジ）＋ `real_ip_header CF-Connecting-IP` 等。Apache: `mod_remoteip` 等。  
   **PHP に入る前に** `REMOTE_ADDR` が実接続元に近い値になる。アプリ横断で一貫する。

2. **`config.local.php` などの極早い PHP**  
   `init.php` の `Bootstrap::initEnv` より後、`fn_set_hook` より前でも実行可能な require で、`$_SERVER['REMOTE_ADDR']` を上書き。  
   **信頼条件**（直前の TCP 接続元が CF エッジであること等）を誤ると **IP 偽装リスク**があるため、条件を明文化すること。

3. **CS-Cart の hook（アドオン実装向け）**  
   ルート `init.php` に **`fn_set_hook` はない**。`fn_init()` にもラッパー用 hook はない。  
   標準アドオンが `init.php` でフック登録したあとで動く **比較的早期**の例: `fn.control.php` の **`get_route` / `get_route_runtime`**（`fn_init_addons` 実行後、`fn_get_route` 内）。  
   `jp_extras` が `require init.php` したあと独自コードが走るまでに、`fn_init()` が完了するため、**この系の hook 内で `REMOTE_ADDR` を直せば** `jp_extras` の `preg_match` より前に反映できる。

4. **`auto_prepend_file`（php.ini / vhost）**  
   `jp_extras` を触らず、起動時に必ず読むスクリプトで同様の補正。インフラ依存が強い。

### 信頼境界（必ず設計に含める）

- **`HTTP_CF_CONNECTING_IP` / `X-Forwarded-For` は無条件に信頼しない**。  
  オレンジクラウドで CF 経由に限定する、**直結 IP が CF 公開レンジか**を確認する、など方針を決める。
- 目的が **決済コールバックの「事業者 IP」** のときは、**顧客ブラウザの実 IP** ではなく **SBPS 等のサーバ IP** が `REMOTE_ADDR` に見える必要がある（CF 経路では **CF ではなく相手側の出元**が見えるかはネットワーク次第。オリジン手前で CF なら `CF-Connecting-IP` は **その接続のクライアント**＝多くは **CF エッジ**になり、**SBPS 実 IP と一致しない**）。  
  → **インフラで real IP を直す**か、**事業者が提示する許可リストと「自分のサーバが見る接続元」の定義**を一致させる必要がある（ここは決済ごとに要確認）。

### コア同梱（`app/payments` 等）に書いてあるもの

- CS-Cart 本体に含まれる決済スクリプト（例: Pay&Read の `app/payments/pay_read.php` で `REMOTE_ADDR` と固定 IP リストを照合）は、**アップデートで上書きされる**ため、**本アドオンからコアを修正・ラップしない**。
- 運用方針: **注意書き**（管理画面の説明文・この MEMO・必要なら利用マニュアル）で「Cloudflare 直結時は `REMOTE_ADDR` がエッジになり得る／インフラの real IP 設定や個別検討が必要」と伝え、**個別対応は導入側・保守担当に委ねる**。
- `jp_extras` 配下は別リポジトリ／配布物のサンプルであり、同様に **本アドオンが一括修正の対象にしない**（§5 前半の共通手段は「導入側が選ぶ」位置づけ）。

### 本アドオン（ap_safecache）との関係

- 管理画面の「決済 IP × Cloudflare」は **注意喚起**に加え、アドオン設定で **オプションの `REMOTE_ADDR` 補正**を有効化できる（§2 表・`lib/ap_safecache_remote_addr.php`）。
- インフラ側の real IP 設定（Nginx `real_ip` 等）と **併用・代替のどちらにするか**は運用で決める。

### Cloudflare 公開エッジ IP レンジのメンテナンス（要・時折確認）

- 公式レンジは **頻繁には変わらないが、追加・変更はあり得る**。変更のたびに **必ずメール等で通知が届くとは限らない**（正は公式一覧および API。開発者向け [IP range updates](https://developers.cloudflare.com/fundamentals/concepts/cloudflare-ip-addresses/#ip-range-updates) の説明参照）。
- **運用**: `https://www.cloudflare.com/ips-v4` と `https://www.cloudflare.com/ips-v6`（または同等 API）を **時折確認**し、`lib/ap_safecache_remote_addr.php` 内の CIDR 定数と **差分がないか突き合わせる**。差分があれば **定数を更新**してデプロイする。

---

## 6. 参照ファイル（主）

- `func.php` — ログ・環境・Ajax ブロック解決・`dispatch_before_display`・`get_route`（REMOTE_ADDR 補正）
- `lib/ap_safecache_remote_addr.php` — Cloudflare エッジ CIDR 判定と `REMOTE_ADDR` 補正
- `cloudflare_rules.php` — CF Rules API
- `cf_cache_recommendations.php` — 推奨ルール JSON
- `js/addons/ap_safecache/func.js` — 店頭ブロック再取得
- `schemas/security/csrf_validation.post.php` — `block_manager.render` の CSRF
- `tests/` — PHPUnit（`lib/ap_safecache_remote_addr.php` のスモーク。§7）

---

## 7. 自動テスト（PHPUnit）

**目的**: CS-Cart を起動せず、`REMOTE_ADDR` 補正の CIDR 判定・ヘッダ解析・置換の境界だけを高速に確認する。

**配置**: `app/addons/ap_safecache/tests/`（`bootstrap.php` で `BOOTSTRAP` を定義してから `lib/ap_safecache_remote_addr.php` を読み込む）

**実行例**（PHPUnit 9 系が PATH にある前提）:

```bash
cd app/addons/ap_safecache/tests
phpunit -c phpunit.xml
```

**前提**: 開発環境に `phpunit/phpunit`（Composer）またはグローバル `phpunit` が必要。コア本体の `vendor/bin/phpunit` を使う場合は、上記 `tests` をカレントにして `-c phpunit.xml` を指定する。

**範囲**: 現状は `RemoteAddrTest.php` のみ。Cloudflare API や管理画面 UI は対象外（手動または別ツール）。

---

## 8. 製品方針（Free / Pro・MV・複数ドメイン）

※ 実装は未着手。販売・ライセンス（Freemius 等）設計のメモ。

### Free / Pro の線引き（案・確定ではない）

| 層 | 内容 |
|----|------|
| **Free** | **読み取り**（Cloudflare からの取得・表示など）と **教育**（注意事項、手動運用のガイド、診断表示）。 |
| **Pro** | **ルール生成・挿入・更新**、**ロールバック**、**IP 補正**（`REMOTE_ADDR` / `get_route` 系）など、書き込みと運用に直結する機能。 |

意図: Free だけでも「手動で Cloudflare を触れる」余地は残るが、**アドオン経由で安全に・繰り返し触る価値**は Pro に寄せ、課金理由を説明しやすくする。

### Multi-Vendor（単一ドメインのマーケットプレイス想定）

- ベンダーごとのゾーン分離までは**要件にしない**（管理者・単一ゾーンで十分なことが多い）。
- **ライセンス価格を上げる**（例: 同一 Pro 機能でも **おおよそ倍** など）で、サポート・検証コストを反映するのは一般的なパターン。**実装を倍にしなくてもよい**。

### 複数ドメイン / Ultimate 複数ストアフロント

- **標準パッケージの対象外**とし、**個別対応**（別プラン・別見積もり・問い合わせ制）。Cloudflare ゾーンやパージの単位が絡み、工数と要件が割れやすいため。

### Freemius 等

- プランは **Free / Pro** を前提に、`can_use_premium_code()` 相当で **書き込み系・IP 補正**をゲート。MV 用は **別商品 ID または高価格プラン**で対応しうる。

---

## 9. 価格の考え方（妥当レンジの出し方）

**ここでは金額を断定しない。** 為替・販売チャネル・サポート方針で変わる。決めるときの**軸**だけ残す。

1. **市場調査**: CS-Cart 系サードパーティアドオンの **想定価格帯**（一回買い切り / 年更新）をいくつかサンプルで見る。
2. **サポート原価**: 想定チケット数 × 1 件あたり対応時間 × 時間単価。Pro は CF 触るため **問い合わせが Free より増えやすい**前提でバッファ。
3. **代替コスト**: 運用者が自分で CF を触る場合の **時給換算**と比較し、「年間この金額なら安い」と言えるか。
4. **MV 倍率**: 「約倍」は**慣習レベル**であり、自社のサポート想定に合わせて調整する。
5. **複数ドメイン**: 個別見積もりの場合、**工数ベース**または **Ult 向けライセンスの定価を別表**で持つ。

具体的な円ドルは、上記を踏まえたうえで **Freemius の価格実験**や **初期顧客へのヒアリング**で決めるのが安全。
