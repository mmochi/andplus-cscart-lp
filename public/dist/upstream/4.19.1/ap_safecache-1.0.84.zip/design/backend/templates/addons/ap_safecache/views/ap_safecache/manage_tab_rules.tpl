<div class="dashboard-row">
    <div>
        {include file="common/subheader.tpl" title=__("ap_safecache.ui_group_cloudflare_rules")}
        <p class="muted">{if $ap_safecache_license_is_pro|default:true}{__("ap_safecache.cf_section_edition_hint_pro")}{else}{__("ap_safecache.cf_section_edition_hint_free")}{/if}</p>
        <p class="muted">{__("ap_safecache.cf_rules_intro")}</p>
        <p class="muted">{__("ap_safecache.cf_rules_workflow")}</p>

        {if !($ap_safecache_license_is_pro|default:true)}
        <div class="alert alert-warning" style="margin-top:12px;margin-bottom:0;">
            <p style="margin:0;"><strong>{__("ap_safecache.license_free_cf_scope_title")}</strong></p>
            <p class="muted" style="margin:8px 0 0 0;font-size:12px;line-height:1.55;margin-bottom:0;">{__("ap_safecache.license_free_cf_scope_body")}</p>
        </div>
        <div class="alert" style="margin-top:12px;margin-bottom:0;border-left:4px solid #5cb85c;background:#f6fff8;padding:12px 14px;">
            <p style="margin:0 0 8px 0;font-size:13px;line-height:1.45;"><strong>{__("ap_safecache.license_pro_rules_value_title")}</strong></p>
            <ul style="margin:0;padding-left:1.35em;font-size:12px;line-height:1.55;">
                <li style="margin-bottom:6px;">{__("ap_safecache.license_pro_rules_value_li1")}</li>
                <li style="margin-bottom:6px;">{__("ap_safecache.license_pro_rules_value_li2")}</li>
                <li style="margin-bottom:6px;">{__("ap_safecache.license_pro_rules_value_li3")}</li>
                <li style="margin-bottom:6px;">{__("ap_safecache.license_pro_rules_value_li4")}</li>
                <li>{__("ap_safecache.license_pro_rules_value_li5")}</li>
            </ul>
            <p class="muted" style="margin:10px 0 0 0;font-size:11px;line-height:1.5;">{__("ap_safecache.license_pro_rules_value_free_reminder")}</p>
        </div>
        {/if}

        <div id="ap-safecache-cf-sync" class="well" style="margin-top:14px;border-left:4px solid #5bc0de;padding:12px 14px;background:#f9fcfd;scroll-margin-top:72px;">
            <p style="margin:0 0 6px 0;"><strong>{__("ap_safecache.cf_sync_section_title")}</strong></p>
            <p class="muted" style="font-size:12px;line-height:1.55;margin-bottom:10px;">{__("ap_safecache.cf_sync_hint")}</p>
            <form action="{""|fn_url}" method="post" style="display:inline;">
                {include file="buttons/button.tpl"
                    but_role="submit"
                    but_meta="btn btn-default"
                    is_btn_primary=false
                    but_name="dispatch[ap_safecache.cf_fetch_rules]"
                    but_text=__("ap_safecache.cf_btn_fetch")
                }
            </form>
            <p class="muted" style="font-size:11px;line-height:1.5;margin-top:8px;margin-bottom:0;">{__("ap_safecache.cf_btn_fetch_caption")}</p>
            {if $ap_safecache_cf_fetched_at}
                <p class="muted" style="margin-top:10px;margin-bottom:0;">{__("ap_safecache.cf_fetched_at", ["[time]" => $ap_safecache_cf_fetched_at|date_format:"%Y-%m-%d %H:%M"])}</p>
            {else}
                <p class="muted" style="margin-top:10px;margin-bottom:0;">{__("ap_safecache.cf_not_fetched")}</p>
            {/if}
        </div>

        <div id="ap-safecache-rules-poll-snapshot" class="well" style="margin-top:14px;border-left:4px solid {if $ap_safecache_cf_poll_display.card_tone == 'success'}#5cb85c{elseif $ap_safecache_cf_poll_display.card_tone == 'warning'}#f0ad4e{elseif $ap_safecache_cf_poll_display.card_tone == 'danger'}#d9534f{else}#6c757d{/if};padding:12px 14px;background:#fafafa;scroll-margin-top:72px;">
            <p style="margin:0 0 8px 0;font-size:13px;line-height:1.5;">
                {if $ap_safecache_cf_poll_display.status_code == 'none'}
                    <span class="muted">{__("ap_safecache.cf_poll_never")}</span>
                {else}
                    <strong>{__("ap_safecache.cf_poll_card_headline")}</strong> {$ap_safecache_cf_poll_display.status_label|escape}
                    {if $ap_safecache_cf_poll_display.last_success_at}
                        <span class="muted" style="margin-left:6px;">({__("ap_safecache.cf_poll_disp_last_success", ["[time]" => $ap_safecache_cf_poll_display.last_success_at|date_format:"%Y-%m-%d %H:%M"])})</span>
                    {/if}
                {/if}
            </p>
            <p class="muted" style="margin:0 0 10px 0;font-size:12px;line-height:1.45;">{__("ap_safecache.cf_rules_tab_status_note")}</p>
            <a href="{$ap_safecache_manage_tab_urls.monitor|fn_url}#ap-safecache-cf-poll" class="btn btn-default btn-sm">{__("ap_safecache.manage_tab_monitor")}</a>
        </div>

        <div id="ap-safecache-cf-recommended" class="well" style="margin-top:18px;border:1px solid #dcdcdc;border-radius:4px;background:#fff;scroll-margin-top:72px;">
            <div style="padding:4px 4px 8px 4px;">
            <!-- ap_safecache: recommended rules UI v2 (flex cards, pre without broken font-family quotes) -->
            {include file="common/subheader.tpl" title=__("ap_safecache.cf_rec_section")}
            <p class="muted">{__("ap_safecache.cf_rec_intro")}</p>
            <p class="muted">{__("ap_safecache.cf_rec_cards_hint")}</p>
            {if $ap_safecache_cf_recommended.rows}
                <div class="ap-safecache-cf-rec-cards" style="width:100%;max-width:100%;box-sizing:border-box;margin-top:12px;">
                    {foreach from=$ap_safecache_cf_recommended.rows item=rr}
                        <div class="well well-small" style="margin-bottom:14px;width:100%;max-width:100%;box-sizing:border-box;overflow:hidden;">
                            <div style="display:flex;align-items:flex-start;gap:10px 12px;width:100%;box-sizing:border-box;margin-bottom:8px;">
                                <div style="flex-shrink:0;padding-top:1px;">
                                    <span class="badge badge-info">{$rr.order|escape}</span>
                                </div>
                                <div style="flex:1;min-width:0;">
                                    <strong style="font-size:14px;display:block;">{$rr.title|escape}</strong>
                                    <div class="muted" style="margin-top:6px;font-size:12px;line-height:1.45;">{$rr.hint|escape}</div>
                                    <div style="margin-top:8px;width:100%;box-sizing:border-box;">
                                        <span class="muted" style="font-size:10px;text-transform:uppercase;letter-spacing:0.04em;display:block;margin-bottom:4px;">{__("ap_safecache.cf_rec_col_action")}</span>
                                        <code style="display:block;box-sizing:border-box;width:100%;margin:0;padding:8px 10px;font-size:11px;line-height:1.45;word-break:break-word;overflow-wrap:anywhere;white-space:pre-wrap;background:#f7f7f7;border:1px solid #e5e5e5;border-radius:3px;font-family:Consolas,Menlo,Monaco,monospace;">{$rr.action|escape}</code>
                                    </div>
                                </div>
                            </div>
                            <div style="margin-bottom:12px;padding-bottom:10px;border-bottom:1px solid #e8e8e8;">
                                <span class="muted" style="font-size:11px;text-transform:uppercase;letter-spacing:0.03em;">{__("ap_safecache.cf_rec_col_source")}</span>
                                <div style="margin-top:4px;font-size:12px;word-break:break-word;">
                                    <span class="muted">{$rr.source_label|escape}</span>
                                    {if $rr.source_value}
                                        <div style="margin-top:4px;">{$rr.source_value|escape}</div>
                                    {/if}
                                </div>
                            </div>
                            <div>
                                <span class="muted" style="font-size:11px;text-transform:uppercase;letter-spacing:0.03em;">{__("ap_safecache.cf_rec_col_expression")}</span>
                                <div style="margin-top:6px;width:100%;max-width:100%;overflow-x:auto;overflow-y:hidden;-webkit-overflow-scrolling:touch;box-sizing:border-box;border:1px solid #d8d8d8;border-radius:4px;background:#fff;">
                                    <pre style="margin:0;padding:10px 12px;font-size:12px;line-height:1.5;white-space:pre-wrap;word-wrap:break-word;word-break:break-word;overflow-wrap:anywhere;max-width:100%;box-sizing:border-box;font-family:Consolas,Menlo,Monaco,monospace;">{$rr.expression|escape}</pre>
                                </div>
                            </div>
                        </div>
                    {/foreach}
                </div>
                <p class="muted" style="margin-top:14px;">{__("ap_safecache.cf_rec_json_label")}</p>
                <div style="width:100%;max-width:100%;overflow-x:auto;box-sizing:border-box;border:1px solid #e0e0e0;border-radius:4px;background:#fafafa;">
                    <pre style="white-space:pre-wrap;word-break:break-word;overflow-wrap:anywhere;margin:0;padding:10px 12px;max-height:18rem;overflow:auto;font-size:11px;line-height:1.45;box-sizing:border-box;max-width:100%;font-family:Consolas,Menlo,Monaco,monospace;">{$ap_safecache_cf_recommended.json_rules|escape}</pre>
                </div>
                <div style="margin-top:12px;">
                    {if $ap_safecache_cf_fetched_at}
                        {if $ap_safecache_license_is_pro|default:true}
                        <form action="{""|fn_url}" method="post" style="display:inline-block;vertical-align:top;">
                            {include file="buttons/button.tpl"
                                but_role="submit"
                                but_meta="btn btn-success"
                                is_btn_primary=false
                                but_name="dispatch[ap_safecache.cf_append_recommended_cache_rules]"
                                but_text=__("ap_safecache.cf_btn_append_recommended")
                                but_confirm_text=__("ap_safecache.cf_confirm_append_recommended")
                            }
                        </form>
                        <p class="muted" style="font-size:11px;line-height:1.5;margin-top:6px;max-width:48rem;">{__("ap_safecache.cf_btn_append_caption")}</p>
                        {else}
                        <p class="muted" style="font-size:12px;line-height:1.5;margin:0;max-width:48rem;">{__("ap_safecache.license_pro_feature_note")}</p>
                        {/if}
                    {else}
                        <p class="muted">{__("ap_safecache.cf_rec_append_requires_fetch")}</p>
                    {/if}
                </div>
            {/if}
            </div>
        </div>

        <div id="ap-safecache-cf-editor" class="well" style="margin-top:20px;border:2px solid #c5c5c5;padding:14px 16px;background:#fafafa;scroll-margin-top:72px;">
            <p style="margin:0 0 4px 0;"><strong>{__("ap_safecache.cf_editor_section_title")}</strong></p>
            <p class="muted" style="font-size:12px;line-height:1.55;margin-bottom:12px;">{__("ap_safecache.cf_editor_hint")}</p>

            {if $ap_safecache_cf_diff_flash}
                <div class="well well-small" style="margin: 0 0 14px 0; background:#fff;">
                    <p class="muted" style="margin-bottom:10px;">{__("ap_safecache.cf_diff_intro")}</p>
                    <p><strong>{__("ap_safecache.cf_diff_page_rules")}</strong></p>
                    <pre style="white-space:pre-wrap;max-height:12rem;overflow:auto;">{$ap_safecache_cf_diff_flash.page_summary|escape}</pre>
                    <p style="margin-top:10px;"><strong>{__("ap_safecache.cf_diff_cache_rules")}</strong></p>
                    <pre style="white-space:pre-wrap;max-height:12rem;overflow:auto;">{$ap_safecache_cf_diff_flash.cache_summary|escape}</pre>
                </div>
            {/if}

            <form action="{""|fn_url}" method="post" name="ap_safecache_cf_rules_form">
                <details class="ap-safecache-manage-fold" style="margin-bottom:12px;border:1px solid #c5c5c5;border-radius:4px;background:#fff;"{if $ap_safecache_cf_diff_flash} open="open"{/if}>
                    <summary>{__("ap_safecache.manage_fold_json_edit")}</summary>
                    <div style="padding:12px 14px;border-top:1px solid #e0e0e0;">
                <p><strong>{__("ap_safecache.cf_label_page_rules")}</strong></p>
                <textarea name="ap_safecache_cf_page_rules_json" rows="10" cols="80" class="input-textarea-long" style="width:100%;max-width:56rem;font-family:monospace;font-size:12px;">{$ap_safecache_cf_page_rules_json|escape}</textarea>

                <p id="ap-safecache-cf-cache-rules-anchor" style="margin-top:14px;scroll-margin-top:72px;"><strong>{__("ap_safecache.cf_label_cache_ruleset")}</strong></p>
                <textarea name="ap_safecache_cf_cache_ruleset_json" rows="14" cols="80" class="input-textarea-long" style="width:100%;max-width:56rem;font-family:monospace;font-size:12px;">{$ap_safecache_cf_cache_ruleset_json|escape}</textarea>
                    </div>
                </details>

                <div style="margin-top:12px;">
                    <p class="muted" style="margin:0 0 6px 0;font-size:11px;line-height:1.45;">{__("ap_safecache.cf_editor_diff_row_hint")}</p>
                    <div class="btn-toolbar" style="margin-bottom:0;">
                        {include file="buttons/button.tpl"
                            but_role="submit"
                            but_meta="btn"
                            is_btn_primary=false
                            but_name="dispatch[ap_safecache.cf_show_diff]"
                            but_text=__("ap_safecache.cf_btn_diff")
                        }
                    </div>
                    {if $ap_safecache_license_is_pro|default:true}
                    <p class="muted" style="margin:12px 0 6px 0;font-size:11px;line-height:1.45;">{__("ap_safecache.cf_editor_apply_row_hint")}</p>
                    <div class="btn-toolbar" style="margin-bottom:0;">
                        {include file="buttons/button.tpl"
                            but_role="submit"
                            but_meta="btn btn-primary"
                            but_name="dispatch[ap_safecache.cf_apply_page_rules]"
                            but_text=__("ap_safecache.cf_btn_apply_page")
                            but_confirm_text=__("ap_safecache.cf_confirm_apply_page")
                        }
                        {include file="buttons/button.tpl"
                            but_role="submit"
                            but_meta="btn btn-primary"
                            is_btn_primary=false
                            but_name="dispatch[ap_safecache.cf_apply_cache_rules]"
                            but_text=__("ap_safecache.cf_btn_apply_cache")
                            but_confirm_text=__("ap_safecache.cf_confirm_apply_cache")
                        }
                    </div>
                    {else}
                    <p class="muted" style="margin:12px 0 6px 0;font-size:11px;line-height:1.45;">{__("ap_safecache.cf_editor_apply_row_hint")}</p>
                    <p class="muted" style="margin:0;font-size:12px;line-height:1.55;">{__("ap_safecache.cf_apply_requires_pro_note")}</p>
                    {/if}
                </div>
                <p class="muted" style="font-size:11px;line-height:1.5;margin-top:10px;">{__("ap_safecache.cf_editor_actions_caption")}</p>
            </form>
        </div>
    </div>
</div>
