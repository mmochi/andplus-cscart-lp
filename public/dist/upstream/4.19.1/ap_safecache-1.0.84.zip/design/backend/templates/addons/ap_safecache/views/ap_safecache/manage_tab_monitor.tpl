<div class="dashboard-row">
    <div>
        {include file="common/subheader.tpl" title=__("ap_safecache.manage_tab_monitor")}

        <div id="ap-safecache-cf-poll" class="well" style="margin-top:14px;border-left:4px solid {if $ap_safecache_cf_poll_display.card_tone == 'success'}#5cb85c{elseif $ap_safecache_cf_poll_display.card_tone == 'warning'}#f0ad4e{elseif $ap_safecache_cf_poll_display.card_tone == 'danger'}#d9534f{else}#6c757d{/if};padding:12px 14px;background:#fafafa;scroll-margin-top:72px;">
            <p style="margin:0 0 6px 0;"><strong>{__("ap_safecache.cf_poll_section_title")}</strong></p>
            <p class="muted" style="font-size:12px;line-height:1.55;margin-bottom:10px;">{__("ap_safecache.cf_poll_hint")}</p>
            <form action="{""|fn_url}" method="post" style="display:inline;">
                {include file="buttons/button.tpl"
                    but_role="submit"
                    but_meta="btn btn-primary"
                    is_btn_primary=true
                    but_name="dispatch[ap_safecache.cf_poll_now]"
                    but_text=__("ap_safecache.cf_poll_btn")
                }
            </form>

            {if ($ap_safecache_cf_poll_cron_need_password || $ap_safecache_cf_poll_cron_ready) && ($ap_safecache_license_is_pro|default:true)}
            <details class="ap-safecache-manage-fold" style="margin-top:10px;border:1px solid #e5e5e5;border-radius:4px;background:#fff;">
                <summary>{__("ap_safecache.manage_fold_cron_commands")}</summary>
                <div style="padding:10px 12px;border-top:1px solid #eee;">
                    {if $ap_safecache_cf_poll_cron_need_password}
                        <p class="muted" style="font-size:11px;margin:0;line-height:1.5;">{__("ap_safecache.cf_poll_cron_need_password")}</p>
                    {else}
                        <p class="muted" style="font-size:11px;margin:0 0 8px 0;line-height:1.5;">{__("ap_safecache.cf_poll_cron_intro")}</p>
                        {capture name="ap_safecache_cf_poll_cron_url_esc"}{$ap_safecache_cf_poll_cron_url|escape:'html'}{/capture}
                        <pre style="font-size:11px;word-break:break-all;white-space:pre-wrap;background:#fff;padding:8px;border:1px solid #e5e5e5;margin:6px 0 0 0;">wget -q -O- '{$smarty.capture.ap_safecache_cf_poll_cron_url_esc}&amp;cron_password=YOUR_PASSWORD'
curl -fsS '{$smarty.capture.ap_safecache_cf_poll_cron_url_esc}&amp;cron_password=YOUR_PASSWORD'</pre>
                        <p class="muted" style="font-size:11px;margin-top:6px;line-height:1.45;">{__("ap_safecache.cf_poll_cron_any_http")}</p>
                        <p class="muted" style="font-size:11px;margin-top:4px;">{__("ap_safecache.cf_poll_cron_replace_placeholder")}</p>
                    {/if}
                </div>
            </details>
            {/if}
            <p class="muted" style="font-size:11px;line-height:1.45;margin-top:10px;margin-bottom:6px;">{__("ap_safecache.cf_poll_disp_hint")}</p>
            {if $ap_safecache_cf_poll_display.status_code == 'none'}
                <p class="muted" style="margin-top:4px;margin-bottom:0;">{__("ap_safecache.cf_poll_never")}</p>
            {else}
                <div style="margin-top:8px;padding:12px 14px;background:#fff;border:1px solid #e5e5e5;border-radius:4px;">
                    <div style="display:flex;align-items:flex-start;gap:10px;">
                        <span style="flex-shrink:0;width:10px;height:10px;margin-top:4px;border-radius:50%;background:{if $ap_safecache_cf_poll_display.card_tone == 'success'}#5cb85c{elseif $ap_safecache_cf_poll_display.card_tone == 'warning'}#f0ad4e{elseif $ap_safecache_cf_poll_display.card_tone == 'danger'}#d9534f{else}#adb5bd{/if};"></span>
                        <div style="flex:1;min-width:0;">
                            <p style="margin:0 0 6px 0;font-size:14px;line-height:1.45;"><strong>{__("ap_safecache.cf_poll_card_headline")}</strong> {$ap_safecache_cf_poll_display.status_label|escape}</p>
                            {if $ap_safecache_cf_poll_display.targets_label != ''}
                                <p class="muted" style="margin:0 0 8px 0;font-size:12px;line-height:1.45;">{__("ap_safecache.cf_poll_card_drift", ["[targets]" => $ap_safecache_cf_poll_display.targets_label])}</p>
                            {/if}
                            <p style="margin:0 0 4px 0;font-size:12px;line-height:1.5;"><strong>{__("ap_safecache.cf_poll_line_page_prefix")}:</strong> {$ap_safecache_cf_poll_display.page_line_label|escape}</p>
                            <p style="margin:0 0 8px 0;font-size:12px;line-height:1.5;"><strong>{__("ap_safecache.cf_poll_line_cache_prefix")}:</strong> {$ap_safecache_cf_poll_display.cache_line_label|escape}</p>
                            {if $ap_safecache_cf_poll_display.status_code == 'error'}
                                {if $ap_safecache_cf_poll_display.last_success_at}
                                    <p class="muted" style="margin-bottom:4px;font-size:12px;">
                                        {__("ap_safecache.cf_poll_disp_last_ok_before_error", ["[time]" => $ap_safecache_cf_poll_display.last_success_at|date_format:"%Y-%m-%d %H:%M"])}
                                    </p>
                                {/if}
                                {if $ap_safecache_cf_poll_display.last_failed_at}
                                    <p class="muted" style="margin-bottom:4px;font-size:12px;">
                                        {__("ap_safecache.cf_poll_disp_last_failed", ["[time]" => $ap_safecache_cf_poll_display.last_failed_at|date_format:"%Y-%m-%d %H:%M"])}
                                    </p>
                                {/if}
                                {if $ap_safecache_cf_poll_display.error_message != ''}
                                    <p class="text-error" style="margin-bottom:0;font-size:12px;">{$ap_safecache_cf_poll_display.error_message|escape}</p>
                                {/if}
                            {elseif $ap_safecache_cf_poll_display.last_success_at}
                                <p class="muted" style="margin-bottom:0;font-size:12px;">
                                    {__("ap_safecache.cf_poll_disp_last_success", ["[time]" => $ap_safecache_cf_poll_display.last_success_at|date_format:"%Y-%m-%d %H:%M"])}
                                </p>
                            {/if}
                        </div>
                    </div>
                </div>
                {if $ap_safecache_cf_poll_display.status_code == 'changed'}
                    <div style="margin-top:12px;padding-top:10px;border-top:1px solid #e8e8e8;">
                        <p class="muted" style="font-size:11px;margin-bottom:8px;line-height:1.45;">{__("ap_safecache.cf_poll_changed_actions_intro")}</p>
                        <div class="btn-toolbar" style="margin-bottom:0;">
                            {if $ap_safecache_license_is_pro|default:true}
                            <div class="btn-group" style="margin-right:8px;margin-bottom:6px;">
                                <form action="{""|fn_url}" method="post" style="display:inline;">
                                    {include file="buttons/button.tpl"
                                        but_role="submit"
                                        but_meta="btn btn-default"
                                        is_btn_primary=false
                                        but_name="dispatch[ap_safecache.cf_backup_create_page]"
                                        but_text=__("ap_safecache.cf_poll_btn_backup_page")
                                    }
                                </form>
                                <form action="{""|fn_url}" method="post" style="display:inline;">
                                    {include file="buttons/button.tpl"
                                        but_role="submit"
                                        but_meta="btn btn-default"
                                        is_btn_primary=false
                                        but_name="dispatch[ap_safecache.cf_backup_create_cache]"
                                        but_text=__("ap_safecache.cf_poll_btn_backup_cache")
                                    }
                                </form>
                            </div>
                            {/if}
                            <div class="btn-group" style="margin-right:8px;margin-bottom:6px;">
                                <form action="{""|fn_url}" method="post" style="display:inline;">
                                    {include file="buttons/button.tpl"
                                        but_role="submit"
                                        but_meta="btn btn-success"
                                        is_btn_primary=false
                                        but_name="dispatch[ap_safecache.cf_fetch_rules]"
                                        but_text=__("ap_safecache.cf_poll_btn_refetch")
                                    }
                                </form>
                            </div>
                            <div class="btn-group" style="margin-bottom:6px;">
                                <a href="{$ap_safecache_manage_tab_urls.rules|fn_url}#ap-safecache-cf-editor" class="btn btn-default">{__("ap_safecache.cf_poll_btn_open_editor")}</a>
                            </div>
                        </div>
                    </div>
                {/if}
                {if $ap_safecache_cf_poll_state || ($ap_safecache_cf_poll_log_recent|@count > 0)}
                <details class="ap-safecache-manage-fold" style="margin-top:12px;border:1px solid #e5e5e5;border-radius:4px;background:#fff;">
                    <summary>{__("ap_safecache.manage_fold_poll_extra")}</summary>
                    <div style="padding:10px 12px;border-top:1px solid #eee;">
                        {if $ap_safecache_cf_poll_state}
                            <p class="muted" style="margin-top:0;margin-bottom:4px;font-size:11px;line-height:1.4;">
                                <span class="muted">Page:</span> <code style="word-break:break-all;">{$ap_safecache_cf_poll_state.page_hash|escape}</code><br />
                                <span class="muted">Cache:</span> <code style="word-break:break-all;">{$ap_safecache_cf_poll_state.cache_hash|escape}</code>
                            </p>
                            {if $ap_safecache_cf_poll_state.last_changed_at}
                                <p class="muted" style="margin-bottom:10px;font-size:12px;">
                                    {__("ap_safecache.cf_poll_last_changed", ["[time]" => $ap_safecache_cf_poll_state.last_changed_at|date_format:"%Y-%m-%d %H:%M"])}
                                </p>
                            {/if}
                        {/if}
                        {if $ap_safecache_cf_poll_log_recent|@count > 0}
                            <div style="margin-top:{if $ap_safecache_cf_poll_state}4px{else}0{/if};">
                                <span class="muted" style="font-size:11px;text-transform:uppercase;">{__("ap_safecache.cf_poll_log_title")}</span>
                                <table class="table table-condensed" style="margin-top:6px;font-size:12px;">
                                    <thead>
                                        <tr>
                                            <th>{__("ap_safecache.cf_poll_log_col_time")}</th>
                                            <th>{__("ap_safecache.cf_poll_log_col_changed")}</th>
                                            <th>{__("ap_safecache.cf_poll_log_col_targets")}</th>
                                            <th>{__("ap_safecache.cf_poll_log_col_backup")}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {foreach from=$ap_safecache_cf_poll_log_recent item=pl}
                                            <tr{if $pl.ui_row_tone == 'error'} style="background:#fdecea;"{elseif $pl.ui_row_tone == 'warning'} style="background:#fcf8e3;"{/if}>
                                                <td>{$pl.created_at|date_format:"%m-%d %H:%M"}</td>
                                                <td>{if $pl.changed}{__("ap_safecache.cf_poll_mark_yes")}{else}{__("ap_safecache.cf_poll_mark_no")}{/if}</td>
                                                <td>{$pl.ui_targets_short|escape}</td>
                                                <td>{if $pl.changed}{if $pl.backup_ok}{__("ap_safecache.cf_poll_mark_yes")}{else}{__("ap_safecache.cf_poll_mark_no")}{/if}{else}—{/if}</td>
                                            </tr>
                                        {/foreach}
                                    </tbody>
                                </table>
                            </div>
                        {/if}
                    </div>
                </details>
                {/if}
            {/if}
        </div>

        <div id="ap-safecache-diagnostics" class="well" style="margin-top:16px;border:1px solid #dcdcdc;border-radius:4px;background:#fafafa;scroll-margin-top:72px;">
            {include file="common/subheader.tpl" title=__("ap_safecache.ui_group_diagnostics")}
            <p class="muted">{__("ap_safecache.diagnostic_payload_hint")}</p>
            <div class="well well-small" style="margin-top: 8px;">
                <div style="max-height: 24rem; overflow: auto;">
                    {include file="common/widget_copy.tpl"
                        widget_copy_code_text=$ap_safecache_diagnostic_json|escape
                    }
                </div>
            </div>
        </div>
    </div>
</div>
