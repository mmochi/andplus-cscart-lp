<?php

/**
 * Cloudflare Page / Cache Rules の V1 フィンガープリント（比較用 SHA-256）。
 * API 配列順は維持。ルール要素はホワイトリスト＋連想配列の ksort／空値除去のみ（PUT 用 sanitize とは別経路）。
 */

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}

/**
 * @param mixed $v
 *
 * @return mixed|null null は「省略」
 */
function fn_ap_safecache_cf_fingerprint_normalize_value($v)
{
    if (is_array($v)) {
        if ($v === []) {
            return [];
        }
        $keys = array_keys($v);
        $is_list = $keys === range(0, count($v) - 1);

        if ($is_list) {
            $out = [];
            foreach ($v as $item) {
                $n = fn_ap_safecache_cf_fingerprint_normalize_value($item);
                if ($n === null || $n === '' || $n === []) {
                    continue;
                }
                $out[] = $n;
            }

            return $out;
        }

        $out = [];
        foreach ($v as $k => $item) {
            $n = fn_ap_safecache_cf_fingerprint_normalize_value($item);
            if ($n === null || $n === '' || $n === []) {
                continue;
            }
            $out[(string) $k] = $n;
        }
        ksort($out);

        return $out;
    }

    if ($v === null) {
        return null;
    }

    return $v;
}

/**
 * @param array<string, mixed> $rule
 *
 * @return array<string, mixed>
 */
function fn_ap_safecache_cf_fingerprint_prune_page_rule(array $rule)
{
    $allow = ['targets', 'actions', 'priority', 'status', 'enabled'];
    $out = [];
    foreach ($allow as $k) {
        if (!array_key_exists($k, $rule)) {
            continue;
        }
        $out[$k] = fn_ap_safecache_cf_fingerprint_normalize_value($rule[$k]);
    }

    return $out;
}

/**
 * @param array<string, mixed> $rule
 *
 * @return array<string, mixed>
 */
function fn_ap_safecache_cf_fingerprint_prune_cache_rule(array $rule)
{
    $allow = ['expression', 'action', 'action_parameters', 'description', 'enabled'];
    $out = [];
    foreach ($allow as $k) {
        if (!array_key_exists($k, $rule)) {
            continue;
        }
        $out[$k] = fn_ap_safecache_cf_fingerprint_normalize_value($rule[$k]);
    }

    return $out;
}

/**
 * @param list<array<string, mixed>> $page_rules
 *
 * @return list<array<string, mixed>>
 */
function fn_ap_safecache_cf_fingerprint_normalize_page_rules(array $page_rules)
{
    $out = [];
    foreach ($page_rules as $r) {
        if (!is_array($r)) {
            continue;
        }
        $out[] = fn_ap_safecache_cf_fingerprint_prune_page_rule($r);
    }

    return $out;
}

/**
 * @param array<string, mixed> $cache_ruleset
 *
 * @return list<array<string, mixed>>
 */
function fn_ap_safecache_cf_fingerprint_normalize_cache_rules(array $cache_ruleset)
{
    $rules = isset($cache_ruleset['rules']) && is_array($cache_ruleset['rules']) ? $cache_ruleset['rules'] : [];
    $out = [];
    foreach ($rules as $r) {
        if (!is_array($r)) {
            continue;
        }
        $out[] = fn_ap_safecache_cf_fingerprint_prune_cache_rule($r);
    }

    return $out;
}

/**
 * @param list<array<string, mixed>> $page_rules
 */
function fn_ap_safecache_cf_fingerprint_hash_page_rules(array $page_rules): string
{
    $norm = fn_ap_safecache_cf_fingerprint_normalize_page_rules($page_rules);
    $json = json_encode($norm, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        $json = '[]';
    }

    return hash('sha256', $json);
}

/**
 * @param array<string, mixed> $cache_ruleset
 */
function fn_ap_safecache_cf_fingerprint_hash_cache_ruleset(array $cache_ruleset): string
{
    $norm = fn_ap_safecache_cf_fingerprint_normalize_cache_rules($cache_ruleset);
    $json = json_encode($norm, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) {
        $json = '[]';
    }

    return hash('sha256', $json);
}
