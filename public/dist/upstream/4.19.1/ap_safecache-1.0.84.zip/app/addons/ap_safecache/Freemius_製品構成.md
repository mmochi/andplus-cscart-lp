# AP SafeCache — Freemius・Free/Pro・ソース提供（構成案）

**状態**: 製品・販売設計メモ。**1.0.63 以降**は `freemius_use=Y` のとき **`fn_ap_safecache_freemius_resolve_tier_or_null()`**（`lib/ap_safecache_freemius.php`）が `fn_ap_safecache_get_license_tier()` に優先。**オフ時**は従来どおり `license_tier`（`free` / `pro`、既定 `pro`）と `fn_ap_safecache_is_pro()`。  
**関連**: `MEMO_保留事項.md` §2、`実装仕様_現行.md` §14（ライセンス行）。

---

## 1. Freemius プロダクト構成（案）

| 項目 | 案 |
|------|-----|
| プロダクト | 1 プロダクト（例: AP SafeCache） |
| プラン | **Free（$0）** と **Pro（サブスクリプション）** |
| 配布 | **同一アドオン ZIP** に SDK を同梱し、**ライセンス／プランで機能を切替** |
| ソース提供 | **Freemius 上でダウンロード権を管理**（Pro に同梱 or 別プラン／バンドル） |

「ソース提供も Freemius」＝ **請求・ライセンス・ソース ZIP の取得権限を Freemius に集約**する想定。GitHub Private 招待は任意の補助。

---

## 2. Free で網羅する機能（案）

**コンセプト**: 店頭の安全なブロック再取得のコアと、Cloudflare の**閲覧・下書き**まで。

| 領域 | 内容（案） |
|------|------------|
| 店頭 | `block_manager.render` によるブロック差し替え、Ajax 完了後の更新、Lazy／初回デバウンス等の**既存フロント機能** |
| 店頭 | ログファイル出力は **制限あり**（Off 固定・行数上限・頻度上限など）も選択肢 |
| 管理 | 接続サマリ、**ping**（推奨 API / Cloudflare 到達確認） |
| Cloudflare | ルールの **取得**、セッション上の **表示・編集・差分表示**（**API による本番反映はしない**と割り切ると説明しやすい） |
| ライブポール | **手動ポールのみ**、ログは **直近 N 件まで** 等 |
| その他 | 決済 IP 注意表示。診断 JSON は **短いサマリのみ** 等も検討 |

---

## 3. Pro で網羅する機能（案）

**コンセプト**: エッジへの**書き込み**・**復旧**・**本番運用**一式。

| 領域 | 内容（案） |
|------|------------|
| Cloudflare | Page / Cache Rules の **反映（apply）** |
| Cloudflare | **パージ**（URL 指定 / Purge Everything） |
| Cloudflare | **推奨 Cache Rules** のセッションへの **マージ**（`cf_append_recommended_*`） |
| Cloudflare | **バックアップ / ロールバック / 複数世代**（Free は 0〜1 世代など数値で差別化可） |
| Cloudflare | **Cron ポール**、外部変更検知まわりのフル利用 |
| 店頭 | ログを **制限なし**、**REMOTE_ADDR 補正**を Pro 専用にする案もあり |
| 将来 | マルチストア向け一括などを Pro に寄せる余地 |

---

## 4. Free / Pro の境界で決めること（チェックリスト）

- **読み取りのみ（Free）** vs **書き込み（Pro）** で分けるか。
- バックアップ **最大世代数**、ポール **ログ件数**、パージ **可否** の数値・可否。
- 同一コードベースでの **`fn_ap_safecache_is_pro()` 等**と Freemius **プラン ID** の対応表を 1 箇所に集約するか。

---

## 5. ソース提供（Freemius）

| パターン | 説明 |
|----------|------|
| A | **Pro にソースダウンロード権を同梱** — Pro 購入者のみ Freemius からソース ZIP を取得 |
| B | **別プラン「Developer / Source」** — 一回買い or 年額でソース権のみ追加 |
| C | **Pro + Source バンドル** — Freemius のバンドル機能で表現 |

**注意**: 再配布禁止・サポート範囲・著作権表示は利用規約に明記する。

---

## 6. 実装フェーズ（現状）

| # | 状態 | 内容 |
|---|------|------|
| 1 | 済 | Freemius でプロダクト・Free / Pro・（必要なら）ソース用アセットを定義。 |
| 2 | 部分 | **SDK 同梱・Opt-in は未採用**。代わりに **REST `licenses/activate`** でプラン同期（`ap_safecache_freemius.php`）。 |
| 3 | 済 | `fn_ap_safecache_get_license_tier()` が Freemius 有効時に **`license_plan_name` → slug** と `freemius_plan_slugs_pro` を照合し **`pro` / `free`** を返す。 |
| 4 | 済 | 既存の **dispatch ガード**は `fn_ap_safecache_is_pro()` 経由のまま。 |
| 5 | 未 | ソース ZIP を **Freemius リリース**とバージョン紐づけ（販売オペ用）。 |
| 6 | 任意 | **Webhook / Cron** で失効を即時反映。 |

---

## 7. 改訂履歴

| 日付 | 内容 |
|------|------|
| 2026-04-15 | 初版（構成案を文書化） |
| 2026-04-15 | §6 を実装状況に更新（activate API・設定キー・SDK 未採用の注記） |
