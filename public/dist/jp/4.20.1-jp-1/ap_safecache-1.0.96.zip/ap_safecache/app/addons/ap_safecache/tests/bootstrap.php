<?php

/**
 * PHPUnit 用: CS-Cart 本体を起動せず lib のみ読み込む。
 */

declare(strict_types=1);

if (!defined('BOOTSTRAP')) {
    define('BOOTSTRAP', true);
}

require_once dirname(__DIR__) . '/lib/ap_safecache_remote_addr.php';
