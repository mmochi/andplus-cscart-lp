{script src="js/addons/ap_safecache/func.js"}
<script>
window.AP_SAFECACHE_AJAX_RELOAD_BLOCKS = {$ap_safecache_ajax_reload_blocks_json|default:'[]' nofilter};
window.AP_SAFECACHE_AJAX_RELOAD_DOM_IDS = {$ap_safecache_ajax_reload_dom_ids_json|default:'[]' nofilter};
window.AP_SAFECACHE_LOG_AJAX_BLOCK_RELOAD = {if $ap_safecache_log_ajax_block_reload}true{else}false{/if};
window.AP_SAFECACHE_IS_PRODUCT_VIEW = {if $ap_safecache_is_product_view|default:false}true{else}false{/if};
window.AP_SAFECACHE_LAZY_RELOAD_LAYOUT_BLOCKS = {if $ap_safecache_lazy_reload_layout_blocks|default:true}true{else}false{/if};
</script>
