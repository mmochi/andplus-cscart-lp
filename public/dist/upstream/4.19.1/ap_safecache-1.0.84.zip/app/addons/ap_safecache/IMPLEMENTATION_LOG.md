# AP SafeCache 実装記録

このファイルは、本スレッド／関連作業で入った挙動の整理用です（保留タスクではありません）。

**現在のバージョン（参考）:** `addon.xml` の `<version>`（記録時点: **1.0.83**）

---

## 現在の実装状況スナップショット（2026-04-18）

この節は **当時点のツリー全体の把握用**（詳細仕様は `実装仕様_現行.md`、保留は `MEMO_保留事項.md`）。

| 区分 | 現状 |
|------|------|
| **バージョン** | `addon.xml` **1.0.83**（正は常に同ファイルの `<version>`） |
| **エントリ** | `init.php` — `dispatch_before_display` / `get_route` / `before_dispatch` の 3 フック |
| **中核** | `func.php` — 設定・店頭 Ajax・パージ・診断・Freemius 連携の大半。先頭で `lib/*.php`（下表）と `cloudflare_rules.php` / `cf_cache_recommendations.php` を読み込み |
| **Cloudflare ルール** | `cloudflare_rules.php` — Page Rules / Cache Rules（cache entrypoint）取得・編集・適用、バックアップ・ロールバック、セッション上の編集 JSON |
| **推奨ルール** | `cf_cache_recommendations.php` — 推奨 Cache Rules の生成とセッションへのマージ（ライブ PUT はしない） |
| **lib** | `ap_safecache_remote_addr.php`（CF 経由 IP 補正）、`ap_safecache_cf_fingerprint.php`（モニタ用フィンガープリント）、`ap_safecache_freemius.php`（ライセンス同期）、`ap_safecache_freemius_config.php`（固定値・**任意** `ap_safecache_freemius_config.local.php`）、`ap_safecache_license_action_token.php`（**外部トークン化**／Pro 書き込み前の短命トークン） |
| **管理画面** | `controllers/backend/ap_safecache.php` — `manage` ほか各 POST `mode`（CF 操作・パージ・推奨マージ・Freemius 同期など）。**1.0.82〜** `license_action_token_fetch` は無し |
| **店頭** | `controllers/frontend/block_manager.pre.php` — ブロック再取得まわりのフック |
| **スキーマ** | `schemas/menu/menu.post.php`、`schemas/permissions/admin.post.php`、`schemas/permissions/trusted_controllers.post.php`、`schemas/security/csrf_validation.post.php` |
| **フロント資産** | `js/addons/ap_safecache/func.js`、`design/backend/templates/...`、`var/themes_repository/.../hooks/index/scripts.post.tpl`（テーマ配下のパスは `実装仕様_現行.md` 参照） |
| **言語** | `var/langs/ja` / `en` の `addons/ap_safecache.po` |
| **テスト** | `tests/` — PHPUnit（例: `RemoteAddrTest.php`） |
| **製品・販売メモ** | `Freemius_製品構成.md` |

**外部トークン（Pro 操作ゲートウェイ）:** `AP_SAFECACHE_LICENSE_ACTION_TOKEN_URL` 等は `lib/ap_safecache_freemius_config.php` 系。契約・シーケンス・開発用モックは別リポジトリ **cscart-ap-safecache** の `IMPLEMENTATION.md` を正とする。アドオン側の要約は `実装仕様_現行.md` の「1.5 Pro 操作トークン」。

**Freemius（§0 参照）:** `lib/ap_safecache_freemius.php`、管理画面ライセンスファネル、`license_tier` / `freemius_*` 設定オブジェクト。

---

## 0. Freemius ライセンス同期（1.0.63）

- **ファイル**: `lib/ap_safecache_freemius.php`。
- **API**: `POST .../products/{id}/licenses/activate.json`（body: `license_key`, `user_id` = `freemius_install_uid`）。
- **管理**: `dispatch[ap_safecache.freemius_sync_license]`、`manage.tpl` の `#ap-safecache-license-funnel`（購入導線は Free・キー未入力時のみ／URL は定数・**1.0.82〜** アドオン設定のチェックアウト項目なし、アドオン設定リンク・同期）。
- **判定**: 応答 `license_plan_name` を slug 化し、`freemius_plan_slugs_pro`（既定 `pro`）に含まれば **有料**。状態は `freemius_state_json`。
- **設定登録**: `fn_ap_safecache_ensure_addon_settings_objects_registered()` が **Freemius 用キー未登録時は再同期**するよう拡張（`freemius_use` の object_id を条件に追加）。

---

## 1. DOM 断片再取得（店頭 Ajax／GET フォールバック）

### 方針

- **アドオン設定側の DOM id テキストエリア**（旧 `ajax_reload_dom_ids`）と **CSS クラス指定**（`ajax_reload_dom_classes`）を廃止。
- 店頭で使う HTML id 一覧は **AP SafeCache のサイト画面**で保存する **`ajax_reload_dom_ids_manage` のみ**（旧「マージ」は実質この一覧＝`fn_ap_safecache_get_ajax_reload_dom_ids_merged()` は manage と同一）。
- クラスによる DOM 指定は **PHP／テンプレート／JS ともに削除**。

### 主な変更箇所（代表）

| 領域 | 内容 |
|------|------|
| `addon.xml` | 上記設定項目の削除、バージョン更新 |
| `func.php` | マージ処理・診断表示・assign からクラス／アドオン id 系を除去 |
| `design/.../scripts.post.tpl` 等 | `AP_SAFECACHE_AJAX_RELOAD_DOM_CLASSES` 削除 |
| `js/addons/ap_safecache/func.js` | `dom_class`・クラス配列・`extractOuterHtmlFirstByClassName` 等を削除。`applyDomFragmentPatchesFromHtmlString` / `reloadDomFragmentsViaFullPage` は **id のみ** |
| `manage.tpl`（診断表） | DOM 関連行の整理 |
| `var/langs/ja|en/addons/ap_safecache.po` | 削除した設定の文言整理、`ajax_reload_dom_ids_manage_*` の説明更新 |

### `#navbar_mobile` の自動付与（廃止）

- 以前: ページに `#navbar_mobile` があれば、一覧に無くても **自動で id を追加**していた。
- 現在: **自動付与しない**。サイト画面に **明示した id のみ**対象。
- 旧実装は `func.js` 内 **コメントブロック**に残してあり、復旧時は関数のコメント解除＋`document.ready` の呼び出しコメント解除で戻せる。
- 遅延リトライ（`AP_SAFECACHE_DOM_FRAGMENT_RETRY_MS`）は、**一覧に `navbar_mobile` を自分で入れた場合のみ**有効（従来どおり）。

---

## 2. Cloudflare Cache Rules 推奨生成（`cf_cache_recommendations.php`）

### SEO 名から path を or 連結

- SEO アドオン有効時、`?:seo_names`（`object_id = 0`, `type = s`）から、バイパス対象 dispatch に対応する **`name`** をパス断片化し、`http.request.uri.path contains "..."` を生成。
- **正規化パスが同じものは 1 つにマージ**（`$seen`）。

### 固定パス `/profiles`

- **`dispatch=profiles` は needles に含めない**（クエリ条件としては使わない）。
- マイアカウント一覧のきれいな URL **`/profiles`** は、`seo_names` だけでは拾い切れない場合があるため、**固定の path 素片**として追加。
- 実装: `fn_ap_safecache_cf_rec_get_fixed_bypass_path_atoms()` → 現状は `path contains "/profiles"` を返す。
- 推奨ルール組み立て時は `dispatch` query 素片 + SEO path 素片 + 固定 path 素片をマージし、**`array_unique` で式レベルの重複を排除**（`seo_names` 側でも `/profiles` が出る場合の二重を防ぐ）。

### 検討メモ（未実装の可能性）

- **全有効言語を明示的に `lang_code IN (...)` で絞る**多言語専用クエリは、議論のみ／途中案があり、**現行コードは `seo_names` を言語条件なしで取得**（重複パスはマージ）。必要なら別途 `?:languages.status = A` と組み合わせた SQL に差し替え可能。

---

## 3. Cloudflare API・バックアップ・ロールバック（`cloudflare_rules.php` / 管理 `mode`）

実装の中心は `cloudflare_rules.php`。**Page Rules API** と **Cache Rules（Rulesets の `http_request_cache_settings` エントリポイント）**のみ。WAF 等は対象外（ファイル先頭コメントどおり）。

### API ラッパ

- `fn_ap_safecache_cf_get_credentials()` … アドオン設定の API Token と Zone ID。
- `fn_ap_safecache_cf_api($method, $path_after_v4, $body)` … `https://api.cloudflare.com/client/v4/{path}` に Bearer で GET/POST/PUT/DELETE。レスポンスは `success` と HTTP ステータスで成否判定。

### 取得・セッション（編集の前提）

- `fn_ap_safecache_cf_fetch_live_page_rules_only()` … `GET zones/{zone_id}/pagerules`。
- `fn_ap_safecache_cf_fetch_live_cache_ruleset_only()` … `GET zones/{zone_id}/rulesets/phases/http_request_cache_settings/entrypoint`。
- `fn_ap_safecache_cf_fetch_rules_to_session()` … 上記をまとめて取得し、`Tygh::$app['session']['ap_safecache_cf']` に `page_rules` / `cache_ruleset` / `fetched_at` および差分用 baseline を保存。**先にフェッチしてから**エディタ・差分・推奨ルールのマージが有効（`cf_err_fetch_first`）。

管理画面 POST: `cf_fetch_rules` → 上記。

### Cache Rules の追加・更新（API 上は rules 配列の置換）

- 本体は `fn_ap_safecache_cf_apply_cache_rules_put($zone_id, $rules)` … 同じ entrypoint に **`PUT` で `rules` 全体を置換**（単一ルールの部分 PATCH ではない）。
- PUT 前に `fn_ap_safecache_cf_sanitize_cache_rules_for_put()` で `last_updated` / `version` / `ref` を除去。`bypass_cache` は `set_cache_settings` + `cache:false` に正規化。
- フォームからの反映: `fn_ap_safecache_cf_apply_cache_rules_from_post()` → 成功後に `fn_ap_safecache_cf_fetch_rules_to_session()` で再取得。

### Page Rules の追加・更新・削除

- `fn_ap_safecache_cf_apply_page_rules_sync($zone_id, $baseline, $edited_list)` … baseline と編集後を突き合わせ、**削除は DELETE**、既存 id は **PUT**、id なしは **POST** で同期。

### 推奨 Cache Rules とセッション（`cf_cache_recommendations.php`）

- `fn_ap_safecache_cf_append_recommended_cache_rules_to_session()` … **取得済み**の `cache_ruleset` 上に推奨ルールをマージ（同一 expression の既存ルールの扱い・挿入位置などは実装コメント参照）。**Cloudflare への書き込みはしない**（セッション内の編集 JSON のみ更新）。反映はエディタから `cf_apply_cache_rules`。

### DB バックアップ（世代管理）

- `fn_ap_safecache_cf_ensure_backup_table()` … `?:ap_safecache_cf_page_backups` と `?:ap_safecache_cf_cache_backups`（Page / Cache で**別テーブル・別世代**）。旧統合テーブル `?:ap_safecache_cf_backups` があれば `fn_ap_safecache_cf_migrate_legacy_combined_backup_table_if_needed()` で分割移行後 DROP。
- 作成: `fn_ap_safecache_cf_backup_create_page_now()` / `fn_ap_safecache_cf_backup_create_cache_now()` … それぞれ API で**ライブ取得した JSON**を `payload` に保存。`generation` はゾーン内で連番。直後に `fn_ap_safecache_cf_backup_prune()` で最大世代数（定数 `AP_SAFECACHE_CF_BACKUP_MAX_GENERATIONS`）を超えた行を削除。
- 一覧・削除: `fn_ap_safecache_cf_backup_list_*` / `fn_ap_safecache_cf_backup_delete_*`（現在の zone に属する行のみ）。

### ロールバック

- `fn_ap_safecache_cf_rollback_page($backup_id)` … バックアップの Page Rules 配列を**目標状態**とし、現在のライブを baseline に `fn_ap_safecache_cf_apply_page_rules_sync()` で合わせる。
- `fn_ap_safecache_cf_rollback_cache($backup_id)` … バックアップの `payload` から `rules` を取り出し `fn_ap_safecache_cf_apply_cache_rules_put()` で反映。
- いずれも成功後に `fn_ap_safecache_cf_fetch_rules_to_session()`。

### コントローラ対応（`controllers/backend/ap_safecache.php`）

| `mode`（POST） | 処理の要点 |
|----------------|------------|
| `cf_fetch_rules` | ルール取得→セッション |
| `cf_append_recommended_cache_rules` | 推奨をセッションにマージ |
| `cf_show_diff` / `cf_apply_cache_rules` / `cf_apply_page_rules` | 差分表示・Cache/Page 適用 |
| `cf_backup_create_page` / `cf_backup_create_cache` | バックアップ作成 |
| `cf_rollback_page` / `cf_rollback_cache` | `backup_id` でロールバック |
| `cf_backup_delete_page` / `cf_backup_delete_cache` | バックアップ行削除 |

---

## 4. 運用上の注意

- 言語 PO を直編集した場合は、管理画面の言語インポートやキャッシュクリアで反映確認すること。
- Cloudflare 側の式は長大化し得るため、ルール長の上限に注意（大量の `or`）。

---

## 5. 管理 UI・ドキュメント（2026-04 時点）

### 推奨 Cache Rules ブロック（`manage.tpl`）

- カードヘッダを **flex** 化し、アクション文字列は **全幅**で折り返し（長い `set_cache_settings` でもレイアウト崩れにくく）。
- 式・JSON 用 `<pre>` の **`style` 属性内に二重引用符付きフォント名を入れない**（例: `"Courier New"` は HTML 属性境界を壊し、`<pre>` が枠外に溢れる）。**`font-family: Consolas,Menlo,Monaco,monospace` のみ**。
- 新テンプレ適用の切り分け用に HTML コメント `recommended rules UI v2` を `#ap-safecache-cf-recommended` 直下へ挿入。

### 詳細仕様

- 推奨ルールの評価順・挿入ロジック（Cache Everything 直後）・ライブポール DB／表示の整理は **`実装仕様_現行.md`**（§7・§8 等）を正とする。

---

## 6. Free/Pro エディションの管理 UI 訴求（2026-04）

### 背景

- **差分（`cf_show_diff`）は Free でも利用可能**（最終取得スナップショットとエディタ JSON の **ローカル比較**のみ）。
- **反映（Apply）は Pro**。かつて Apply 用の Pro 注記が差分ボタンと同列にあり、**差分＝Pro** と誤読されやすかった。

### 実装概要

| 領域 | 内容 |
|------|------|
| `manage_tab_rules.tpl` | 差分ブロックと反映ブロックを **行として分離**。Free 時は反映行に `cf_apply_requires_pro_note` のみ（Apply ボタン非表示）。 |
| 同上 | Free 時、**緑ボーダー**の訴求ブロックで `license_pro_rules_value_title` + `license_pro_rules_value_li1`〜`li5` + `license_pro_rules_value_free_reminder`（箇条書きで Pro メリットを明示）。 |
| `manage.tpl` | Free 時バナー見出し `license_free_banner_title` を **検証 vs 本番反映**が伝わる文言に変更。 |
| `ap_safecache.po`（en/ja） | 上記キー追加。旧 `license_pro_rules_value_brief`（一文）は **廃止**。 |

### 仕様の正

- **機能線引き・次期 Freemius 予定**は **`実装仕様_現行.md` §14** を正とする。

---

## 7. ライセンス・トークン・Freemius UI（1.0.82・2026-04）

**目的:** チェックアウト URL をアドオン設定に持たせず配布用定数に集約し、Pro 操作トークンは **書き込み直前の自動取得**に統一する。

| 領域 | 内容 |
|------|------|
| `addon.xml` | バージョン **1.0.82**。`freemius_checkout_url_pro_ss` / `freemius_checkout_url_pro_mv` 設定項目を**削除**（DB 残存は未使用扱い）。 |
| `lib/ap_safecache_freemius.php` | `fn_ap_safecache_freemius_get_checkout_url_pro_single_store` / `..._multi_vendor` は **DB を読まず**、`AP_SAFECACHE_FREEMIUS_CHECKOUT_URL_PRO_*` → 単一 `CHECKOUT_URL` へフォールバック。 |
| `lib/ap_safecache_freemius_config.php` | コメントを「Pro チェックアウトはアドオン設定で上書きしない」旨に更新。 |
| `lib/ap_safecache_license_action_token.php` | `fn_ap_safecache_license_action_token_ensure_for_pro_write()` 追加。`abort_pro_write` / `redirect_or_null` は ensure 失敗時のみ通知（`fetch_now` のメッセージ）。`block_message_or_null` は**常に null**。 |
| `func.php` | エッジパージ系で `ensure` 失敗時に通知（従来の「ページ表示用ブロック文言」経路をやめる）。 |
| `cloudflare_rules.php` | バックアップ作成（page/cache）で `needs_fetch` + 固定文言をやめ、**ensure 失敗時は `fetch_now` のメッセージ**を返す。 |
| `controllers/backend/ap_safecache.php` | POST `mode=license_action_token_fetch` を**削除**。`manage` の `license_action_token_*` assign を**削除**。 |
| `design/.../manage.tpl` | トークン取得ボタン・トークン状態の常時表示を**削除**。 |
| `var/langs/ja|en/addons/ap_safecache.po` | `SettingsOptions::...freemius_checkout_url_pro_*` の 2 ブロックを**削除**。 |
| **運用** | 配布ツリー `andplus-apps/.../ap_safecache/ap_safecache` とローカル CS-Cart（例: `cloudflare_test_v4.19.1_JP_1`）は、`app/addons/ap_safecache`、`design/backend/templates/...`、`js/addons/...`、`var/langs/.../ap_safecache.po`、`var/themes_repository/...` と `design/themes/...` へ **rsync** 等で揃える（キャッシュ・ログは対象外）。 |

**仕様の正:** `実装仕様_現行.md` の **§0.2 / §0.3 / §1.5 / §14.4**。

---

*記録の更新は、仕様変更時に本ファイルへ追記してください。*
