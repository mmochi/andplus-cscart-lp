<?php

/**
 * Cloudflare Cache-Tag 名の単一ソース（タグパージキュー producer と店頭応答で共有）。
 *
 * @see MEMO_保留事項.md §11.17.7
 */

if (!defined('BOOTSTRAP')) {
    die('Access denied');
}

use Tygh\Registry;

/**
 * タグパージ API 用・店頭 Cache-Tag 用の商品タグ名。
 */
function fn_ap_safecache_cf_purge_tag_product($product_id)
{
    return 'product-' . (int) $product_id;
}

/**
 * タグパージ API 用・店頭 Cache-Tag 用のカテゴリタグ名。
 */
function fn_ap_safecache_cf_purge_tag_category($category_id)
{
    return 'category-' . (int) $category_id;
}

/**
 * 店頭 `products.search` とパージキュー共有の固定タグ（検索結果 HTML 一括無効化用）。
 */
function fn_ap_safecache_cf_purge_tag_search_results()
{
    return 'search-results';
}

/**
 * 店頭フルページ: Cloudflare がエッジで紐付ける `Cache-Tag` を付与（`products.view` / `categories.view` / `products.search`）。
 *
 * @return void
 */
function fn_ap_safecache_storefront_cf_cache_tag_headers_send()
{
    if (headers_sent()) {
        return;
    }

    if (!function_exists('fn_ap_safecache_purge_queue_is_enabled') || !fn_ap_safecache_purge_queue_is_enabled()) {
        return;
    }

    $addon = Registry::get('addons.ap_safecache');
    $addon = is_array($addon) ? $addon : [];
    $raw = $addon['cf_storefront_cache_tag_enable'] ?? 'Y';
    $s = strtoupper(trim((string) $raw));
    if (!($s === 'Y' || $s === '1' || $s === 'YES' || $s === 'ON' || $s === 'TRUE')) {
        return;
    }

    $controller = (string) Registry::get('runtime.controller');
    $mode = (string) Registry::get('runtime.mode');

    $tags = [];

    if ($controller === 'products' && $mode === 'view') {
        $pid = isset($_REQUEST['product_id']) ? (int) $_REQUEST['product_id'] : 0;
        if ($pid > 0) {
            $tags[] = fn_ap_safecache_cf_purge_tag_product($pid);
        }
    } elseif ($controller === 'categories' && $mode === 'view') {
        $cid = isset($_REQUEST['category_id']) ? (int) $_REQUEST['category_id'] : 0;
        if ($cid > 0) {
            $tags[] = fn_ap_safecache_cf_purge_tag_category($cid);
        }
    } elseif ($controller === 'products' && $mode === 'search') {
        $tags[] = fn_ap_safecache_cf_purge_tag_search_results();
    }

    if ($tags === []) {
        return;
    }

    $tags = array_values(array_unique($tags));
    $value = implode(', ', $tags);
    if ($value === '') {
        return;
    }

    header('Cache-Tag: ' . $value, false);
}
