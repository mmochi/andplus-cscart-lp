<?php

if ( !defined('BOOTSTRAP') ) { die('Access denied'); }

fn_register_hooks(
    'dispatch_before_display',
    'get_route',
    'before_dispatch',
    'update_addon_post'
);